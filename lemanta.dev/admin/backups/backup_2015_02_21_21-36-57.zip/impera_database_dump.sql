-- Impera CMS: дамп таблиц базы данных.
-- Версия системы: 150215
-- http://aimatrix.itak.info
--
-- Время создания: 2015-02-21 21:36:57
-- Предписанный список таблиц: все (кроме кеш-таблиц)

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА articles: структура
--
-- ----------------------------------------------------------------------------

DROP TABLE IF EXISTS `articles`;

CREATE TABLE `articles` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `header` varchar(500) NOT NULL,
  `url` varchar(255) NOT NULL,
  `meta_title` varchar(500) NOT NULL,
  `meta_keywords` varchar(500) NOT NULL,
  `meta_description` varchar(500) NOT NULL,
  `annotation` text NOT NULL,
  `body` longtext NOT NULL,
  `order_num` int(11) NOT NULL DEFAULT '0',
  `enabled` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `listed` tinyint(1) NOT NULL DEFAULT '1',
  `section` int(11) NOT NULL DEFAULT '1',
  `menu_id` int(11) NOT NULL DEFAULT '0',
  `objects` varchar(512) NOT NULL DEFAULT '',
  `category_id` int(11) NOT NULL DEFAULT '0',
  `brand_id` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  `commented` tinyint(1) NOT NULL DEFAULT '1',
  `hidden` tinyint(1) NOT NULL DEFAULT '0',
  `rss_disabled` tinyint(1) NOT NULL DEFAULT '0',
  `export_disabled` tinyint(1) NOT NULL DEFAULT '0',
  `url_special` tinyint(1) NOT NULL DEFAULT '0',
  `images` text NOT NULL,
  `images_alts` text NOT NULL,
  `images_texts` longtext NOT NULL,
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `browsed` int(11) NOT NULL DEFAULT '0',
  `images_view` text NOT NULL,
  `seo_description` text NOT NULL,
  `rating` float(12,2) NOT NULL DEFAULT '0.00',
  `votes` int(11) NOT NULL DEFAULT '0',
  `highlighted` tinyint(1) NOT NULL DEFAULT '0',
  `tags` varchar(256) NOT NULL DEFAULT '' COMMENT 'Теги записи',
  PRIMARY KEY (`article_id`),
  KEY `enabled` (`enabled`),
  KEY `order_num` (`order_num`),
  KEY `url` (`url`),
  KEY `menu_id` (`menu_id`),
  KEY `category_id` (`category_id`),
  KEY `brand_id` (`brand_id`),
  KEY `user_id` (`user_id`),
  KEY `hidden` (`hidden`),
  KEY `rss_disabled` (`rss_disabled`),
  KEY `export_disabled` (`export_disabled`),
  KEY `browsed` (`browsed`),
  KEY `votes` (`votes`),
  KEY `highlighted` (`highlighted`),
  KEY `tags` (`tags`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА articles: содержимое
--
-- ----------------------------------------------------------------------------


-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА articles_comments: структура
--
-- ----------------------------------------------------------------------------

DROP TABLE IF EXISTS `articles_comments`;

CREATE TABLE `articles_comments` (
  `comment_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `parent_id` bigint(20) NOT NULL DEFAULT '0',
  `article_id` int(11) NOT NULL DEFAULT '0',
  `ip` varchar(32) NOT NULL DEFAULT '',
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `name` varchar(255) NOT NULL DEFAULT '',
  `comment` varchar(4096) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `from_user` int(11) NOT NULL DEFAULT '0',
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`comment_id`),
  KEY `parent_id` (`parent_id`),
  KEY `article_id` (`article_id`),
  KEY `from_user` (`from_user`),
  KEY `enabled` (`enabled`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА articles_comments: содержимое
--
-- ----------------------------------------------------------------------------


-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА banneds: структура
--
-- ----------------------------------------------------------------------------

DROP TABLE IF EXISTS `banneds`;

CREATE TABLE `banneds` (
  `ban_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ip` varchar(256) NOT NULL DEFAULT '',
  `begin_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `end_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `no_access` tinyint(1) NOT NULL DEFAULT '1',
  `no_register` tinyint(1) NOT NULL DEFAULT '1',
  `no_comment` tinyint(1) NOT NULL DEFAULT '1',
  `no_admin` tinyint(1) NOT NULL DEFAULT '1',
  `remark` text NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `attempts` int(11) NOT NULL DEFAULT '0',
  `attempts_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `no_callme` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`ban_id`),
  KEY `no_access` (`no_access`),
  KEY `no_register` (`no_register`),
  KEY `no_comment` (`no_comment`),
  KEY `no_admin` (`no_admin`),
  KEY `enabled` (`enabled`),
  KEY `attempts` (`attempts`),
  KEY `no_callme` (`no_callme`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА banneds: содержимое
--
-- ----------------------------------------------------------------------------


-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА brands: структура
--
-- ----------------------------------------------------------------------------

DROP TABLE IF EXISTS `brands`;

CREATE TABLE `brands` (
  `brand_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'Идентификатор бренда',
  `name` varchar(256) NOT NULL DEFAULT '' COMMENT 'Название бренда',
  `url` varchar(256) NOT NULL DEFAULT '' COMMENT 'Окончание URL страницы',
  `meta_title` varchar(256) NOT NULL DEFAULT '' COMMENT 'Мета заголовок страницы',
  `meta_keywords` varchar(512) NOT NULL DEFAULT '' COMMENT 'Мета ключевые слова страницы',
  `meta_description` varchar(512) NOT NULL DEFAULT '' COMMENT 'Мета описание страницы',
  `description` text NOT NULL,
  `subdomain` varchar(256) NOT NULL DEFAULT '' COMMENT 'Левая часть имени собственного субдомена',
  `subdomain_enabled` tinyint(1) NOT NULL DEFAULT '1',
  `subdomain_html` text NOT NULL,
  `section` int(11) NOT NULL DEFAULT '1',
  `hidden` tinyint(1) NOT NULL DEFAULT '0',
  `order_num` int(11) NOT NULL DEFAULT '0',
  `parent` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Идентификатор родительского бренда',
  `parents` text NOT NULL,
  `url_special` tinyint(1) NOT NULL DEFAULT '0',
  `image` varchar(256) NOT NULL DEFAULT '' COMMENT 'Основное фото бренда',
  `images` text NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `informative` tinyint(1) NOT NULL DEFAULT '0',
  `menu_id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Идентификатор меню',
  `objects` varchar(512) NOT NULL DEFAULT '',
  `user_id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Идентификатор администрирующего пользователя',
  `rss_disabled` tinyint(1) NOT NULL DEFAULT '0',
  `export_disabled` tinyint(1) NOT NULL DEFAULT '0',
  `seo_description` text NOT NULL,
  `images_alts` text NOT NULL,
  `images_texts` longtext NOT NULL,
  `images_view` text NOT NULL,
  `browsed` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Количество просмотров страницы',
  `highlighted` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Выделена ли запись визуально',
  `tags` varchar(256) NOT NULL DEFAULT '' COMMENT 'Теги записи',
  `sync_id` varchar(40) NOT NULL DEFAULT '' COMMENT 'Синхронизационный идентификатор',
  `template` varchar(256) NOT NULL DEFAULT '' COMMENT 'Шаблон, используемый для отображения страницы',
  PRIMARY KEY (`brand_id`),
  KEY `name` (`name`),
  KEY `subdomain` (`subdomain`),
  KEY `subdomain_enabled` (`subdomain_enabled`),
  KEY `order_num` (`order_num`),
  KEY `parent` (`parent`),
  KEY `enabled` (`enabled`),
  KEY `informative` (`informative`),
  KEY `menu_id` (`menu_id`),
  KEY `user_id` (`user_id`),
  KEY `rss_disabled` (`rss_disabled`),
  KEY `export_disabled` (`export_disabled`),
  KEY `browsed` (`browsed`),
  KEY `highlighted` (`highlighted`),
  KEY `hidden` (`hidden`),
  KEY `url` (`url`),
  KEY `url_special` (`url_special`),
  KEY `tags` (`tags`),
  KEY `section` (`section`),
  KEY `sync_id` (`sync_id`),
  KEY `template` (`template`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА brands: содержимое
--
-- ----------------------------------------------------------------------------


-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА callme: структура
--
-- ----------------------------------------------------------------------------

DROP TABLE IF EXISTS `callme`;

CREATE TABLE `callme` (
  `callme_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(256) NOT NULL DEFAULT '',
  `phone` varchar(256) NOT NULL DEFAULT '',
  `email` varchar(256) NOT NULL DEFAULT '',
  `icq` varchar(256) NOT NULL DEFAULT '',
  `skype` varchar(256) NOT NULL DEFAULT '',
  `reason` varchar(8192) NOT NULL DEFAULT '' COMMENT 'Описание причины запроса',
  `ip` varchar(256) NOT NULL DEFAULT '',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `done` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`callme_id`),
  KEY `done` (`done`),
  KEY `name` (`name`),
  KEY `phone` (`phone`),
  KEY `email` (`email`),
  KEY `icq` (`icq`),
  KEY `skype` (`skype`),
  KEY `ip` (`ip`),
  KEY `created` (`created`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА callme: содержимое
--
-- ----------------------------------------------------------------------------


-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА categories: структура
--
-- ----------------------------------------------------------------------------

DROP TABLE IF EXISTS `categories`;

CREATE TABLE `categories` (
  `category_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'Идентификатор категории',
  `parent` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Идентификатор родительской категории',
  `name` varchar(256) NOT NULL DEFAULT '' COMMENT 'Название категории',
  `single_name` varchar(256) NOT NULL DEFAULT '' COMMENT 'Название в единственном числе',
  `meta_title` varchar(256) NOT NULL DEFAULT '' COMMENT 'Мета заголовок страницы',
  `meta_keywords` varchar(512) NOT NULL DEFAULT '' COMMENT 'Мета ключевые слова страницы',
  `meta_description` varchar(512) NOT NULL DEFAULT '' COMMENT 'Мета описание страницы',
  `description` text NOT NULL,
  `url` varchar(256) NOT NULL DEFAULT '' COMMENT 'Окончание URL страницы',
  `image` varchar(256) NOT NULL DEFAULT '' COMMENT 'Основное фото категории',
  `order_num` int(11) NOT NULL DEFAULT '0',
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `subdomain` varchar(256) NOT NULL DEFAULT '' COMMENT 'Левая часть имени собственного субдомена',
  `subdomain_enabled` tinyint(1) NOT NULL DEFAULT '1',
  `subdomain_html` text NOT NULL,
  `section` int(11) NOT NULL DEFAULT '1',
  `hidden` tinyint(1) NOT NULL DEFAULT '0',
  `parents` text NOT NULL,
  `in_prices` tinyint(1) unsigned NOT NULL DEFAULT '255',
  `informative` tinyint(1) NOT NULL DEFAULT '0',
  `url_special` tinyint(1) NOT NULL DEFAULT '0',
  `images` text NOT NULL,
  `menu_id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Идентификатор меню',
  `objects` varchar(512) NOT NULL DEFAULT '',
  `user_id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Идентификатор администрирующего пользователя',
  `rss_disabled` tinyint(1) NOT NULL DEFAULT '0',
  `export_disabled` tinyint(1) NOT NULL DEFAULT '0',
  `seo_description` text NOT NULL,
  `images_alts` text NOT NULL,
  `images_texts` longtext NOT NULL,
  `images_view` text NOT NULL,
  `browsed` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Количество просмотров страницы',
  `ymarket` int(11) NOT NULL DEFAULT '1' COMMENT 'Признак Экспорт в Яндекс.Маркет',
  `vkontakte` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'Признак Экспорт в ВКонтакте',
  `highlighted` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Выделена ли запись визуально',
  `own_block` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Имеет ли категория свой блок на основной странице каталога',
  `configurator_name` varchar(256) NOT NULL DEFAULT '' COMMENT 'Название категории в конфигураторе',
  `tags` varchar(256) NOT NULL DEFAULT '' COMMENT 'Теги записи',
  `sync_id` varchar(40) NOT NULL DEFAULT '' COMMENT 'Синхронизационный идентификатор',
  `template` varchar(256) NOT NULL DEFAULT '' COMMENT 'Шаблон, используемый для отображения страницы',
  PRIMARY KEY (`category_id`),
  KEY `order_num` (`order_num`),
  KEY `parent` (`parent`),
  KEY `url` (`url`),
  KEY `enabled` (`enabled`),
  KEY `subdomain` (`subdomain`),
  KEY `subdomain_enabled` (`subdomain_enabled`),
  KEY `in_prices` (`in_prices`),
  KEY `informative` (`informative`),
  KEY `menu_id` (`menu_id`),
  KEY `user_id` (`user_id`),
  KEY `rss_disabled` (`rss_disabled`),
  KEY `export_disabled` (`export_disabled`),
  KEY `browsed` (`browsed`),
  KEY `ymarket` (`ymarket`),
  KEY `vkontakte` (`vkontakte`),
  KEY `highlighted` (`highlighted`),
  KEY `own_block` (`own_block`),
  KEY `hidden` (`hidden`),
  KEY `url_special` (`url_special`),
  KEY `name` (`name`),
  KEY `single_name` (`single_name`),
  KEY `configurator_name` (`configurator_name`),
  KEY `tags` (`tags`),
  KEY `section` (`section`),
  KEY `sync_id` (`sync_id`),
  KEY `template` (`template`)
) ENGINE=MyISAM AUTO_INCREMENT=80 DEFAULT CHARSET=utf8;

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА categories: содержимое
--
-- ----------------------------------------------------------------------------

INSERT INTO `categories` VALUES ('11', '0', 'Мальчики', '', 'Мальчики', '', '', '', 'boys', '', '81', '1', '', '1', '', '1', '0', '', '255', '0', '0', '', '0', '', '0', '0', '0', '', '', '', '', '65', '1', '1', '0', '0', '', '', '', '');
INSERT INTO `categories` VALUES ('39', '0', 'Девочки', '', 'Девочки', '', '', '', 'devochki', '', '82', '1', '', '1', '', '1', '0', '', '255', '0', '0', '', '0', '', '0', '0', '0', '', '', '', '', '67', '1', '1', '0', '0', '', '', '', '');
INSERT INTO `categories` VALUES ('55', '0', 'Распродажа', '', 'Распродажа', 'Распродажа', '', '', 'rasprodazha', '', '79', '1', '', '1', '', '1', '0', '', '255', '0', '0', '', '0', '', '0', '0', '0', '', '', '', '', '51', '1', '1', '0', '0', '', '', '', '');
INSERT INTO `categories` VALUES ('56', '0', 'Женщины', '', 'Женщины', '', '', '', 'zhenschiny', '', '83', '1', '', '1', '', '1', '0', '', '255', '0', '0', '', '0', '', '0', '0', '0', '', '', '', '', '118', '1', '1', '0', '0', '', '', '', '');

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА countries: структура
--
-- ----------------------------------------------------------------------------

DROP TABLE IF EXISTS `countries`;

CREATE TABLE `countries` (
  `country_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'Идентификатор страны',
  `enabled` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'Разрешена ли запись к использованию',
  `url` varchar(256) NOT NULL DEFAULT '' COMMENT 'Адрес страницы записи',
  `meta_title` varchar(256) NOT NULL DEFAULT '' COMMENT 'Мета заголовок страницы записи',
  `meta_keywords` varchar(512) NOT NULL DEFAULT '' COMMENT 'Мета ключевые слова страницы записи',
  `meta_description` varchar(512) NOT NULL DEFAULT '' COMMENT 'Мета описание страницы записи',
  `name` varchar(256) NOT NULL DEFAULT '' COMMENT 'Название страны',
  `description` text NOT NULL COMMENT 'Описание страны',
  `seo_description` text NOT NULL COMMENT 'SEO текст',
  `phone_code` varchar(16) NOT NULL DEFAULT '' COMMENT 'Телефонный код страны',
  `images` text NOT NULL COMMENT 'Изображения записи',
  `images_alts` text NOT NULL COMMENT 'Подписи изображений записи',
  `images_texts` longtext NOT NULL COMMENT 'Описания изображений записи',
  `images_view` text NOT NULL COMMENT 'Признаки использования в слайдере изображений записи',
  `tags` varchar(256) NOT NULL DEFAULT '' COMMENT 'Теги записи',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Дата создания записи',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Дата изменения записи',
  `browsed` int(11) NOT NULL DEFAULT '0' COMMENT 'Количество просмотров записи',
  `order_num` int(11) NOT NULL DEFAULT '0' COMMENT 'Порядковый номер записи',
  `hidden` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Признак Скрыто от неавторизованных',
  `highlighted` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Признак Выделено визуально',
  `commented` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'Признак Разрешено к обсуждению',
  `url_special` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Признак Особый адрес',
  `template` varchar(256) NOT NULL DEFAULT '' COMMENT 'Нестандартный шаблон для отображения',
  PRIMARY KEY (`country_id`),
  KEY `enabled` (`enabled`),
  KEY `url` (`url`),
  KEY `name` (`name`),
  KEY `phone_code` (`phone_code`),
  KEY `tags` (`tags`),
  KEY `created` (`created`),
  KEY `modified` (`modified`),
  KEY `browsed` (`browsed`),
  KEY `order_num` (`order_num`),
  KEY `hidden` (`hidden`),
  KEY `highlighted` (`highlighted`),
  KEY `commented` (`commented`),
  KEY `template` (`template`)
) ENGINE=MyISAM AUTO_INCREMENT=256 DEFAULT CHARSET=utf8;

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА countries: содержимое
--
-- ----------------------------------------------------------------------------

INSERT INTO `countries` VALUES ('23', '1', 'belorussia', '', '', '', 'Белоруссия', '', '', '', '', '', '', '', '', '2011-11-07 16:32:47', '0000-00-00 00:00:00', '0', '9998', '0', '0', '1', '0', '');
INSERT INTO `countries` VALUES ('139', '1', 'moldova', '', '', '', 'Молдавия', '', '', '', '', '', '', '', '', '2011-11-07 16:32:51', '0000-00-00 00:00:00', '0', '139', '0', '0', '1', '0', '');
INSERT INTO `countries` VALUES ('174', '1', 'russia', '', '', '', 'Россия', '', '', '', '', '', '', '', '', '2011-11-07 16:32:51', '0000-00-00 00:00:00', '0', '9999', '0', '0', '1', '0', '');
INSERT INTO `countries` VALUES ('223', '1', 'ukraine', '', '', '', 'Украина', '', '', '', '', '', '', '', '', '2011-11-07 16:32:51', '0000-00-00 00:00:00', '0', '10000', '0', '0', '1', '0', '');

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА coupons: структура
--
-- ----------------------------------------------------------------------------

DROP TABLE IF EXISTS `coupons`;

CREATE TABLE `coupons` (
  `coupon_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'Идентификатор купона',
  `name` varchar(256) NOT NULL DEFAULT '' COMMENT 'Название купона',
  `code` varchar(32) NOT NULL DEFAULT '' COMMENT 'Контрольный код',
  `discount` float(5,2) NOT NULL DEFAULT '0.00' COMMENT 'Процент разовой скидки',
  `group_id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Идентификатор назначаемой группы скидок',
  `price_id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Идентификатор назначаемой ценовой группы',
  `affiliate_id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Идентификатор назначаемого партнера',
  `user_id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Идентификатор погасившего пользователя',
  `order_id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Идентификатор погасившего заказа',
  `enabled` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'Признак Запись разрешена',
  `deleted` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Признак Запись удалена',
  `lifetime` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Срок действия в секундах',
  `discharged` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Дата погашения',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Дата создания записи',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Дата изменения записи',
  `printer` int(11) unsigned NOT NULL DEFAULT '1' COMMENT 'Номер печатной формы',
  `count` int(11) unsigned NOT NULL DEFAULT '1' COMMENT 'Остаток разов использования',
  `email` varchar(64) NOT NULL DEFAULT '' COMMENT 'Емейл для уведомлений по активности',
  `phone` varchar(64) NOT NULL DEFAULT '' COMMENT 'Телефон для SMS-уведомлений по активности',
  PRIMARY KEY (`coupon_id`),
  KEY `name` (`name`),
  KEY `code` (`code`),
  KEY `discount` (`discount`),
  KEY `group_id` (`group_id`),
  KEY `price_id` (`price_id`),
  KEY `affiliate_id` (`affiliate_id`),
  KEY `user_id` (`user_id`),
  KEY `order_id` (`order_id`),
  KEY `enabled` (`enabled`),
  KEY `deleted` (`deleted`),
  KEY `lifetime` (`lifetime`),
  KEY `discharged` (`discharged`),
  KEY `created` (`created`),
  KEY `modified` (`modified`),
  KEY `printer` (`printer`),
  KEY `count` (`count`),
  KEY `email` (`email`),
  KEY `phone` (`phone`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА coupons: содержимое
--
-- ----------------------------------------------------------------------------


-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА credit_programs: структура
--
-- ----------------------------------------------------------------------------

DROP TABLE IF EXISTS `credit_programs`;

CREATE TABLE `credit_programs` (
  `credit_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'Идентификатор кредитной программы',
  `name` varchar(64) NOT NULL DEFAULT '' COMMENT 'Название кредитной программы',
  `term` int(11) unsigned NOT NULL DEFAULT '12' COMMENT 'Срок кредитования',
  `percent` float(5,2) NOT NULL DEFAULT '36.00' COMMENT 'Процентная ставка',
  `form_fields` mediumtext NOT NULL COMMENT 'Пакет запрашиваемых данных',
  `enabled` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'Признак Запись разрешена',
  `deleted` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Признак Запись удалена',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Дата создания записи',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Дата изменения записи',
  `order_num` int(11) NOT NULL DEFAULT '0' COMMENT 'Вес записи среди прочих',
  `minimal_sum` float(17,6) NOT NULL DEFAULT '0.000000' COMMENT 'Минимальная сумма заказа',
  `maximal_sum` float(17,6) NOT NULL DEFAULT '0.000000' COMMENT 'Максимальная сумма заказа',
  `description` text NOT NULL COMMENT 'Описание кредитной программы',
  PRIMARY KEY (`credit_id`),
  KEY `name` (`name`),
  KEY `term` (`term`),
  KEY `percent` (`percent`),
  KEY `enabled` (`enabled`),
  KEY `deleted` (`deleted`),
  KEY `created` (`created`),
  KEY `modified` (`modified`),
  KEY `order_num` (`order_num`),
  KEY `minimal_sum` (`minimal_sum`),
  KEY `maximal_sum` (`maximal_sum`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА credit_programs: содержимое
--
-- ----------------------------------------------------------------------------

INSERT INTO `credit_programs` VALUES ('1', 'На год по 1% в месяц', '12', '12.00', 'a:33:{i:0;a:3:{s:5:\"field\";s:25:\"ФИО полностью\";s:4:\"type\";i:1;s:8:\"required\";b:1;}i:1;a:3:{s:5:\"field\";s:25:\"Дата рождения\";s:4:\"type\";i:3;s:8:\"required\";b:1;}i:2;a:3:{s:5:\"field\";s:50:\"Идентификационный код (ИНН)\";s:4:\"type\";i:4;s:8:\"required\";b:1;}i:3;s:33:\"Паспортные данные\";i:4;a:3:{s:5:\"field\";s:37:\"Паспорт серия, номер\";s:4:\"type\";i:1;s:8:\"required\";b:1;}i:5;a:3:{s:5:\"field\";s:17:\"Кем выдан\";s:4:\"type\";i:1;s:8:\"required\";b:1;}i:6;a:3:{s:5:\"field\";s:21:\"Когда выдан\";s:4:\"type\";i:3;s:8:\"required\";b:1;}i:7;a:3:{s:5:\"field\";s:33:\"Адрес регистрации\";s:4:\"type\";i:1;s:8:\"required\";b:1;}i:8;s:33:\"Адресные сведения\";i:9;a:3:{s:5:\"field\";s:42:\"Адрес места проживания\";s:4:\"type\";i:1;s:8:\"required\";b:1;}i:10;a:3:{s:5:\"field\";s:29:\"Почтовый индекс\";s:4:\"type\";i:4;s:8:\"required\";b:1;}i:11;a:3:{s:5:\"field\";s:31:\"Домашний телефон\";s:4:\"type\";i:5;s:8:\"required\";b:0;}i:12;a:3:{s:5:\"field\";s:33:\"Мобильный телефон\";s:4:\"type\";i:5;s:8:\"required\";b:1;}i:13;a:3:{s:5:\"field\";s:33:\"Электронная почта\";s:4:\"type\";i:6;s:8:\"required\";b:0;}i:14;s:49:\"Образование и место работы\";i:15;a:3:{s:5:\"field\";s:22:\"Образование\";s:4:\"type\";i:1;s:8:\"required\";b:1;}i:16;a:3:{s:5:\"field\";s:67:\"Какое учебное заведение заканчивали\";s:4:\"type\";i:1;s:8:\"required\";b:1;}i:17;a:3:{s:5:\"field\";s:23:\"Место работы\";s:4:\"type\";i:1;s:8:\"required\";b:1;}i:18;a:3:{s:5:\"field\";s:29:\"Рабочий телефон\";s:4:\"type\";i:5;s:8:\"required\";b:1;}i:19;a:3:{s:5:\"field\";s:23:\"Адрес работы\";s:4:\"type\";i:1;s:8:\"required\";b:1;}i:20;a:3:{s:5:\"field\";s:18:\"Должность\";s:4:\"type\";i:1;s:8:\"required\";b:1;}i:21;s:35:\"Семейное положение\";i:22;a:3:{s:5:\"field\";s:35:\"Семейное положение\";s:4:\"type\";i:1;s:8:\"required\";b:1;}i:23;a:3:{s:5:\"field\";s:31:\"Количество детей\";s:4:\"type\";i:4;s:8:\"required\";b:1;}i:24;a:3:{s:5:\"field\";s:25:\"Возраст детей\";s:4:\"type\";i:1;s:8:\"required\";b:0;}i:25;a:3:{s:5:\"field\";s:67:\"Количество людей, проживающих с Вами\";s:4:\"type\";i:4;s:8:\"required\";b:1;}i:26;a:3:{s:5:\"field\";s:52:\"Комментарий (не обязательно)\";s:4:\"type\";i:2;s:8:\"required\";b:0;}i:27;s:20:\"Приложения\";i:28;a:3:{s:5:\"field\";s:55:\"Приложить скан копию паспорта\";s:4:\"type\";i:8;s:8:\"required\";b:1;}i:29;a:3:{s:5:\"field\";s:74:\"..... скан копия паспорта (вторая страница)\";s:4:\"type\";i:8;s:8:\"required\";b:0;}i:30;a:3:{s:5:\"field\";s:61:\"..... скан копия паспорта (прописка)\";s:4:\"type\";i:8;s:8:\"required\";b:0;}i:31;a:3:{s:5:\"field\";s:45:\"Приложить скан копию ИНН\";s:4:\"type\";i:8;s:8:\"required\";b:1;}i:32;a:3:{s:5:\"field\";s:52:\"Приложить личную фотографию\";s:4:\"type\";i:8;s:8:\"required\";b:1;}}', '0', '0', '2014-11-12 16:33:21', '2014-11-12 16:33:21', '0', '0.000000', '0.000000', '');

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА currencies: структура
--
-- ----------------------------------------------------------------------------

DROP TABLE IF EXISTS `currencies`;

CREATE TABLE `currencies` (
  `currency_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'Идентификатор валюты',
  `main` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Признак Базовая валюта',
  `def` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Признак Выбрана по умолчанию для клиентской стороны',
  `name` varchar(32) NOT NULL DEFAULT '' COMMENT 'Название валюты',
  `sign` varchar(32) NOT NULL DEFAULT '' COMMENT 'Надпись валюты',
  `code` varchar(3) NOT NULL DEFAULT '' COMMENT 'ISO код валюты',
  `rate_from` float(12,4) NOT NULL DEFAULT '1.0000' COMMENT 'Курс (за единицу базовой валюты)',
  `rate_to` float(12,4) NOT NULL DEFAULT '1.0000' COMMENT 'Обратный курс (сколько единиц базовой валюты)',
  `defa` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Признак Выбрана по умолчанию для админпанели',
  `enabled` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'Признак Запись разрешена',
  `ymarket` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Признак Выбрана для Яндекс.Маркет',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Дата создания записи',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Дата изменения записи',
  `order_num` int(11) NOT NULL DEFAULT '0' COMMENT 'Вес записи среди прочих в ветке',
  `deleted` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Признак Запись удалена',
  PRIMARY KEY (`currency_id`),
  KEY `main` (`main`),
  KEY `def` (`def`),
  KEY `defa` (`defa`),
  KEY `name` (`name`),
  KEY `sign` (`sign`),
  KEY `code` (`code`),
  KEY `enabled` (`enabled`),
  KEY `ymarket` (`ymarket`),
  KEY `created` (`created`),
  KEY `modified` (`modified`),
  KEY `order_num` (`order_num`),
  KEY `deleted` (`deleted`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА currencies: содержимое
--
-- ----------------------------------------------------------------------------

INSERT INTO `currencies` VALUES ('1', '0', '0', 'рубли', 'руб', 'RUR', '1.0000', '0.3333', '0', '1', '0', '2014-11-12 16:42:33', '2015-02-02 13:57:07', '0', '0');
INSERT INTO `currencies` VALUES ('2', '0', '0', 'доллары', 'usd', 'USD', '1.0000', '20.0000', '0', '1', '0', '2014-11-12 16:43:21', '2015-02-02 13:56:38', '0', '0');
INSERT INTO `currencies` VALUES ('3', '1', '1', 'гривны', 'грн', 'UAH', '1.0000', '1.0000', '1', '1', '0', '2014-11-12 16:43:45', '2015-02-02 13:56:29', '0', '0');

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА deliveries_types: структура
--
-- ----------------------------------------------------------------------------

DROP TABLE IF EXISTS `deliveries_types`;

CREATE TABLE `deliveries_types` (
  `type_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'Идентификатор типа доставки',
  `name` varchar(256) NOT NULL DEFAULT '' COMMENT 'Название типа доставки',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Дата создания записи',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Дата изменения записи',
  PRIMARY KEY (`type_id`),
  KEY `name` (`name`),
  KEY `created` (`created`),
  KEY `modified` (`modified`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА deliveries_types: содержимое
--
-- ----------------------------------------------------------------------------

INSERT INTO `deliveries_types` VALUES ('2', 'Частями по мере сборки заказа', '2014-11-10 06:36:35', '2014-11-10 06:36:35');
INSERT INTO `deliveries_types` VALUES ('3', 'Весь заказ в одной посылке', '2014-11-10 06:39:21', '2014-11-10 06:39:21');
INSERT INTO `deliveries_types` VALUES ('4', 'Габаритный - перевозчиком, документы и мелочевка - курьером сразу', '2014-11-10 06:40:56', '2014-11-10 06:40:56');

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА delivery_methods: структура
--
-- ----------------------------------------------------------------------------

DROP TABLE IF EXISTS `delivery_methods`;

CREATE TABLE `delivery_methods` (
  `delivery_method_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `free_from` float(10,2) NOT NULL,
  `price` float(10,2) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '0',
  `undelivery_category_ids` text NOT NULL,
  `order_num` int(11) NOT NULL DEFAULT '0',
  `discount` float(5,2) NOT NULL DEFAULT '-1.00' COMMENT 'Скидка на споособ доставки',
  `types_ids` text NOT NULL COMMENT 'Идентификаторы типов доставки',
  `tracking_url` varchar(1024) NOT NULL DEFAULT '' COMMENT 'Адрес страницы отслеживания посылки',
  `require_address` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'Требует ли заполнения адреса доставки',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Дата создания записи',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Дата изменения записи',
  PRIMARY KEY (`delivery_method_id`),
  KEY `order_num` (`order_num`),
  KEY `require_address` (`require_address`),
  KEY `created` (`created`),
  KEY `modified` (`modified`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА delivery_methods: содержимое
--
-- ----------------------------------------------------------------------------

INSERT INTO `delivery_methods` VALUES ('1', 'Самовывоз', '<p>Вы сможете забрать заказ своим транспортом в нашем пункте выдачи заказов. Адрес пункта: Москва, ул. Примерная, дом 1, офис 2.</p>', '0.00', '0.00', '1', '', '0', '-1.00', '', '', '0', '2014-11-12 16:46:02', '2014-11-12 16:46:02');
INSERT INTO `delivery_methods` VALUES ('2', 'Доставка курьером', '<p>Доставка возможна только в пределах города. Обязательно убедитесь, что правильно указали свой адрес во время оформления заказа.</p>', '25000.00', '250.00', '1', '', '0', '-1.00', '2,4', '', '1', '2014-11-12 16:48:19', '2014-11-12 16:48:19');

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА delivery_payment: структура
--
-- ----------------------------------------------------------------------------

DROP TABLE IF EXISTS `delivery_payment`;

CREATE TABLE `delivery_payment` (
  `delivery_method_id` int(11) NOT NULL,
  `payment_method_id` int(11) NOT NULL,
  PRIMARY KEY (`delivery_method_id`,`payment_method_id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 COMMENT='Связка способов оплаты и способов доставки';

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА delivery_payment: содержимое
--
-- ----------------------------------------------------------------------------

INSERT INTO `delivery_payment` VALUES ('1', '1');
INSERT INTO `delivery_payment` VALUES ('1', '2');
INSERT INTO `delivery_payment` VALUES ('1', '3');
INSERT INTO `delivery_payment` VALUES ('1', '4');
INSERT INTO `delivery_payment` VALUES ('2', '1');
INSERT INTO `delivery_payment` VALUES ('2', '2');
INSERT INTO `delivery_payment` VALUES ('2', '3');
INSERT INTO `delivery_payment` VALUES ('2', '4');

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА feedback: структура
--
-- ----------------------------------------------------------------------------

DROP TABLE IF EXISTS `feedback`;

CREATE TABLE `feedback` (
  `feedback_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'Идентификатор сообщения',
  `date` datetime NOT NULL,
  `ip` varchar(256) NOT NULL DEFAULT '' COMMENT 'IP-адрес получателя во время написания',
  `name` varchar(256) NOT NULL DEFAULT '' COMMENT 'Имя отправителя',
  `email` varchar(256) NOT NULL DEFAULT '' COMMENT 'Емейл отправителя',
  `message` text NOT NULL,
  `from_user` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Идентификатор писавшего пользователя',
  `to_user` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Идентификатор получающего пользователя',
  `new` tinyint(1) NOT NULL DEFAULT '1',
  `parent_id` bigint(20) NOT NULL DEFAULT '0',
  `department` varchar(256) NOT NULL DEFAULT '' COMMENT 'Департамент',
  `subject` varchar(256) NOT NULL DEFAULT '' COMMENT 'Тема',
  `phone` varchar(256) NOT NULL DEFAULT '' COMMENT 'Телефон',
  PRIMARY KEY (`feedback_id`),
  KEY `parent_id` (`parent_id`),
  KEY `name` (`name`),
  KEY `email` (`email`),
  KEY `new` (`new`),
  KEY `from_user` (`from_user`),
  KEY `to_user` (`to_user`),
  KEY `ip` (`ip`),
  KEY `date` (`date`),
  KEY `department` (`department`),
  KEY `subject` (`subject`),
  KEY `phone` (`phone`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА feedback: содержимое
--
-- ----------------------------------------------------------------------------


-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА files: структура
--
-- ----------------------------------------------------------------------------

DROP TABLE IF EXISTS `files`;

CREATE TABLE `files` (
  `file_id` int(11) NOT NULL AUTO_INCREMENT,
  `menu_id` int(11) NOT NULL DEFAULT '0',
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `hidden` tinyint(1) NOT NULL DEFAULT '0',
  `url` varchar(256) NOT NULL DEFAULT '',
  `meta_title` varchar(256) NOT NULL DEFAULT '',
  `meta_keywords` varchar(512) NOT NULL DEFAULT '',
  `meta_description` varchar(512) NOT NULL DEFAULT '',
  `name` varchar(256) NOT NULL DEFAULT '',
  `header` varchar(512) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `seo_description` text NOT NULL,
  `files` text NOT NULL,
  `files_alts` text NOT NULL,
  `files_texts` longtext NOT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `browsed` int(11) NOT NULL DEFAULT '0',
  `order_num` int(11) NOT NULL DEFAULT '0',
  `section` int(11) NOT NULL DEFAULT '1',
  `tags` varchar(256) NOT NULL DEFAULT '' COMMENT 'Теги записи',
  PRIMARY KEY (`file_id`),
  KEY `menu_id` (`menu_id`),
  KEY `enabled` (`enabled`),
  KEY `hidden` (`hidden`),
  KEY `url` (`url`),
  KEY `browsed` (`browsed`),
  KEY `order_num` (`order_num`),
  KEY `tags` (`tags`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА files: содержимое
--
-- ----------------------------------------------------------------------------


-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА groups: структура
--
-- ----------------------------------------------------------------------------

DROP TABLE IF EXISTS `groups`;

CREATE TABLE `groups` (
  `group_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'Идентификатор группы',
  `name` varchar(256) NOT NULL DEFAULT '' COMMENT 'Название группы',
  `discount` float(5,2) NOT NULL DEFAULT '0.00',
  `next_group_id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Идентификатор следующей группы',
  `next_group_sum` float(17,6) NOT NULL DEFAULT '0.000000' COMMENT 'Необходимая сумма заказов для перехода в следующую группу',
  `next_group_orders` int(11) NOT NULL DEFAULT '0',
  `next_group_products` int(11) NOT NULL DEFAULT '0',
  `next_group_condition` tinyint(1) NOT NULL DEFAULT '0',
  `next_group_condition2` tinyint(1) NOT NULL DEFAULT '0',
  `from_sum` float(17,6) NOT NULL DEFAULT '0.000000' COMMENT 'От какой суммы действует',
  `authorized` tinyint(1) NOT NULL DEFAULT '1',
  `auto_assign` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Признак Автоматически назначаемая зарегистрировавшемуся пользователю',
  `enabled` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'Признак Запись разрешена',
  `deleted` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Признак Запись удалена',
  PRIMARY KEY (`group_id`),
  KEY `next_group_id` (`next_group_id`),
  KEY `name` (`name`(255)),
  KEY `discount` (`discount`),
  KEY `from_sum` (`from_sum`),
  KEY `authorized` (`authorized`),
  KEY `auto_assign` (`auto_assign`),
  KEY `next_group_sum` (`next_group_sum`),
  KEY `next_group_orders` (`next_group_orders`),
  KEY `next_group_products` (`next_group_products`),
  KEY `next_group_condition` (`next_group_condition`),
  KEY `next_group_condition2` (`next_group_condition2`),
  KEY `enabled` (`enabled`),
  KEY `deleted` (`deleted`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА groups: содержимое
--
-- ----------------------------------------------------------------------------


-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА imports: структура
--
-- ----------------------------------------------------------------------------

DROP TABLE IF EXISTS `imports`;

CREATE TABLE `imports` (
  `import_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'Идентификатор варианта импорта',
  `name` varchar(256) NOT NULL DEFAULT '',
  `delimiter` varchar(16) NOT NULL DEFAULT '',
  `format` varchar(16) NOT NULL DEFAULT '',
  `columns` text NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `url` varchar(256) NOT NULL DEFAULT '',
  `password` varchar(256) NOT NULL DEFAULT '',
  `automatic` tinyint(1) NOT NULL DEFAULT '0',
  `filename` varchar(256) NOT NULL DEFAULT '',
  `lifetime` int(11) NOT NULL DEFAULT '86400',
  `before_action` int(11) NOT NULL DEFAULT '0',
  `marketing_update` tinyint(1) NOT NULL DEFAULT '0',
  `financial_update` tinyint(1) NOT NULL DEFAULT '0',
  `history` text NOT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `lastused` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `busy` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`import_id`),
  KEY `enabled` (`enabled`),
  KEY `url` (`url`),
  KEY `automatic` (`automatic`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА imports: содержимое
--
-- ----------------------------------------------------------------------------

INSERT INTO `imports` VALUES ('1', 'Импорт товаров из CSV-файла (с очисткой базы от прежних товаров)', ';', 'csv', 'category, brand, pcode, variant, model, price, quantity, discount [* : -1], annotation, description, images, video, tags, property, property2, property3, property4, property5, property6', '1', '', 'cqymnwVacC', '0', '', '86400', '2', '0', '0', '13.11.2014 00:01:16 - РЕЗУЛЬТАТ (заняло 1257 секунд)\r\n        ТОВАРЫ\r\n            добавлено = 4274\r\n            обновлено = 3232\r\n            неизменившихся = 5980\r\n        ВАРИАНТЫ ТОВАРОВ\r\n            добавлено = 7347\r\n            обновлено = 6139\r\n        КАТЕГОРИИ\r\n            добавлено = 79\r\n\r\n\r\n12.11.2014 23:40:19 - (ручной запуск с IP-адреса 95.211.220.155)\r\n        начат процесс импорта из файла', '2014-11-12 20:50:05', '2014-11-12 23:40:19', '0');
INSERT INTO `imports` VALUES ('2', 'Для очистки базы товаров с помощью пустого CSV-файла', ';', 'csv', 'productId, model', '1', '', 'Hc6nJNr9l3', '0', '', '86400', '2', '0', '0', '21.02.2015 21:23:05 - РЕЗУЛЬТАТ (заняло 0 секунд)\r\n\r\n\r\n21.02.2015 21:23:05 - (ручной запуск с IP-адреса 91.214.82.66)\r\n        начат процесс импорта из файла\r\n\r\n21.02.2015 21:22:22 - РЕЗУЛЬТАТ (заняло 0 секунд)\r\n\r\n\r\n21.02.2015 21:22:22 - (ручной запуск с IP-адреса 91.214.82.66)\r\n        начат процесс импорта из файла\r\n\r\n21.02.2015 21:20:36 - РЕЗУЛЬТАТ (заняло 0 секунд)\r\n\r\n\r\n21.02.2015 21:20:36 - (ручной запуск с IP-адреса 91.214.82.66)\r\n        начат процесс импорта из файла', '2015-02-03 19:29:08', '2015-02-21 21:23:05', '0');

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА menu: структура
--
-- ----------------------------------------------------------------------------

DROP TABLE IF EXISTS `menu`;

CREATE TABLE `menu` (
  `menu_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'Идентификатор меню',
  `name` varchar(256) NOT NULL DEFAULT '' COMMENT 'Название меню',
  `fixed` tinyint(1) DEFAULT '0',
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `hidden` tinyint(1) NOT NULL DEFAULT '0',
  `restarter` int(11) NOT NULL DEFAULT '1424555189' COMMENT 'Рестартер контроля таблиц',
  `versifier` int(11) NOT NULL DEFAULT '150215' COMMENT 'Версификатор контроля таблиц',
  PRIMARY KEY (`menu_id`),
  KEY `enabled` (`enabled`),
  KEY `hidden` (`hidden`),
  KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА menu: содержимое
--
-- ----------------------------------------------------------------------------

INSERT INTO `menu` VALUES ('1', 'Абстрактное меню', '0', '0', '0', '1415883502', '141109');
INSERT INTO `menu` VALUES ('2', 'Верхнее меню', '0', '1', '0', '1415883502', '141109');

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА modules: структура
--
-- ----------------------------------------------------------------------------

DROP TABLE IF EXISTS `modules`;

CREATE TABLE `modules` (
  `module_id` int(11) NOT NULL AUTO_INCREMENT,
  `class` varchar(255) NOT NULL DEFAULT '',
  `name` varchar(255) NOT NULL DEFAULT '',
  `valuable` tinyint(1) NOT NULL DEFAULT '0',
  `filename` varchar(255) NOT NULL DEFAULT '',
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `plugin` tinyint(1) NOT NULL DEFAULT '0',
  `description` varchar(8192) NOT NULL DEFAULT '',
  PRIMARY KEY (`module_id`),
  KEY `enabled` (`enabled`),
  KEY `plugin` (`plugin`)
) ENGINE=MyISAM AUTO_INCREMENT=40 DEFAULT CHARSET=utf8;

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА modules: содержимое
--
-- ----------------------------------------------------------------------------

INSERT INTO `modules` VALUES ('1', 'StaticPage', 'Статическая страница', '1', '', '1', '0', '');
INSERT INTO `modules` VALUES ('3', 'News', 'Лента новостей', '1', '', '1', '0', '');
INSERT INTO `modules` VALUES ('4', 'Catalog', 'Каталог товаров', '1', '', '1', '0', '');
INSERT INTO `modules` VALUES ('5', 'Articles', 'Статьи', '1', '', '0', '0', '');
INSERT INTO `modules` VALUES ('6', 'Search', 'Поиск', '0', '', '0', '0', '');
INSERT INTO `modules` VALUES ('7', 'Cart', 'Корзина', '0', '', '1', '0', '');
INSERT INTO `modules` VALUES ('8', 'Login', 'Вход для пользователей', '1', '', '1', '0', '');
INSERT INTO `modules` VALUES ('9', 'Registration', 'Регистрация пользователя', '1', '', '1', '0', '');
INSERT INTO `modules` VALUES ('12', 'Account', 'Аккаунт пользователя', '0', '', '1', '0', '');
INSERT INTO `modules` VALUES ('11', 'Order', 'Оформление заказа', '0', '', '1', '0', '');
INSERT INTO `modules` VALUES ('13', 'Pricelist', 'Прайс-лист', '1', '', '0', '0', '');
INSERT INTO `modules` VALUES ('14', 'Sitemap', 'Карта сайта', '1', '', '0', '0', '');
INSERT INTO `modules` VALUES ('10', 'Feedback', 'Обратная связь', '1', '', '1', '0', '');
INSERT INTO `modules` VALUES ('15', 'Compare', 'Сравнение товаров', '0', '', '0', '0', '');
INSERT INTO `modules` VALUES ('16', 'RSS', 'RSS', '0', '', '0', '0', '');
INSERT INTO `modules` VALUES ('17', 'Import', 'Мульти прайсовый импорт', '0', '', '0', '0', '');
INSERT INTO `modules` VALUES ('18', 'Configurator', 'Конфигуратор', '1', '', '0', '0', '');
INSERT INTO `modules` VALUES ('20', 'Stocks', 'Модуль складов', '1', '', '0', '0', '');
INSERT INTO `modules` VALUES ('21', 'Files', 'Модуль медиа файлов', '1', '', '0', '0', '');
INSERT INTO `modules` VALUES ('22', 'ProductsKits', 'Комплекты товаров', '1', '', '0', '0', 'Модуль формирует список комплектов товаров и страницы комплектов.');
INSERT INTO `modules` VALUES ('23', 'CallMe', 'Позвоните мне', '0', '', '0', '0', 'Модуль обеспечивает прием запросов связи от пользователей сайта.');
INSERT INTO `modules` VALUES ('24', 'NotifyMe', 'Уведомите меня', '0', '', '0', '0', 'Модуль обеспечивает подключение пользователей сайта к системе уведомлений о новинках сайта, появлении товара в наличии, слежении за товаром.');
INSERT INTO `modules` VALUES ('25', 'FulminantOrder', 'Мгновенный заказ', '0', '', '0', '0', 'Модуль обеспечивает прием от пользователя мгновенного заказа (покупка единственного товара без укладывания в корзину).');
INSERT INTO `modules` VALUES ('26', 'Logout', 'Выход пользователя', '1', '', '1', '0', 'Модуль выхода пользователя из состояния авторизации.');
INSERT INTO `modules` VALUES ('27', 'LoginRemind', 'Забыли пароль?', '1', '', '1', '0', 'Модуль восстановления пароля входа на сайт.');
INSERT INTO `modules` VALUES ('29', 'Products', 'Список товаров', '1', '', '1', '0', 'Модуль формирует страницу списка товаров.');
INSERT INTO `modules` VALUES ('30', 'Product', 'Страница товара', '0', '', '1', '0', 'Модуль формирует страницу товара.');
INSERT INTO `modules` VALUES ('31', 'ProductsKit', 'Страница комплекта товаров', '0', '', '0', '0', 'Модуль формирует страницу комплекта товаров.');
INSERT INTO `modules` VALUES ('32', 'Countries', 'Список стран', '1', '', '0', '0', 'Модуль формирует страницу списка стран.');
INSERT INTO `modules` VALUES ('33', 'Country', 'Страница страны', '0', '', '0', '0', 'Модуль формирует страницу страны.');
INSERT INTO `modules` VALUES ('34', 'Regions', 'Список областей', '1', '', '0', '0', 'Модуль формирует страницу списка областей.');
INSERT INTO `modules` VALUES ('35', 'Region', 'Страница области', '0', '', '0', '0', 'Модуль формирует страницу области.');
INSERT INTO `modules` VALUES ('36', 'Towns', 'Список городов', '1', '', '0', '0', 'Модуль формирует страницу списка городов.');
INSERT INTO `modules` VALUES ('37', 'Town', 'Страница города', '0', '', '0', '0', 'Модуль формирует страницу города.');
INSERT INTO `modules` VALUES ('38', 'NewsItem', 'Страница новости', '0', '', '1', '0', 'Модуль формирует страницу новости.');
INSERT INTO `modules` VALUES ('39', 'Stock', 'Страница склада', '0', '', '0', '0', 'Модуль формирует страницу склада.');

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА news: структура
--
-- ----------------------------------------------------------------------------

DROP TABLE IF EXISTS `news`;

CREATE TABLE `news` (
  `news_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'Идентификатор записи',
  `header` varchar(256) NOT NULL DEFAULT '' COMMENT 'Название (заголовок)',
  `url` varchar(256) NOT NULL DEFAULT '' COMMENT 'Адрес страницы',
  `date` date NOT NULL DEFAULT '0000-00-00',
  `meta_title` varchar(256) NOT NULL DEFAULT '' COMMENT 'Мета заголовок',
  `meta_keywords` varchar(512) NOT NULL DEFAULT '' COMMENT 'Мета ключевые слова',
  `meta_description` varchar(512) NOT NULL DEFAULT '' COMMENT 'Мета описание',
  `annotation` text NOT NULL,
  `body` text NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `section` int(11) NOT NULL DEFAULT '1',
  `menu_id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Идентификатор меню',
  `objects` varchar(512) NOT NULL DEFAULT '',
  `category_id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Идентификатор категории',
  `brand_id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Идентификатор бренда',
  `user_id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Идентификатор пользователя',
  `listed` tinyint(1) NOT NULL DEFAULT '1',
  `commented` tinyint(1) NOT NULL DEFAULT '1',
  `hidden` tinyint(1) NOT NULL DEFAULT '0',
  `rss_disabled` tinyint(1) NOT NULL DEFAULT '0',
  `export_disabled` tinyint(1) NOT NULL DEFAULT '0',
  `url_special` tinyint(1) NOT NULL DEFAULT '0',
  `images` text NOT NULL,
  `images_alts` text NOT NULL,
  `images_texts` longtext NOT NULL,
  `browsed` int(11) NOT NULL DEFAULT '0',
  `order_num` int(11) NOT NULL DEFAULT '0',
  `images_view` text NOT NULL,
  `seo_description` text NOT NULL,
  `rating` float(12,2) NOT NULL DEFAULT '0.00',
  `votes` int(11) NOT NULL DEFAULT '0',
  `highlighted` tinyint(1) NOT NULL DEFAULT '0',
  `tags` varchar(256) NOT NULL DEFAULT '' COMMENT 'Теги записи',
  `template` varchar(256) NOT NULL DEFAULT '' COMMENT 'Нестандартный шаблон для отображения',
  PRIMARY KEY (`news_id`),
  KEY `url` (`url`),
  KEY `enabled` (`enabled`),
  KEY `menu_id` (`menu_id`),
  KEY `category_id` (`category_id`),
  KEY `brand_id` (`brand_id`),
  KEY `user_id` (`user_id`),
  KEY `hidden` (`hidden`),
  KEY `rss_disabled` (`rss_disabled`),
  KEY `export_disabled` (`export_disabled`),
  KEY `browsed` (`browsed`),
  KEY `order_num` (`order_num`),
  KEY `votes` (`votes`),
  KEY `highlighted` (`highlighted`),
  KEY `tags` (`tags`),
  KEY `header` (`header`),
  KEY `listed` (`listed`),
  KEY `commented` (`commented`),
  KEY `template` (`template`),
  KEY `rating` (`rating`),
  KEY `date` (`date`),
  KEY `created` (`created`),
  KEY `modified` (`modified`),
  KEY `section` (`section`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА news: содержимое
--
-- ----------------------------------------------------------------------------

INSERT INTO `news` VALUES ('1', 'Повседневные платья оптом', 'blog/povsednevnye-platya-optom', '2014-03-11', 'Повседневные платья оптом', 'платья, опт', 'Наш магазин реализует повседневные платья оптом. Если вы тоже в этом бизнесе, имеете свой магазин, секцию в супермаркете или батискаф на рынке, поделимся полезной информацией.', '<p>Сколько людей, столько и мнений, но бизнесмены &mdash; это особая категория людей. Они хотят и умеют открывать перед обществом новые возможности, улучшать его жизнь. Они думают о потребителях, не только о себе.</p>', '<p>Сколько людей, столько и мнений, но бизнесмены &mdash; это особая категория людей. Они хотят и умеют открывать перед обществом новые возможности, улучшать его жизнь. Они думают о потребителях, не только о себе.</p><p>&nbsp;</p><p>Наш магазин реализует повседневные платья оптом. Если вы тоже в этом бизнесе, имеете свой магазин, секцию в супермаркете или батискаф на рынке, поделимся полезной информацией. Конечно, вы сможете ее получить и без нашей помощи, но как часто это бывает, золото лежит под ногами, достаточно наклониться и поднять.</p><p>&nbsp;</p><ul><li>Модели в каталоге полноразмерные, трикотаж хорошо тянется. Советов по размерам мы не даем, потому как у каждой женщины своя фигура и вкусы относительно того, как должно сидеть платье.</li><li>Ткани качественные &mdash; прямо струятся по фигуре, нежные, приятные к телу; цвета на любой вкус, соответствуют фотографиям, а в живую даже красивее, чем на фото.</li><li>Повседневные платья продаем оптом, недорого. И самые дешевые, и дорогие подчеркивают фигуру, скрывают &laquo;животик&raquo;, когда это нужно и задумано изначально.</li></ul><p>&nbsp;</p><p>Сейчас, уважаемый посетитель, ответь на главный вопрос. Если ты, конечно, занимаешься нашим общим бизнесом: - Сколько единиц товара можно продать одному покупателя? При условии, что он доволен первой покупкой и место в платяном шкафу есть...</p><p>&nbsp;</p><p>Женщины, которые носят наши вещи, говорят по-разному. Одни признаются, что имеют пару платьев, а хотелось бы десять, но нет денег. Другие покупают 3-4, но разных цветов &mdash; черного, бежевого, розового. Третьи хвалятся, у них штук 15 повседневных, не считая вечерних, так что муж скоро на улицу выгонит. Четвертые успевают часть гардероба продать через интернет, остается много, а одеть все равно нечего.</p><p>&nbsp;</p><p>Были у нас и другие ответы. Например, что одевают только одно, а остальные &mdash; новые и дорогие, тупо висят. Или одевают их в гости, погулять, в кино, а для работы &mdash; ни одного. Или имеют на холодное время парочку поплотнее, на лето &mdash; еще парочку с рюшками. Осенью в ход идут джинсы или кардиганы, со всякими шарфиками/платочками сверху.</p><p>&nbsp;</p><p>Суть всех этих слов такова: пока женщина жива, у нее в гардеробе есть несколько платьев, она регулярно подбирает новые, даже если старые в идеальном состоянии. Мы всегда рады новым заказам, а вы покупайте повседневные платья оптом, и не волнуйтесь: - За ними будут возвращаться снова, только успевай ассортимент обновлять!</p>', '1', '2014-11-12 16:26:18', '2015-02-02 12:58:42', '1', '0', '', '0', '0', '0', '1', '0', '0', '0', '0', '1', '', '', '', '8', '1', '', '', '0.00', '0', '0', '', '');
INSERT INTO `news` VALUES ('2', 'Подростковая одежда оптом в Украине', 'blog/podrostkovaya-odezhda-optom-v-ukraine', '2014-02-27', 'Подростковая одежда оптом в Украине', 'подростковая, одежда, опт, Украина', 'Каждая компания-оптовик в блоге на сайте хоть немного, но себя похвалит. Как минимум, расскажет, что одежда произведена в Одессе, реализация - ростовками, минимальный заказ на сумму от 1000 гривен и такое всякое.', '<p>Каждая компания-оптовик в блоге на сайте хоть немного, но себя похвалит. Как минимум, расскажет, что одежда произведена в Одессе, реализация &mdash; ростовками, минимальный заказ на сумму от 1000 гривен и такое всякое.</p>', '<p>Каждая компания-оптовик в блоге на сайте хоть немного, но себя похвалит. Как минимум, расскажет, что одежда произведена в Одессе, реализация &mdash; ростовками, минимальный заказ на сумму от 1000 гривен и такое всякое.</p><p>&nbsp;</p><p>И лишь единицы готовы открыть тайну. Например, мы. О том, из чего шьем наряды или для кого работают наши сотрудники. Как предлагают купить оптом подростковую одежду, но когда приходит время одевать своих детей, разводят руками. Пошли в фирменный магазин, а там ассортимент маленький, оптовики разобрали... Расстроились. Раньше покупали все, что нужно и в одном месте:</p><p>&nbsp;</p><ul><li>широкий выбор цветов</li><li>все размеры</li><li>хорошее качество по доступной цене (своими руками делаем, для себя же стараемся!)</li></ul><p>&nbsp;</p><p>&nbsp;</p><p>А теперь непонятно, где банальный сарафан найти. Идешь в соседний батискаф, там тоже одежда для подростков на опт идет, в розницу не продают. А вдобавок с ядреными рисунками, зверюшками, а возраст не детский, для 5 класса не пойдет.</p><p>&nbsp;</p><p>Подростковая одежда оптом от производителя, как считают наши дизайнеры, и во многом они правы, должна подчеркивать быстро меняющуюся фигуру ребенка. Возраст 12-16 лет &mdash; время полового созревания. Девушки и парни хотят общаться со взрослыми на равных, а модели для сформировавшейся фигуры отличаются от моделей для подростков.</p><p>&nbsp;</p><p>В них они выглядят нелепо и смешно, неспроста дизайнеры целые коллекции создают для определенного возраста.</p><p>&nbsp;</p><p>Так вот, вернемся к вопросу преимуществ продукции в каталоге. Она пошита в Одессе, по меркам, снятым с украинских мальчиков и девочек, из качественных материалов. Продается ростовками по 2-3 штуки, естественно, по ценам производителя. Доставка возможна компаниями-перевозчиками в любую точку Украины.</p><p>&nbsp;</p><p>Немаловажен и факт, что подростковая одежда оптом, абсолютно вся, выдержана в духе &laquo;стиля&raquo;. Юные модники и модницы не опасаются улыбок своего окружения, вливаются в молодежное течение. Иногда даже чересчур &mdash; ткани и покрой качественные, поэтому сменять гардероб придется не по причине &laquo;ветхости&raquo;, а по причине скоротечности моды.</p><p>&nbsp;</p><p>Оптовые цены на подростковую одежду, качество, условия работы с магазинами и частными предпринимателями &mdash; вне конкуренции, &mdash; любят хвастаться сотрудники компаний. А когда дело доходит до покупок &laquo;себе&raquo;, &laquo;для своих&raquo;, разводят руками: &laquo;Бизнес есть бизнес, в рознице дороже&raquo;.</p>', '1', '2015-02-02 12:56:25', '2015-02-02 12:59:05', '1', '0', '', '0', '0', '0', '1', '0', '0', '0', '0', '1', '', '', '', '7', '2', '', '', '0.00', '0', '0', '', '');

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА news_comments: структура
--
-- ----------------------------------------------------------------------------

DROP TABLE IF EXISTS `news_comments`;

CREATE TABLE `news_comments` (
  `comment_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `parent_id` bigint(20) NOT NULL DEFAULT '0',
  `news_id` int(11) NOT NULL DEFAULT '0',
  `ip` varchar(32) NOT NULL DEFAULT '',
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `name` varchar(255) NOT NULL DEFAULT '',
  `comment` varchar(4096) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `from_user` int(11) NOT NULL DEFAULT '0',
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`comment_id`),
  KEY `parent_id` (`parent_id`),
  KEY `news_id` (`news_id`),
  KEY `from_user` (`from_user`),
  KEY `enabled` (`enabled`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА news_comments: содержимое
--
-- ----------------------------------------------------------------------------


-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА notifies: структура
--
-- ----------------------------------------------------------------------------

DROP TABLE IF EXISTS `notifies`;

CREATE TABLE `notifies` (
  `notify_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'Идентификатор подписки',
  `type` varchar(16) NOT NULL DEFAULT '' COMMENT 'Тип уведомления',
  `user_id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Идентификатор пользователя',
  `email` varchar(256) NOT NULL DEFAULT '' COMMENT 'Емейл получателя',
  `phone` varchar(256) NOT NULL DEFAULT '' COMMENT 'Телефон получателя',
  `icq` varchar(256) NOT NULL DEFAULT '' COMMENT 'ICQ номер получателя',
  `skype` varchar(256) NOT NULL DEFAULT '' COMMENT 'Skype имя получателя',
  `object_id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Идентификатор отслеживаемого объекта',
  `variant_id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Идентификатор варианта отслеживаемого объекта',
  `done` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Признак Выполнено ли уведомление',
  `enabled` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'Разрешена ли запись к использованию',
  `ip` varchar(256) NOT NULL DEFAULT '' COMMENT 'IP-адрес получателя во время заявки',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Дата создания записи',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Дата изменения записи',
  `remote_token` varchar(256) NOT NULL DEFAULT '' COMMENT 'Аутентификатор удаленного действия',
  PRIMARY KEY (`notify_id`),
  KEY `type` (`type`),
  KEY `user_id` (`user_id`),
  KEY `email` (`email`),
  KEY `phone` (`phone`),
  KEY `icq` (`icq`),
  KEY `skype` (`skype`),
  KEY `object_id` (`object_id`),
  KEY `variant_id` (`variant_id`),
  KEY `done` (`done`),
  KEY `enabled` (`enabled`),
  KEY `ip` (`ip`),
  KEY `created` (`created`),
  KEY `modified` (`modified`),
  KEY `remote_token` (`remote_token`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА notifies: содержимое
--
-- ----------------------------------------------------------------------------


-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА orders: структура
--
-- ----------------------------------------------------------------------------

DROP TABLE IF EXISTS `orders`;

CREATE TABLE `orders` (
  `order_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `delivery_method_id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Идентификатор способа доставки',
  `delivery_price` float(17,6) NOT NULL DEFAULT '0.000000' COMMENT 'Цена доставки',
  `payment_method_id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Идентификатор способа оплаты',
  `payment_status` int(11) NOT NULL DEFAULT '0',
  `payment_date` datetime NOT NULL,
  `written_off` tinyint(1) NOT NULL,
  `date` datetime DEFAULT NULL,
  `user_id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Идентификатор покупателя',
  `name` varchar(256) NOT NULL DEFAULT '' COMMENT 'Имя покупателя',
  `address` varchar(512) NOT NULL DEFAULT '' COMMENT 'Адрес доставки',
  `phone` varchar(256) NOT NULL DEFAULT '' COMMENT 'Телефон покупателя',
  `email` varchar(256) NOT NULL DEFAULT '' COMMENT 'Емейл покупателя',
  `comment` varchar(8192) NOT NULL DEFAULT '' COMMENT 'Комментарий покупателя к заказу',
  `status` int(11) NOT NULL DEFAULT '0',
  `code` varchar(256) NOT NULL DEFAULT '' COMMENT 'Код для url страницы заказа',
  `payment_details` text NOT NULL,
  `ip` varchar(256) NOT NULL DEFAULT '' COMMENT 'IP-адрес сделавшего заказ',
  `affiliate_id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Идентификатор реферала',
  `address2` varchar(512) NOT NULL DEFAULT '' COMMENT 'Адрес 2 доставки',
  `phone2` varchar(256) NOT NULL DEFAULT '' COMMENT 'Телефон 2 покупателя',
  `email2` varchar(256) NOT NULL DEFAULT '' COMMENT 'Емейл 2 покупателя',
  `to_date` varchar(256) NOT NULL DEFAULT '' COMMENT 'Желаемая дата доставки',
  `to_time` varchar(256) NOT NULL DEFAULT '' COMMENT 'Желаемое время доставки',
  `discount_sum` float(17,6) NOT NULL DEFAULT '0.000000' COMMENT 'Общая сумма скидки',
  `delivery_type` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Идентификатор типа доставки',
  `delivery_tracking` varchar(256) NOT NULL DEFAULT '' COMMENT 'Код отслеживания груза',
  `desire_payment_id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Идентификатор желаемого способа оплаты',
  `hidden` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Признак Скрыт от чужих',
  `state` int(11) NOT NULL DEFAULT '0' COMMENT 'Стадия состояния заказа',
  `comment_status` varchar(8192) NOT NULL DEFAULT '' COMMENT 'Комментарий администратора к состоянию заказа',
  `country_id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Идентификатор страны',
  `region_id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Идентификатор области',
  `town_id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Идентификатор города',
  `icq` varchar(256) NOT NULL DEFAULT '' COMMENT 'ICQ номер покупателя',
  `icq2` varchar(256) NOT NULL DEFAULT '' COMMENT 'ICQ номер 2 покупателя',
  `skype` varchar(256) NOT NULL DEFAULT '' COMMENT 'Skype имя покупателя',
  `skype2` varchar(256) NOT NULL DEFAULT '' COMMENT 'Skype имя 2 покупателя',
  `credit_id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Идентификатор кредитной программы',
  `credit_details` text NOT NULL COMMENT 'Детали кредита',
  `coupon_id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Идентификатор скидочного купона',
  PRIMARY KEY (`order_id`),
  KEY `login` (`user_id`),
  KEY `written_off` (`written_off`),
  KEY `date` (`date`),
  KEY `status` (`status`),
  KEY `code` (`code`),
  KEY `payment_status` (`payment_status`),
  KEY `affiliate_id` (`affiliate_id`),
  KEY `delivery_type` (`delivery_type`),
  KEY `desire_payment_id` (`desire_payment_id`),
  KEY `hidden` (`hidden`),
  KEY `country_id` (`country_id`),
  KEY `region_id` (`region_id`),
  KEY `town_id` (`town_id`),
  KEY `icq` (`icq`),
  KEY `icq2` (`icq2`),
  KEY `skype` (`skype`),
  KEY `skype2` (`skype2`),
  KEY `delivery_method_id` (`delivery_method_id`),
  KEY `payment_method_id` (`payment_method_id`),
  KEY `credit_id` (`credit_id`),
  KEY `name` (`name`),
  KEY `address` (`address`(333)),
  KEY `address2` (`address2`(333)),
  KEY `phone` (`phone`),
  KEY `phone2` (`phone2`),
  KEY `email` (`email`),
  KEY `email2` (`email2`),
  KEY `ip` (`ip`),
  KEY `coupon_id` (`coupon_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА orders: содержимое
--
-- ----------------------------------------------------------------------------


-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА orders_phases: структура
--
-- ----------------------------------------------------------------------------

DROP TABLE IF EXISTS `orders_phases`;

CREATE TABLE `orders_phases` (
  `phase_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'Идентификатор стадии заказа',
  `name` varchar(256) NOT NULL DEFAULT '' COMMENT 'Название стадии заказа',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Дата создания записи',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Дата изменения записи',
  `deleted` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Признак Запись удалена',
  PRIMARY KEY (`phase_id`),
  KEY `name` (`name`),
  KEY `created` (`created`),
  KEY `modified` (`modified`),
  KEY `deleted` (`deleted`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА orders_phases: содержимое
--
-- ----------------------------------------------------------------------------

INSERT INTO `orders_phases` VALUES ('1', 'Выполнен', '2014-11-12 16:34:01', '2014-11-12 16:34:01', '0');
INSERT INTO `orders_phases` VALUES ('2', 'Отложен для уточнения', '2014-11-12 16:34:26', '2014-11-12 16:34:26', '0');
INSERT INTO `orders_phases` VALUES ('3', 'Находится в сборке', '2014-11-12 16:34:46', '2014-11-12 16:34:46', '0');
INSERT INTO `orders_phases` VALUES ('4', 'Доставляется', '2014-11-12 16:35:07', '2014-11-12 16:35:07', '0');

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА orders_products: структура
--
-- ----------------------------------------------------------------------------

DROP TABLE IF EXISTS `orders_products`;

CREATE TABLE `orders_products` (
  `order_id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Идентификатор заказа',
  `product_id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Идентификатор товара',
  `variant_id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Идентификатор варианта товара',
  `product_name` varchar(256) NOT NULL DEFAULT '' COMMENT 'Название товара',
  `variant_name` varchar(256) NOT NULL DEFAULT '' COMMENT 'Название варианта товара',
  `price` float(17,6) NOT NULL DEFAULT '0.000000' COMMENT 'Цена товара со скидкой',
  `quantity` int(11) NOT NULL DEFAULT '0',
  `name_properties` text NOT NULL,
  `real_price` float(17,6) NOT NULL DEFAULT '0.000000' COMMENT 'Исходная цена товара',
  `orderitem_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'Идентификатор элемента заказа',
  `position` int(11) NOT NULL DEFAULT '0' COMMENT 'Положение элемента в заказе',
  `price_id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Идентификатор ценовой группы',
  PRIMARY KEY (`orderitem_id`),
  KEY `order_id` (`order_id`),
  KEY `position` (`position`),
  KEY `product_id` (`product_id`),
  KEY `variant_id` (`variant_id`),
  KEY `price_id` (`price_id`),
  KEY `quantity` (`quantity`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА orders_products: содержимое
--
-- ----------------------------------------------------------------------------


-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА payment_methods: структура
--
-- ----------------------------------------------------------------------------

DROP TABLE IF EXISTS `payment_methods`;

CREATE TABLE `payment_methods` (
  `payment_method_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'Идентификатор способа оплаты',
  `module` varchar(256) NOT NULL DEFAULT '' COMMENT 'Название платежного модуля',
  `name` varchar(256) NOT NULL DEFAULT '' COMMENT 'Название',
  `description` text NOT NULL,
  `currency_id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Идентификатор валюты',
  `params` text NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Дата создания записи',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Дата изменения записи',
  `order_num` int(11) NOT NULL DEFAULT '0' COMMENT 'Порядковый номер записи',
  `deleted` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Признак Запись удалена',
  PRIMARY KEY (`payment_method_id`),
  KEY `created` (`created`),
  KEY `modified` (`modified`),
  KEY `order_num` (`order_num`),
  KEY `name` (`name`),
  KEY `module` (`module`),
  KEY `currency_id` (`currency_id`),
  KEY `enabled` (`enabled`),
  KEY `deleted` (`deleted`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА payment_methods: содержимое
--
-- ----------------------------------------------------------------------------

INSERT INTO `payment_methods` VALUES ('1', 'privat24', 'Оплата банковской картой на Украине', '<p>Вы сможете оплатить заказ через систему Приват24 как со своей карты, так и с любого вашего счета.</p>', '3', 'a:3:{s:17:\"privat24_gate_url\";s:0:\"\";s:20:\"privat24_merchant_id\";s:0:\"\";s:19:\"privat24_secret_key\";s:0:\"\";}', '1', '2014-11-12 16:50:07', '2014-11-12 16:50:07', '0', '0');
INSERT INTO `payment_methods` VALUES ('2', 'receipt', 'Оплата в российском банке по квитанции', '<p>При выборе этого способа вам нужен принтер, чтобы распечатать квитанцию со страницы браузера.</p>', '1', 'a:23:{s:8:\"gate_url\";s:0:\"\";s:7:\"purpose\";s:0:\"\";s:13:\"purpose_label\";s:41:\"(наименование платежа)\";s:10:\"payer_name\";s:0:\"\";s:16:\"payer_name_label\";s:32:\"Ф.И.О. плательщика\";s:9:\"payer_inn\";s:0:\"\";s:15:\"payer_inn_label\";s:72:\"(номер лицевого счета (код) плательщика)\";s:13:\"payer_address\";s:0:\"\";s:19:\"payer_address_label\";s:33:\"Адрес плательщика\";s:9:\"recipient\";s:0:\"\";s:15:\"recipient_label\";s:62:\"(наименование получателя платежа)\";s:3:\"inn\";s:0:\"\";s:9:\"inn_label\";s:44:\"(ИНН получателя платежа)\";s:7:\"account\";s:0:\"\";s:13:\"account_label\";s:59:\"(номер счета получателя платежа)\";s:4:\"bank\";s:0:\"\";s:10:\"bank_label\";s:73:\"(наименование банка получателя платежа)\";s:3:\"bik\";s:0:\"\";s:9:\"bik_label\";s:6:\"БИК\";s:21:\"correspondent_account\";s:0:\"\";s:27:\"correspondent_account_label\";s:73:\"(номер кор./сч. банка получателя платежа)\";s:8:\"banknote\";s:0:\"\";s:5:\"pense\";s:0:\"\";}', '1', '2014-11-12 16:51:43', '2014-11-12 16:51:43', '0', '0');
INSERT INTO `payment_methods` VALUES ('3', 'liqpay', 'Оплата с карты через систему LiqPAY', '<p>Воспользуйтесь этим способом оплаты, если у вас есть счет в системе международных платежей LiqPAY.</p>', '1', 'a:5:{s:15:\"liqpay_gate_url\";s:0:\"\";s:18:\"liqpay_merchant_id\";s:0:\"\";s:17:\"liqpay_secret_key\";s:0:\"\";s:23:\"liqpay_through_terminal\";s:1:\"0\";s:15:\"liqpay_exp_time\";s:2:\"36\";}', '1', '2014-11-12 16:53:09', '2014-11-12 16:53:09', '0', '0');
INSERT INTO `payment_methods` VALUES ('4', 'robokassa', 'Оплату через Робокассу', '<p>Сервис Robokassa позволяет вам расплатиться любым видом электронных денег, какие имеются у вас в наличиии.</p>', '1', 'a:5:{s:8:\"gate_url\";s:0:\"\";s:15:\"robokassa_login\";s:0:\"\";s:19:\"robokassa_password1\";s:0:\"\";s:19:\"robokassa_password2\";s:0:\"\";s:18:\"robokassa_language\";s:2:\"ru\";}', '1', '2014-11-12 16:54:45', '2014-11-12 16:54:45', '0', '0');

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА products: структура
--
-- ----------------------------------------------------------------------------

DROP TABLE IF EXISTS `products`;

CREATE TABLE `products` (
  `product_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'Идентификатор товара',
  `url` varchar(256) NOT NULL DEFAULT '' COMMENT 'Окончание адреса страницы записи',
  `category_id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Идентификатор категории',
  `brand_id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Идентификатор бренда',
  `model` varchar(256) NOT NULL DEFAULT '' COMMENT 'Название товара',
  `description` text NOT NULL,
  `body` longtext NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `hit` tinyint(1) NOT NULL DEFAULT '0',
  `order_num` int(11) NOT NULL DEFAULT '0',
  `small_image` varchar(256) NOT NULL DEFAULT '' COMMENT 'Миниатюра основного фото',
  `large_image` varchar(256) NOT NULL DEFAULT '' COMMENT 'Основное фото',
  `download` text NOT NULL COMMENT 'Скачиваемый файл',
  `meta_title` varchar(256) NOT NULL DEFAULT '' COMMENT 'Мета заголовок страницы',
  `meta_keywords` varchar(512) NOT NULL DEFAULT '' COMMENT 'Мета ключевые слова страницы',
  `meta_description` varchar(512) NOT NULL DEFAULT '' COMMENT 'Мета описание страницы',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `subdomain` varchar(256) NOT NULL DEFAULT '' COMMENT 'Левая часть собственного субдомена товара',
  `subdomain_enabled` tinyint(1) NOT NULL DEFAULT '1',
  `subdomain_html` text NOT NULL,
  `order_num_hit` int(11) NOT NULL DEFAULT '0',
  `order_num_newest` int(11) NOT NULL DEFAULT '0',
  `order_num_actional` int(11) NOT NULL DEFAULT '0',
  `order_num_awaited` int(11) NOT NULL DEFAULT '0',
  `section` int(11) NOT NULL DEFAULT '1',
  `price` float(17,6) NOT NULL DEFAULT '0.000000' COMMENT 'Цена',
  `old_price` float(17,6) NOT NULL DEFAULT '0.000000' COMMENT 'Старая цена',
  `guarantee` varchar(64) NOT NULL DEFAULT '' COMMENT 'Срок гарантии',
  `quantity` int(11) NOT NULL DEFAULT '0',
  `pcode` varchar(256) NOT NULL DEFAULT '' COMMENT 'Буквенный код товара',
  `video` text NOT NULL,
  `coming` datetime NOT NULL,
  `ymarket` int(11) NOT NULL DEFAULT '1' COMMENT 'Признак Экспорт в Яндекс.Маркет',
  `vkontakte` tinyint(1) NOT NULL DEFAULT '1',
  `newest` tinyint(1) NOT NULL DEFAULT '0',
  `actional` tinyint(1) NOT NULL DEFAULT '0',
  `awaited` tinyint(1) NOT NULL DEFAULT '0',
  `article_ids` text NOT NULL COMMENT 'Идентификаторы связанных статей',
  `priority_discount` float(5,2) NOT NULL DEFAULT '-1.00',
  `temp_price` float(17,6) NOT NULL DEFAULT '0.000000' COMMENT 'Акционная цена',
  `in_prices` tinyint(1) unsigned NOT NULL DEFAULT '255',
  `url_special` tinyint(1) NOT NULL DEFAULT '0',
  `seo_description` text NOT NULL,
  `rating` float(12,2) NOT NULL DEFAULT '0.00',
  `votes` int(11) NOT NULL DEFAULT '0',
  `menu_id` bigint(20) NOT NULL DEFAULT '0',
  `user_id` bigint(20) NOT NULL DEFAULT '0',
  `objects` varchar(512) NOT NULL DEFAULT '',
  `commented` tinyint(1) NOT NULL DEFAULT '1',
  `hidden` tinyint(1) NOT NULL DEFAULT '0',
  `rss_disabled` tinyint(1) NOT NULL DEFAULT '0',
  `export_disabled` tinyint(1) NOT NULL DEFAULT '0',
  `news_ids` text NOT NULL,
  `images` text NOT NULL,
  `images_alts` text NOT NULL,
  `images_texts` longtext NOT NULL,
  `images_view` text NOT NULL,
  `browsed` int(11) NOT NULL DEFAULT '0',
  `shippings_term_id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Идентификатор срока отправки',
  `highlighted` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Выделена ли запись визуально',
  `barcode` varchar(256) NOT NULL DEFAULT '' COMMENT 'Штрих код товара',
  `files` text NOT NULL COMMENT 'Перечень всех файлов товара',
  `files_alts` text NOT NULL COMMENT 'Перечень надписей всех файлов товара',
  `files_texts` longtext NOT NULL COMMENT 'Перечень описаний всех файлов товара',
  `tags` varchar(256) NOT NULL DEFAULT '' COMMENT 'Теги записи',
  `non_creditable` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Запрещена ли продажа в кредит',
  `accessory_pids` text NOT NULL COMMENT 'Идентификаторы дополнительных товаров (аксессуаров)',
  `related_pids` text NOT NULL COMMENT 'Идентификаторы похожих товаров',
  `related_cids` text NOT NULL COMMENT 'Идентификаторы похожих категорий',
  `related_bids` text NOT NULL COMMENT 'Идентификаторы похожих брендов',
  `template` varchar(256) NOT NULL DEFAULT '' COMMENT 'Шаблон, используемый для отображения страницы',
  `sync_id` varchar(40) NOT NULL DEFAULT '' COMMENT 'Синхронизационный идентификатор',
  `non_usable` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Признак товара не для продажи',
  `canonical_id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Идентификатор канонического товара',
  PRIMARY KEY (`product_id`),
  KEY `url` (`url`),
  KEY `category_id` (`category_id`),
  KEY `brand_id` (`brand_id`),
  KEY `model` (`model`),
  KEY `hit` (`hit`),
  KEY `order_num` (`order_num`),
  KEY `date_edit` (`modified`),
  KEY `subdomain` (`subdomain`),
  KEY `subdomain_enabled` (`subdomain_enabled`),
  KEY `order_num_hit` (`order_num_hit`),
  KEY `order_num_newest` (`order_num_newest`),
  KEY `order_num_actional` (`order_num_actional`),
  KEY `order_num_awaited` (`order_num_awaited`),
  KEY `ymarket` (`ymarket`),
  KEY `vkontakte` (`vkontakte`),
  KEY `newest` (`newest`),
  KEY `actional` (`actional`),
  KEY `awaited` (`awaited`),
  KEY `in_prices` (`in_prices`),
  KEY `menu_id` (`menu_id`),
  KEY `user_id` (`user_id`),
  KEY `hidden` (`hidden`),
  KEY `rss_disabled` (`rss_disabled`),
  KEY `export_disabled` (`export_disabled`),
  KEY `browsed` (`browsed`),
  KEY `shippings_term_id` (`shippings_term_id`),
  KEY `enabled` (`enabled`),
  KEY `highlighted` (`highlighted`),
  KEY `commented` (`commented`),
  KEY `url_special` (`url_special`),
  KEY `pcode` (`pcode`),
  KEY `barcode` (`barcode`),
  KEY `tags` (`tags`),
  KEY `created` (`created`),
  KEY `votes` (`votes`),
  KEY `section` (`section`),
  KEY `non_creditable` (`non_creditable`),
  KEY `template` (`template`),
  KEY `sync_id` (`sync_id`),
  KEY `non_usable` (`non_usable`),
  KEY `canonical_id` (`canonical_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА products: содержимое
--
-- ----------------------------------------------------------------------------


-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА products_categories: структура
--
-- ----------------------------------------------------------------------------

DROP TABLE IF EXISTS `products_categories`;

CREATE TABLE `products_categories` (
  `product_id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Идентификатор товара',
  `category_id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Идентификатор категории',
  KEY `product_id` (`product_id`),
  KEY `category_id` (`category_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА products_categories: содержимое
--
-- ----------------------------------------------------------------------------


-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА products_comments: структура
--
-- ----------------------------------------------------------------------------

DROP TABLE IF EXISTS `products_comments`;

CREATE TABLE `products_comments` (
  `comment_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ip` varchar(20) NOT NULL DEFAULT '',
  `product_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `comment` varchar(1024) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `parent_id` bigint(20) NOT NULL DEFAULT '0',
  `email` varchar(255) NOT NULL DEFAULT '',
  `from_user` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_id`),
  KEY `product_id` (`product_id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА products_comments: содержимое
--
-- ----------------------------------------------------------------------------


-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА products_kits: структура
--
-- ----------------------------------------------------------------------------

DROP TABLE IF EXISTS `products_kits`;

CREATE TABLE `products_kits` (
  `kit_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'Идентификатор комплекта',
  `ymarket` int(11) NOT NULL DEFAULT '1' COMMENT 'Признак Экспорт в Яндекс.Маркет',
  `vkontakte` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'Признак Экспорт в ВКонтакте',
  `enabled` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'Разрешена ли запись к использованию',
  `commented` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'Разрешено ли оставлять отзывы о комплекте',
  `hidden` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Скрыта ли запись от незарегистрированных пользователей',
  `rss_disabled` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Резрешен ли экспорт записи в RSS',
  `export_disabled` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Разрешен ли экспорт записи в информеры для внешних сайтов',
  `in_prices` tinyint(1) unsigned NOT NULL DEFAULT '255' COMMENT 'В каких из 8 прайсов выводится запись',
  `url` varchar(256) NOT NULL DEFAULT '' COMMENT 'Окончание адреса страницы записи',
  `url_special` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Имеет ли запись особый адрес страницы',
  `meta_title` varchar(256) NOT NULL DEFAULT '' COMMENT 'Мета заголовок',
  `meta_keywords` varchar(512) NOT NULL DEFAULT '' COMMENT 'Мета ключевые слова',
  `meta_description` varchar(512) NOT NULL DEFAULT '' COMMENT 'Мета описание',
  `name` varchar(256) NOT NULL DEFAULT '' COMMENT 'Название комплекта',
  `description` text NOT NULL COMMENT 'Описание комплекта',
  `body` longtext NOT NULL COMMENT 'Полное описание',
  `seo_description` text NOT NULL COMMENT 'SEO текст',
  `tags` varchar(256) NOT NULL DEFAULT '' COMMENT 'Теги записи',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Дата создания записи',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Дата изменения записи',
  `browsed` int(11) NOT NULL DEFAULT '0' COMMENT 'Количество просмотров страницы записи',
  `order_num` int(11) NOT NULL DEFAULT '0' COMMENT 'Порядковый номер записи',
  `highlighted` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Выделена ли запись визуально',
  `non_creditable` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Запрещена ли продажа в кредит',
  `non_usable` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Признак Не для продажи (экспонат)',
  `template` varchar(256) NOT NULL DEFAULT '' COMMENT 'Нестандартный шаблон для отображения',
  PRIMARY KEY (`kit_id`),
  KEY `ymarket` (`ymarket`),
  KEY `vkontakte` (`vkontakte`),
  KEY `enabled` (`enabled`),
  KEY `commented` (`commented`),
  KEY `hidden` (`hidden`),
  KEY `rss_disabled` (`rss_disabled`),
  KEY `export_disabled` (`export_disabled`),
  KEY `in_prices` (`in_prices`),
  KEY `url` (`url`),
  KEY `name` (`name`),
  KEY `tags` (`tags`),
  KEY `created` (`created`),
  KEY `modified` (`modified`),
  KEY `browsed` (`browsed`),
  KEY `order_num` (`order_num`),
  KEY `highlighted` (`highlighted`),
  KEY `non_creditable` (`non_creditable`),
  KEY `non_usable` (`non_usable`),
  KEY `template` (`template`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА products_kits: содержимое
--
-- ----------------------------------------------------------------------------


-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА products_kits_items: структура
--
-- ----------------------------------------------------------------------------

DROP TABLE IF EXISTS `products_kits_items`;

CREATE TABLE `products_kits_items` (
  `kititem_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'Идентификатор элемента комплекта',
  `kit_id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Идентификатор комплекта',
  `product_id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Идентификатор товара',
  `variant_id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Идентификатор варианта товара',
  `discount` float(5,2) NOT NULL DEFAULT '-1.00' COMMENT 'Скидка',
  `quantity` int(11) NOT NULL DEFAULT '0' COMMENT 'Количество товара',
  `position` int(11) NOT NULL DEFAULT '0' COMMENT 'Положение элемента в комплекте',
  PRIMARY KEY (`kititem_id`),
  KEY `kit_id` (`kit_id`),
  KEY `product_id` (`product_id`),
  KEY `variant_id` (`variant_id`),
  KEY `quantity` (`quantity`),
  KEY `position` (`position`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА products_kits_items: содержимое
--
-- ----------------------------------------------------------------------------


-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА products_variants: структура
--
-- ----------------------------------------------------------------------------

DROP TABLE IF EXISTS `products_variants`;

CREATE TABLE `products_variants` (
  `variant_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `product_id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Идентификатор товара',
  `sku` varchar(256) NOT NULL DEFAULT '' COMMENT 'Артикул варианта товара',
  `name` varchar(256) NOT NULL DEFAULT '' COMMENT 'Название варианта товара',
  `price` float(17,6) NOT NULL DEFAULT '0.000000' COMMENT 'Цена 1 варианта товара',
  `stock` int(11) NOT NULL,
  `position` int(11) NOT NULL,
  `old_price` float(17,6) NOT NULL DEFAULT '0.000000' COMMENT 'Старая цена варианта',
  `priority_discount` float(5,2) NOT NULL DEFAULT '-1.00',
  `temp_price` float(17,6) NOT NULL DEFAULT '0.000000' COMMENT 'Акционная цена варианта',
  `price2` float(17,6) NOT NULL DEFAULT '0.000000' COMMENT 'Цена 2 варианта товара',
  `price3` float(17,6) NOT NULL DEFAULT '0.000000' COMMENT 'Цена 3 варианта товара',
  `price4` float(17,6) NOT NULL DEFAULT '0.000000' COMMENT 'Цена 4 варианта товара',
  `price5` float(17,6) NOT NULL DEFAULT '0.000000' COMMENT 'Цена 5 варианта товара',
  `price6` float(17,6) NOT NULL DEFAULT '0.000000' COMMENT 'Цена 6 варианта товара',
  `price7` float(17,6) NOT NULL DEFAULT '0.000000' COMMENT 'Цена 7 варианта товара',
  `price8` float(17,6) NOT NULL DEFAULT '0.000000' COMMENT 'Цена 8 варианта товара',
  `price9` float(17,6) NOT NULL DEFAULT '0.000000' COMMENT 'Цена 9 варианта товара',
  `price10` float(17,6) NOT NULL DEFAULT '0.000000' COMMENT 'Цена 10 варианта товара',
  `temp_price_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Дата действия акционной цены',
  `temp_price_members` int(11) NOT NULL DEFAULT '0' COMMENT 'Требуемое число участников акционной цены',
  `temp_price_invited` int(11) NOT NULL DEFAULT '0' COMMENT 'Число привлеченных участников акционной цены',
  `sync_id` varchar(40) NOT NULL DEFAULT '' COMMENT 'Синхронизационный идентификатор',
  `temp_price_start` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Дата начала действия акционной цены',
  PRIMARY KEY (`variant_id`),
  KEY `product_id` (`product_id`),
  KEY `sku` (`sku`),
  KEY `name` (`name`),
  KEY `price` (`price`),
  KEY `temp_price` (`temp_price`),
  KEY `priority_discount` (`priority_discount`),
  KEY `stock` (`stock`),
  KEY `position` (`position`),
  KEY `temp_price_date` (`temp_price_date`),
  KEY `temp_price_members` (`temp_price_members`),
  KEY `temp_price_invited` (`temp_price_invited`),
  KEY `sync_id` (`sync_id`),
  KEY `temp_price_start` (`temp_price_start`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА products_variants: содержимое
--
-- ----------------------------------------------------------------------------


-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА properties: структура
--
-- ----------------------------------------------------------------------------

DROP TABLE IF EXISTS `properties`;

CREATE TABLE `properties` (
  `property_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `in_product` int(1) NOT NULL,
  `in_filter` int(1) NOT NULL,
  `in_compare` int(1) NOT NULL,
  `order_num` int(11) NOT NULL,
  `enabled` int(1) NOT NULL DEFAULT '1',
  `options` text NOT NULL,
  `categories` mediumtext NOT NULL,
  `brands` mediumtext NOT NULL,
  `sync_id` varchar(40) NOT NULL DEFAULT '' COMMENT 'Синхронизационный идентификатор',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Дата создания записи',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Дата изменения записи',
  PRIMARY KEY (`property_id`),
  KEY `sync_id` (`sync_id`),
  KEY `created` (`created`),
  KEY `modified` (`modified`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА properties: содержимое
--
-- ----------------------------------------------------------------------------


-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА properties_values: структура
--
-- ----------------------------------------------------------------------------

DROP TABLE IF EXISTS `properties_values`;

CREATE TABLE `properties_values` (
  `product_id` int(11) NOT NULL,
  `property_id` int(11) NOT NULL,
  `value` varchar(512) NOT NULL,
  `order_num` int(11) NOT NULL DEFAULT '0',
  `price_plus` varchar(13) NOT NULL DEFAULT '',
  `quantity_plus` varchar(12) NOT NULL DEFAULT '',
  PRIMARY KEY (`product_id`,`property_id`,`order_num`),
  KEY `value` (`value`(333))
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА properties_values: содержимое
--
-- ----------------------------------------------------------------------------


-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА regions: структура
--
-- ----------------------------------------------------------------------------

DROP TABLE IF EXISTS `regions`;

CREATE TABLE `regions` (
  `region_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'Идентификатор области',
  `country_id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Идентификатор страны',
  `enabled` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'Разрешена ли запись к использованию',
  `url` varchar(256) NOT NULL DEFAULT '' COMMENT 'Адрес страницы записи',
  `meta_title` varchar(256) NOT NULL DEFAULT '' COMMENT 'Мета заголовок страницы записи',
  `meta_keywords` varchar(512) NOT NULL DEFAULT '' COMMENT 'Мета ключевые слова страницы записи',
  `meta_description` varchar(512) NOT NULL DEFAULT '' COMMENT 'Мета описание страницы записи',
  `name` varchar(256) NOT NULL DEFAULT '' COMMENT 'Название области',
  `description` text NOT NULL COMMENT 'Описание области',
  `seo_description` text NOT NULL COMMENT 'SEO текст',
  `phone_code` varchar(16) NOT NULL DEFAULT '' COMMENT 'Телефонный стационарный код области',
  `images` text NOT NULL COMMENT 'Изображения записи',
  `images_alts` text NOT NULL COMMENT 'Подписи изображений записи',
  `images_texts` longtext NOT NULL COMMENT 'Описания изображений записи',
  `images_view` text NOT NULL COMMENT 'Признаки использования в слайдере изображений записи',
  `tags` varchar(256) NOT NULL DEFAULT '' COMMENT 'Теги записи',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Дата создания записи',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Дата изменения записи',
  `browsed` int(11) NOT NULL DEFAULT '0' COMMENT 'Количество просмотров записи',
  `order_num` int(11) NOT NULL DEFAULT '0' COMMENT 'Порядковый номер записи',
  PRIMARY KEY (`region_id`),
  KEY `country_id` (`country_id`),
  KEY `enabled` (`enabled`),
  KEY `url` (`url`),
  KEY `name` (`name`),
  KEY `phone_code` (`phone_code`),
  KEY `tags` (`tags`),
  KEY `created` (`created`),
  KEY `modified` (`modified`),
  KEY `browsed` (`browsed`),
  KEY `order_num` (`order_num`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА regions: содержимое
--
-- ----------------------------------------------------------------------------

INSERT INTO `regions` VALUES ('1', '223', '1', '', '', '', '', 'АР Крым', '', '', '', '', '', '', '', '', '2011-11-07 16:32:54', '0000-00-00 00:00:00', '0', '0');
INSERT INTO `regions` VALUES ('2', '223', '1', '', '', '', '', 'Винницкая область', '', '', '', '', '', '', '', '', '2011-11-07 16:32:54', '0000-00-00 00:00:00', '0', '0');
INSERT INTO `regions` VALUES ('3', '223', '1', '', '', '', '', 'Волынская область', '', '', '', '', '', '', '', '', '2011-11-07 16:32:54', '0000-00-00 00:00:00', '0', '0');
INSERT INTO `regions` VALUES ('4', '223', '1', '', '', '', '', 'Днепропетровская область', '', '', '', '', '', '', '', '', '2011-11-07 16:32:54', '0000-00-00 00:00:00', '0', '0');
INSERT INTO `regions` VALUES ('5', '223', '1', '', '', '', '', 'Донецкая область', '', '', '', '', '', '', '', '', '2011-11-07 16:32:54', '0000-00-00 00:00:00', '0', '0');
INSERT INTO `regions` VALUES ('6', '223', '1', '', '', '', '', 'Житомирская область', '', '', '', '', '', '', '', '', '2011-11-07 16:32:54', '0000-00-00 00:00:00', '0', '0');
INSERT INTO `regions` VALUES ('7', '223', '1', '', '', '', '', 'Закарпатская область', '', '', '', '', '', '', '', '', '2011-11-07 16:32:54', '0000-00-00 00:00:00', '0', '0');
INSERT INTO `regions` VALUES ('8', '223', '1', '', '', '', '', 'Запорожская область', '', '', '', '', '', '', '', '', '2011-11-07 16:32:54', '0000-00-00 00:00:00', '0', '0');
INSERT INTO `regions` VALUES ('9', '223', '1', '', '', '', '', 'Ивано-Франковская область', '', '', '', '', '', '', '', '', '2011-11-07 16:32:54', '0000-00-00 00:00:00', '0', '0');
INSERT INTO `regions` VALUES ('10', '223', '1', '', '', '', '', 'Киевская область', '', '', '', '', '', '', '', '', '2011-11-07 16:32:54', '0000-00-00 00:00:00', '0', '0');
INSERT INTO `regions` VALUES ('11', '223', '1', '', '', '', '', 'Кировоградская область', '', '', '', '', '', '', '', '', '2011-11-07 16:32:54', '0000-00-00 00:00:00', '0', '0');
INSERT INTO `regions` VALUES ('12', '223', '1', '', '', '', '', 'Луганская область', '', '', '', '', '', '', '', '', '2011-11-07 16:32:54', '0000-00-00 00:00:00', '0', '0');
INSERT INTO `regions` VALUES ('13', '223', '1', '', '', '', '', 'Львовская область', '', '', '', '', '', '', '', '', '2011-11-07 16:32:54', '0000-00-00 00:00:00', '0', '0');
INSERT INTO `regions` VALUES ('14', '223', '1', '', '', '', '', 'Николаевская область', '', '', '', '', '', '', '', '', '2011-11-07 16:32:54', '0000-00-00 00:00:00', '0', '0');
INSERT INTO `regions` VALUES ('15', '223', '1', '', '', '', '', 'Одесская область', '', '', '', '', '', '', '', '', '2011-11-07 16:32:54', '0000-00-00 00:00:00', '0', '0');
INSERT INTO `regions` VALUES ('16', '223', '1', '', '', '', '', 'Полтавская область', '', '', '', '', '', '', '', '', '2011-11-07 16:32:54', '0000-00-00 00:00:00', '0', '0');
INSERT INTO `regions` VALUES ('17', '223', '1', '', '', '', '', 'Ровенская область', '', '', '', '', '', '', '', '', '2011-11-07 16:32:54', '0000-00-00 00:00:00', '0', '0');
INSERT INTO `regions` VALUES ('18', '223', '1', '', '', '', '', 'Сумская область', '', '', '', '', '', '', '', '', '2011-11-07 16:32:54', '0000-00-00 00:00:00', '0', '0');
INSERT INTO `regions` VALUES ('19', '223', '1', '', '', '', '', 'Тернопольская область', '', '', '', '', '', '', '', '', '2011-11-07 16:32:54', '0000-00-00 00:00:00', '0', '0');
INSERT INTO `regions` VALUES ('20', '223', '1', '', '', '', '', 'Харьковская область', '', '', '', '', '', '', '', '', '2011-11-07 16:32:54', '0000-00-00 00:00:00', '0', '0');
INSERT INTO `regions` VALUES ('21', '223', '1', '', '', '', '', 'Херсонская область', '', '', '', '', '', '', '', '', '2011-11-07 16:32:54', '0000-00-00 00:00:00', '0', '0');
INSERT INTO `regions` VALUES ('22', '223', '1', '', '', '', '', 'Хмельницкая область', '', '', '', '', '', '', '', '', '2011-11-07 16:32:54', '0000-00-00 00:00:00', '0', '0');
INSERT INTO `regions` VALUES ('23', '223', '1', '', '', '', '', 'Черкасская область', '', '', '', '', '', '', '', '', '2011-11-07 16:32:54', '0000-00-00 00:00:00', '0', '0');
INSERT INTO `regions` VALUES ('24', '223', '1', '', '', '', '', 'Черниговская область', '', '', '', '', '', '', '', '', '2011-11-07 16:32:54', '0000-00-00 00:00:00', '0', '0');
INSERT INTO `regions` VALUES ('25', '223', '1', '', '', '', '', 'Черновицкая область', '', '', '', '', '', '', '', '', '2011-11-07 16:32:54', '0000-00-00 00:00:00', '0', '0');

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА related_products: структура
--
-- ----------------------------------------------------------------------------

DROP TABLE IF EXISTS `related_products`;

CREATE TABLE `related_products` (
  `product_id` int(11) NOT NULL,
  `related_sku` varchar(255) NOT NULL,
  PRIMARY KEY (`product_id`,`related_sku`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА related_products: содержимое
--
-- ----------------------------------------------------------------------------


-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА s_blog: структура
--
-- ----------------------------------------------------------------------------

DROP TABLE IF EXISTS `s_blog`;

CREATE TABLE `s_blog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(500) NOT NULL,
  `url` varchar(255) NOT NULL,
  `meta_title` varchar(500) NOT NULL,
  `meta_keywords` varchar(500) NOT NULL,
  `meta_description` varchar(500) NOT NULL,
  `annotation` text NOT NULL,
  `text` longtext NOT NULL,
  `visible` tinyint(1) NOT NULL DEFAULT '0',
  `date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `enabled` (`visible`),
  KEY `url` (`url`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА s_blog: содержимое
--
-- ----------------------------------------------------------------------------

INSERT INTO `s_blog` VALUES ('14', 'Подростковая одежда оптом в Украине', 'podrostkovaya-odezhda-optom-v-ukraine', 'Подростковая одежда оптом в Украине', 'Подростковая одежда оптом в Украине', 'Каждая компания-оптовик в блоге на сайте хоть немного, но себя похвалит. Как минимум, расскажет, что одежда произведена в Одессе, реализация &mdash; ростовками, минимальный заказ на сумму от 1000 гривен и такое всякое.', '<p>Каждая компания-оптовик в блоге на сайте хоть немного, но себя похвалит. Как минимум, расскажет, что одежда произведена в Одессе, реализация &mdash; ростовками, минимальный заказ на сумму от 1000 гривен и такое всякое.</p>', '<p>Каждая компания-оптовик в блоге на сайте хоть немного, но себя похвалит. Как минимум, расскажет, что одежда произведена в Одессе, реализация &mdash; ростовками, минимальный заказ на сумму от 1000 гривен и такое всякое.</p><p>&nbsp;</p><p>И лишь единицы готовы открыть тайну. Например, мы. О том, из чего шьем наряды или для кого работают наши сотрудники. Как предлагают купить оптом подростковую одежду, но когда приходит время одевать своих детей, разводят руками. Пошли в фирменный магазин, а там ассортимент маленький, оптовики разобрали... Расстроились. Раньше покупали все, что нужно и в одном месте:</p><p>&nbsp;</p><ul><li>широкий выбор цветов</li><li>все размеры</li><li>хорошее качество по доступной цене (своими руками делаем, для себя же стараемся!)</li></ul><p>&nbsp;</p><p>&nbsp;</p><p>А теперь непонятно, где банальный сарафан найти. Идешь в соседний батискаф, там тоже одежда для подростков на опт идет, в розницу не продают. А вдобавок с ядреными рисунками, зверюшками, а возраст не детский, для 5 класса не пойдет.</p><p>&nbsp;</p><p>Подростковая одежда оптом от производителя, как считают наши дизайнеры, и во многом они правы, должна подчеркивать быстро меняющуюся фигуру ребенка. Возраст 12-16 лет &mdash; время полового созревания. Девушки и парни хотят общаться со взрослыми на равных, а модели для сформировавшейся фигуры отличаются от моделей для подростков.</p><p>&nbsp;</p><p>В них они выглядят нелепо и смешно, неспроста дизайнеры целые коллекции создают для определенного возраста.</p><p>&nbsp;</p><p>Так вот, вернемся к вопросу преимуществ продукции в каталоге. Она пошита в Одессе, по меркам, снятым с украинских мальчиков и девочек, из качественных материалов. Продается ростовками по 2-3 штуки, естественно, по ценам производителя. Доставка возможна компаниями-перевозчиками в любую точку Украины.</p><p>&nbsp;</p><p>Немаловажен и факт, что подростковая одежда оптом, абсолютно вся, выдержана в духе &laquo;стиля&raquo;. Юные модники и модницы не опасаются улыбок своего окружения, вливаются в молодежное течение. Иногда даже чересчур &mdash; ткани и покрой качественные, поэтому сменять гардероб придется не по причине &laquo;ветхости&raquo;, а по причине скоротечности моды.</p><p>&nbsp;</p><p>Оптовые цены на подростковую одежду, качество, условия работы с магазинами и частными предпринимателями &mdash; вне конкуренции, &mdash; любят хвастаться сотрудники компаний. А когда дело доходит до покупок &laquo;себе&raquo;, &laquo;для своих&raquo;, разводят руками: &laquo;Бизнес есть бизнес, в рознице дороже&raquo;.</p>', '1', '2014-02-27 00:00:00');
INSERT INTO `s_blog` VALUES ('15', 'Повседневные платья оптом', 'povsednevnye-platya-optom', 'Повседневные платья оптом', 'Повседневные платья оптом', 'Сколько людей, столько и мнений, но бизнесмены &mdash; это особая категория людей. Они хотят и умеют открывать перед обществом новые возможности, улучшать его жизнь. Они думают о потребителях, не только о себе.', '<p>Сколько людей, столько и мнений, но бизнесмены &mdash; это особая категория людей. Они хотят и умеют открывать перед обществом новые возможности, улучшать его жизнь. Они думают о потребителях, не только о себе.</p>', '<p>Сколько людей, столько и мнений, но бизнесмены &mdash; это особая категория людей. Они хотят и умеют открывать перед обществом новые возможности, улучшать его жизнь. Они думают о потребителях, не только о себе.</p><p>&nbsp;</p><p>Наш магазин реализует повседневные платья оптом. Если вы тоже в этом бизнесе, имеете свой магазин, секцию в супермаркете или батискаф на рынке, поделимся полезной информацией. Конечно, вы сможете ее получить и без нашей помощи, но как часто это бывает, золото лежит под ногами, достаточно наклониться и поднять.</p><p>&nbsp;</p><ul><li>Модели в каталоге полноразмерные, трикотаж хорошо тянется. Советов по размерам мы не даем, потому как у каждой женщины своя фигура и вкусы относительно того, как должно сидеть платье.</li><li>Ткани качественные &mdash; прямо струятся по фигуре, нежные, приятные к телу; цвета на любой вкус, соответствуют фотографиям, а в живую даже красивее, чем на фото.</li><li>Повседневные платья продаем оптом, недорого. И самые дешевые, и дорогие подчеркивают фигуру, скрывают &laquo;животик&raquo;, когда это нужно и задумано изначально.</li></ul><p>&nbsp;</p><p>Сейчас, уважаемый посетитель, ответь на главный вопрос. Если ты, конечно, занимаешься нашим общим бизнесом: - Сколько единиц товара можно продать одному покупателя? При условии, что он доволен первой покупкой и место в платяном шкафу есть...</p><p>&nbsp;</p><p>Женщины, которые носят наши вещи, говорят по-разному. Одни признаются, что имеют пару платьев, а хотелось бы десять, но нет денег. Другие покупают 3-4, но разных цветов &mdash; черного, бежевого, розового. Третьи хвалятся, у них штук 15 повседневных, не считая вечерних, так что муж скоро на улицу выгонит. Четвертые успевают часть гардероба продать через интернет, остается много, а одеть все равно нечего.</p><p>&nbsp;</p><p>Были у нас и другие ответы. Например, что одевают только одно, а остальные &mdash; новые и дорогие, тупо висят. Или одевают их в гости, погулять, в кино, а для работы &mdash; ни одного. Или имеют на холодное время парочку поплотнее, на лето &mdash; еще парочку с рюшками. Осенью в ход идут джинсы или кардиганы, со всякими шарфиками/платочками сверху.</p><p>&nbsp;</p><p>Суть всех этих слов такова: пока женщина жива, у нее в гардеробе есть несколько платьев, она регулярно подбирает новые, даже если старые в идеальном состоянии. Мы всегда рады новым заказам, а вы покупайте повседневные платья оптом, и не волнуйтесь: - За ними будут возвращаться снова, только успевай ассортимент обновлять!</p>', '1', '2014-03-11 00:00:00');

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА s_brands: структура
--
-- ----------------------------------------------------------------------------

DROP TABLE IF EXISTS `s_brands`;

CREATE TABLE `s_brands` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `url` varchar(255) NOT NULL DEFAULT '',
  `meta_title` varchar(500) NOT NULL,
  `meta_keywords` varchar(500) NOT NULL,
  `meta_description` varchar(500) NOT NULL,
  `description` text NOT NULL,
  `image` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `url` (`url`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА s_brands: содержимое
--
-- ----------------------------------------------------------------------------

INSERT INTO `s_brands` VALUES ('12', 'Брендикола', 'brendikola', 'Брендикола', 'Брендикола', 'Брендикола', '', '');

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА s_categories: структура
--
-- ----------------------------------------------------------------------------

DROP TABLE IF EXISTS `s_categories`;

CREATE TABLE `s_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `meta_title` varchar(255) NOT NULL,
  `meta_keywords` varchar(255) NOT NULL,
  `meta_description` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `url` varchar(255) NOT NULL DEFAULT '',
  `image` varchar(255) NOT NULL DEFAULT '',
  `position` int(11) NOT NULL DEFAULT '0',
  `visible` tinyint(1) NOT NULL DEFAULT '1',
  `external_id` varchar(36) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `url` (`url`),
  KEY `parent_id` (`parent_id`),
  KEY `position` (`position`),
  KEY `visible` (`visible`),
  KEY `external_id` (`external_id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА s_categories: содержимое
--
-- ----------------------------------------------------------------------------

INSERT INTO `s_categories` VALUES ('1', '0', 'Девочки', 'Девочки', 'Девочки', '', '', 'devochki', 'girl.jpg', '2', '1', '');
INSERT INTO `s_categories` VALUES ('2', '0', 'Женщины', 'Женщины', 'Женщины', '', '', 'zhenschiny', '', '1', '1', '');
INSERT INTO `s_categories` VALUES ('12', '2', 'Рубашки', 'Рубашки', 'Рубашки', '', '', 'rubashki', '', '12', '1', '');
INSERT INTO `s_categories` VALUES ('9', '2', 'Офисная одежда', 'Офисная одежда', 'Офисная одежда', '', '', 'ofisnaya-odezhda', '', '9', '1', '');
INSERT INTO `s_categories` VALUES ('5', '0', 'Мальчики', 'Мальчики', 'Мальчики', '', '', 'boys', 'boy.jpg', '7', '1', '');
INSERT INTO `s_categories` VALUES ('10', '2', 'Платья', 'Платья', 'Платья', '', '', 'platya', '', '10', '1', '');
INSERT INTO `s_categories` VALUES ('11', '2', 'Сарафаны', 'Сарафаны', 'Сарафаны', '', '', 'sarafany', '', '11', '1', '');
INSERT INTO `s_categories` VALUES ('8', '0', 'Распродажа', 'Распродажа', 'Распродажа', '', '', 'rasprodazha', '', '8', '1', '');

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА s_categories_features: структура
--
-- ----------------------------------------------------------------------------

DROP TABLE IF EXISTS `s_categories_features`;

CREATE TABLE `s_categories_features` (
  `category_id` int(11) NOT NULL,
  `feature_id` int(11) NOT NULL,
  PRIMARY KEY (`category_id`,`feature_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА s_categories_features: содержимое
--
-- ----------------------------------------------------------------------------

INSERT INTO `s_categories_features` VALUES ('2', '158');
INSERT INTO `s_categories_features` VALUES ('2', '159');

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА s_comments: структура
--
-- ----------------------------------------------------------------------------

DROP TABLE IF EXISTS `s_comments`;

CREATE TABLE `s_comments` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ip` varchar(20) NOT NULL,
  `object_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `text` text NOT NULL,
  `type` enum('product','blog') NOT NULL,
  `approved` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `product_id` (`object_id`),
  KEY `type` (`type`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА s_comments: содержимое
--
-- ----------------------------------------------------------------------------


-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА s_coupons: структура
--
-- ----------------------------------------------------------------------------

DROP TABLE IF EXISTS `s_coupons`;

CREATE TABLE `s_coupons` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `code` varchar(256) NOT NULL,
  `expire` timestamp NULL DEFAULT NULL,
  `type` enum('absolute','percentage') NOT NULL DEFAULT 'absolute',
  `value` float(10,2) NOT NULL,
  `min_order_price` float(10,2) DEFAULT NULL,
  `single` int(1) NOT NULL DEFAULT '0',
  `usages` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА s_coupons: содержимое
--
-- ----------------------------------------------------------------------------

INSERT INTO `s_coupons` VALUES ('11', 'THANKYOU', '2015-05-31 21:00:00', 'absolute', '5.00', '50000.00', '1', '0');
INSERT INTO `s_coupons` VALUES ('15', 'SIMPLACMS', NULL, 'absolute', '10.00', '150000.00', '0', '0');
INSERT INTO `s_coupons` VALUES ('17', 'TESTCOUPON', '2010-05-31 21:00:00', 'percentage', '0.10', '0.00', '0', '0');

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА s_currencies: структура
--
-- ----------------------------------------------------------------------------

DROP TABLE IF EXISTS `s_currencies`;

CREATE TABLE `s_currencies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '0',
  `sign` varchar(20) NOT NULL,
  `code` char(3) NOT NULL DEFAULT '',
  `rate_from` float(10,2) NOT NULL DEFAULT '1.00',
  `rate_to` float(10,2) NOT NULL DEFAULT '1.00',
  `cents` int(1) NOT NULL DEFAULT '2',
  `position` int(11) NOT NULL,
  `enabled` int(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `position` (`position`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА s_currencies: содержимое
--
-- ----------------------------------------------------------------------------

INSERT INTO `s_currencies` VALUES ('2', 'UAH', 'грн', 'UAH', '3.75', '3.75', '0', '1', '1');
INSERT INTO `s_currencies` VALUES ('1', 'USD', 'usd', 'USD', '1.00', '10.00', '0', '2', '1');
INSERT INTO `s_currencies` VALUES ('3', 'RUB', 'руб', 'RUB', '4.00', '1.00', '0', '3', '1');

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА s_delivery: структура
--
-- ----------------------------------------------------------------------------

DROP TABLE IF EXISTS `s_delivery`;

CREATE TABLE `s_delivery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `free_from` float(10,2) NOT NULL,
  `price` float(10,2) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '0',
  `position` int(11) NOT NULL,
  `separate_payment` int(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `position` (`position`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА s_delivery: содержимое
--
-- ----------------------------------------------------------------------------

INSERT INTO `s_delivery` VALUES ('1', 'Курьерская доставка по Одессе', '<p><span>Курьерская доставка осуществляется на следующий день после оформления заказа, если товар есть в наличии. Курьерская доставка осуществляется в пределах г. Одесса ежедневно с 10.00 до 21.00. Заказ на сумму свыше 1500 гривен доставляется бесплатно.&nbsp;<br /><br />Стоимость бесплатной доставки раcсчитывается от суммы заказа с учтенной скидкой. В случае если сумма заказа после применения скидки менее 1500 грн., осуществляется платная доставка.&nbsp;<br /><br />При сумме заказа менее 1500 гривен стоимость доставки составляет от 50 гривен.</span></p>', '1500.00', '50.00', '1', '2', '1');
INSERT INTO `s_delivery` VALUES ('2', 'Самовывоз', '<p>Удобный, бесплатный и быстрый способ получения заказа.</p><p>Товар можно получить по адресу:&nbsp;</p><p>г. Одесса&nbsp;</p><p>Промышленный рынок 7 км.</p><p>2 площадка&nbsp;</p><p>Абрикосовая №3335</p>', '0.00', '0.00', '1', '3', NULL);
INSERT INTO `s_delivery` VALUES ('3', 'Новая почта', '<p>Доставка осуществляется на следующий день после отправления заказа.&nbsp;</p><p>Тариф расчитывается отдельно транспортной фирмой-перевозчиком.</p>', '0.00', '0.00', '1', '3', '1');

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА s_delivery_payment: структура
--
-- ----------------------------------------------------------------------------

DROP TABLE IF EXISTS `s_delivery_payment`;

CREATE TABLE `s_delivery_payment` (
  `delivery_id` int(11) NOT NULL,
  `payment_method_id` int(11) NOT NULL,
  PRIMARY KEY (`delivery_id`,`payment_method_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Связка способом оплаты и способов доставки';

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА s_delivery_payment: содержимое
--
-- ----------------------------------------------------------------------------

INSERT INTO `s_delivery_payment` VALUES ('1', '1');
INSERT INTO `s_delivery_payment` VALUES ('1', '2');
INSERT INTO `s_delivery_payment` VALUES ('1', '3');
INSERT INTO `s_delivery_payment` VALUES ('1', '4');
INSERT INTO `s_delivery_payment` VALUES ('1', '5');
INSERT INTO `s_delivery_payment` VALUES ('1', '6');
INSERT INTO `s_delivery_payment` VALUES ('1', '7');
INSERT INTO `s_delivery_payment` VALUES ('1', '8');
INSERT INTO `s_delivery_payment` VALUES ('1', '9');
INSERT INTO `s_delivery_payment` VALUES ('2', '1');
INSERT INTO `s_delivery_payment` VALUES ('2', '2');
INSERT INTO `s_delivery_payment` VALUES ('2', '3');
INSERT INTO `s_delivery_payment` VALUES ('2', '4');
INSERT INTO `s_delivery_payment` VALUES ('2', '5');
INSERT INTO `s_delivery_payment` VALUES ('2', '6');
INSERT INTO `s_delivery_payment` VALUES ('2', '7');
INSERT INTO `s_delivery_payment` VALUES ('2', '8');
INSERT INTO `s_delivery_payment` VALUES ('2', '9');
INSERT INTO `s_delivery_payment` VALUES ('3', '1');
INSERT INTO `s_delivery_payment` VALUES ('3', '2');
INSERT INTO `s_delivery_payment` VALUES ('3', '3');
INSERT INTO `s_delivery_payment` VALUES ('3', '4');
INSERT INTO `s_delivery_payment` VALUES ('3', '5');
INSERT INTO `s_delivery_payment` VALUES ('3', '6');
INSERT INTO `s_delivery_payment` VALUES ('3', '7');
INSERT INTO `s_delivery_payment` VALUES ('3', '8');
INSERT INTO `s_delivery_payment` VALUES ('3', '9');

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА s_features: структура
--
-- ----------------------------------------------------------------------------

DROP TABLE IF EXISTS `s_features`;

CREATE TABLE `s_features` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `position` int(11) NOT NULL,
  `in_filter` int(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `position` (`position`),
  KEY `in_filter` (`in_filter`)
) ENGINE=MyISAM AUTO_INCREMENT=160 DEFAULT CHARSET=utf8;

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА s_features: содержимое
--
-- ----------------------------------------------------------------------------

INSERT INTO `s_features` VALUES ('158', 'Размер', '158', '0');
INSERT INTO `s_features` VALUES ('159', 'Тучность', '159', '0');

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА s_feedbacks: структура
--
-- ----------------------------------------------------------------------------

DROP TABLE IF EXISTS `s_feedbacks`;

CREATE TABLE `s_feedbacks` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL,
  `ip` varchar(20) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `message` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА s_feedbacks: содержимое
--
-- ----------------------------------------------------------------------------


-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА s_groups: структура
--
-- ----------------------------------------------------------------------------

DROP TABLE IF EXISTS `s_groups`;

CREATE TABLE `s_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `discount` float(5,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА s_groups: содержимое
--
-- ----------------------------------------------------------------------------

INSERT INTO `s_groups` VALUES ('3', 'opt', '15.00');

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА s_images: структура
--
-- ----------------------------------------------------------------------------

DROP TABLE IF EXISTS `s_images`;

CREATE TABLE `s_images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `product_id` int(11) NOT NULL DEFAULT '0',
  `filename` varchar(255) NOT NULL DEFAULT '',
  `position` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `filename` (`filename`),
  KEY `product_id` (`product_id`),
  KEY `position` (`position`)
) ENGINE=MyISAM AUTO_INCREMENT=155 DEFAULT CHARSET=utf8;

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА s_images: содержимое
--
-- ----------------------------------------------------------------------------

INSERT INTO `s_images` VALUES ('125', '', '17', '20702549.jpg', '0');
INSERT INTO `s_images` VALUES ('145', '', '44', '726680-1.jpg', '0');
INSERT INTO `s_images` VALUES ('146', '', '44', '928353-1.jpg', '146');
INSERT INTO `s_images` VALUES ('147', '', '44', '806_1511-1.jpg', '147');
INSERT INTO `s_images` VALUES ('151', '', '45', 'ch.png', '1');
INSERT INTO `s_images` VALUES ('148', '', '44', 'FMnYyCvFXvs.jpg', '148');
INSERT INTO `s_images` VALUES ('150', '', '45', '2.jpg', '0');
INSERT INTO `s_images` VALUES ('152', '', '46', 'DSC_16751.jpg', '2');
INSERT INTO `s_images` VALUES ('153', '', '46', 'DSC_16752.jpg', '1');
INSERT INTO `s_images` VALUES ('154', '', '46', '22.jpg', '0');

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА s_labels: структура
--
-- ----------------------------------------------------------------------------

DROP TABLE IF EXISTS `s_labels`;

CREATE TABLE `s_labels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `color` varchar(6) NOT NULL,
  `position` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА s_labels: содержимое
--
-- ----------------------------------------------------------------------------

INSERT INTO `s_labels` VALUES ('4', 'перезвонить', 'ff00ff', '4');
INSERT INTO `s_labels` VALUES ('5', 'ожидается товар', '00d5fa', '5');

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА s_menu: структура
--
-- ----------------------------------------------------------------------------

DROP TABLE IF EXISTS `s_menu`;

CREATE TABLE `s_menu` (
  `id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `position` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА s_menu: содержимое
--
-- ----------------------------------------------------------------------------

INSERT INTO `s_menu` VALUES ('1', 'Основное меню', '1');
INSERT INTO `s_menu` VALUES ('2', 'Другие страницы', '2');

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА s_options: структура
--
-- ----------------------------------------------------------------------------

DROP TABLE IF EXISTS `s_options`;

CREATE TABLE `s_options` (
  `product_id` int(11) NOT NULL,
  `feature_id` int(11) NOT NULL,
  `value` varchar(1024) NOT NULL,
  PRIMARY KEY (`product_id`,`feature_id`),
  KEY `value` (`value`(333)),
  KEY `product_id` (`product_id`),
  KEY `feature_id` (`feature_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА s_options: содержимое
--
-- ----------------------------------------------------------------------------

INSERT INTO `s_options` VALUES ('46', '158', '1');
INSERT INTO `s_options` VALUES ('46', '159', '2');

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА s_orders: структура
--
-- ----------------------------------------------------------------------------

DROP TABLE IF EXISTS `s_orders`;

CREATE TABLE `s_orders` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `delivery_id` int(11) DEFAULT NULL,
  `delivery_price` float(10,2) NOT NULL DEFAULT '0.00',
  `payment_method_id` int(11) DEFAULT NULL,
  `paid` int(1) NOT NULL DEFAULT '0',
  `payment_date` datetime NOT NULL,
  `closed` tinyint(1) NOT NULL,
  `date` datetime DEFAULT NULL,
  `user_id` int(11) DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `address` varchar(255) NOT NULL DEFAULT '',
  `phone` varchar(255) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL,
  `comment` varchar(1024) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `url` varchar(255) DEFAULT NULL,
  `payment_details` text NOT NULL,
  `ip` varchar(15) NOT NULL,
  `total_price` float(10,2) NOT NULL,
  `note` varchar(1024) NOT NULL,
  `discount` float(5,2) NOT NULL,
  `coupon_discount` float(10,2) NOT NULL,
  `coupon_code` varchar(255) NOT NULL,
  `separate_delivery` int(1) NOT NULL DEFAULT '0',
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `login` (`user_id`),
  KEY `written_off` (`closed`),
  KEY `date` (`date`),
  KEY `status` (`status`),
  KEY `code` (`url`),
  KEY `payment_status` (`paid`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА s_orders: содержимое
--
-- ----------------------------------------------------------------------------

INSERT INTO `s_orders` VALUES ('5', '1', '120.00', '0', '0', '0000-00-00 00:00:00', '1', '2014-03-11 23:03:09', '0', 'фвіафвіа', 'Курская 13а', '380672671850', 'anatoliy.gatilov@gmail.com', 'asdf asdf asdf asdf', '2', 'a3950713c35e4ed5f8cfbbdbaba1e21d', '', '93.73.114.123', '580.00', '', '0.00', '0.00', '', '1', '2014-03-11 23:05:28');
INSERT INTO `s_orders` VALUES ('6', '3', '0.00', '9', '0', '0000-00-00 00:00:00', '1', '2014-03-12 21:30:54', '0', 'фыва', 'Курская 13а', '380672671850', 'anatoliy.gatilov@gmail.com', 'фы вафыва фыва фыва ', '1', 'cfca551271374c2524b66b20e7af6006', '', '93.73.114.123', '250.00', '', '0.00', '0.00', '', '0', '2014-03-13 08:21:00');
INSERT INTO `s_orders` VALUES ('7', '1', '50.00', NULL, '0', '0000-00-00 00:00:00', '0', '2014-03-31 09:55:43', '0', 'Александр', '', 'asdasd', 'problem_net@ukr.net', '', '3', '5c0f66f059f7fd0fb53ac8cf0186e323', '', '176.102.32.154', '250.00', '', '0.00', '0.00', '', '1', '2015-01-13 10:17:45');
INSERT INTO `s_orders` VALUES ('8', '3', '0.00', NULL, '0', '0000-00-00 00:00:00', '0', '2014-04-29 08:37:11', '0', 'Тимур', 'sdgjshd', '0682545444', 'timur_tt@ukr.net', 'sdgkhjdshkjfgsjdfh\\\r\nsdgjhsdg', '0', '1cd05446a94c0f4367264a6dde39d671', '', '195.138.75.176', '1900.00', '', '0.00', '0.00', '', '0', '2014-04-29 08:37:27');
INSERT INTO `s_orders` VALUES ('9', '3', '0.00', '9', '0', '0000-00-00 00:00:00', '1', '2015-01-27 11:19:48', '2', 'Timur', '', '555555', 'timur_tam@mail.ru', 'weqwereerqwer', '2', '5bc6a8180ed3767478afe068b7eb6d5a', '', '78.26.173.64', '700.00', '', '0.00', '0.00', '', '0', '2015-01-27 11:20:55');

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА s_orders_labels: структура
--
-- ----------------------------------------------------------------------------

DROP TABLE IF EXISTS `s_orders_labels`;

CREATE TABLE `s_orders_labels` (
  `order_id` int(11) NOT NULL,
  `label_id` int(11) NOT NULL,
  PRIMARY KEY (`order_id`,`label_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА s_orders_labels: содержимое
--
-- ----------------------------------------------------------------------------

INSERT INTO `s_orders_labels` VALUES ('1', '5');
INSERT INTO `s_orders_labels` VALUES ('2', '4');
INSERT INTO `s_orders_labels` VALUES ('9', '4');

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА s_pages: структура
--
-- ----------------------------------------------------------------------------

DROP TABLE IF EXISTS `s_pages`;

CREATE TABLE `s_pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(255) NOT NULL DEFAULT '',
  `name` varchar(255) NOT NULL DEFAULT '',
  `meta_title` varchar(500) NOT NULL,
  `meta_description` varchar(500) NOT NULL,
  `meta_keywords` varchar(500) NOT NULL,
  `body` longtext NOT NULL,
  `menu_id` int(11) NOT NULL DEFAULT '0',
  `position` int(11) NOT NULL DEFAULT '0',
  `visible` tinyint(1) NOT NULL DEFAULT '0',
  `header` varchar(1024) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `order_num` (`position`),
  KEY `url` (`url`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА s_pages: содержимое
--
-- ----------------------------------------------------------------------------

INSERT INTO `s_pages` VALUES ('1', '', 'Главная', 'Lemanta - Одежда от производителя', 'Женская и детская одежда от производителя в интернет-магазине Lemanta. Широкий выбор товара по доступным ценам. Качественный и сертифицированный материал. Доставка курьерской службой \"Новая Почта\" в любой уголок Украины. Наличный и безналичный расчет, через электронные платежные системы. ', 'Женская одежда, интернет-магазин одежды, детская одежда', '<p>Женская и детская одежда от производителя в интернет-магазине Lemanta. Широкий выбор товара по доступным ценам. Качественный и сертифицированный материал. Доставка курьерской службой \"Новая Почта\" в любой уголок Украины. Наличный и безналичный расчет, через электронные платежные системы.&nbsp;</p>', '1', '1', '1', 'Главная');
INSERT INTO `s_pages` VALUES ('2', 'oplata', 'Оплата', 'Оплата', 'Оплата', 'Оплата', '<p>Минимальная сумма заказа 1000 гривен.&nbsp;</p><p>Товар будет &nbsp;отправлен только после 100% оплаты.</p><p>Оплата товара может быть произведена как наличными (гривны), так и по безналичному расчёту (доставка не включается в стоимость товара).</p>', '1', '10', '1', 'Способы оплаты');
INSERT INTO `s_pages` VALUES ('3', 'dostavka', 'Доставка', 'Доставка', 'Доставка', 'Доставка', '<p>Доставка по городам Украины осуществляется транспортно-экспедиторскими компаниями-партнерами на основе&nbsp;<strong>100% предоплаты.</strong><b>&nbsp;</b>Стоимость доставки зависит от веса, объема, стоимости товара, способа доставки и расстояния до Вашего города. Рассчитывается по каждому конкретному заказу.<br /><br />Достаточно сделать заказ установленной формы (купить товар) и система Интернет-магазина после обработки, которая занимает 2-3 рабочих дня, вышлет Вам в электронном виде все необходимые условия доставки, включая счета для оплаты.&nbsp;</p><p><strong>Доставка до Вашего города считается отдельно транспортно-экспедиторскими компаниями.</strong></p>', '1', '9', '1', 'Способы доставки');
INSERT INTO `s_pages` VALUES ('4', 'blog', 'Новости', 'Новости', '', 'Новости', '', '1', '8', '1', 'Новости');
INSERT INTO `s_pages` VALUES ('5', '404', '', 'Страница не найдена', 'Страница не найдена', 'Страница не найдена', '<p>Страница не найдена</p>', '2', '5', '1', 'Страница не найдена');
INSERT INTO `s_pages` VALUES ('6', 'contact', 'Контакты', 'Контакты', 'Контакты', 'Контакты', '<p>г. Одесса&nbsp;</p><p>Промышленный рынок 7 км.</p><p>2 площадка&nbsp;</p><p></p><p>т. (098) 053-22-33</p><p>E-mail: <a href=\"mailto:office@lemanta.com\" target=\"_blank\">office@lemanta.com</a></p><p>Skype: Lemanta2014</p>', '1', '11', '1', 'Контакты');
INSERT INTO `s_pages` VALUES ('7', 'products', 'Все товары', 'Все товары', '', 'Все товары', '', '2', '7', '1', 'Все товары');
INSERT INTO `s_pages` VALUES ('8', 'catalog/devochki', 'Девочки', 'Девочки', '', 'Девочки', '', '1', '4', '1', 'Девочки');
INSERT INTO `s_pages` VALUES ('11', 'catalog/zhenschiny', 'Женщины', 'Женщины', '', 'Женщины', '', '1', '3', '1', 'Женщины');
INSERT INTO `s_pages` VALUES ('9', 'catalog/boys', 'Мальчики', 'Мальчики', '', 'Мальчики', '', '1', '6', '1', 'Мальчики');

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА s_payment_methods: структура
--
-- ----------------------------------------------------------------------------

DROP TABLE IF EXISTS `s_payment_methods`;

CREATE TABLE `s_payment_methods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `module` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `currency_id` float NOT NULL,
  `settings` text NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '0',
  `position` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `position` (`position`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА s_payment_methods: содержимое
--
-- ----------------------------------------------------------------------------

INSERT INTO `s_payment_methods` VALUES ('1', 'Receipt', 'Квитанция', '<p>Вы можете распечатать квитанцию и оплатить её в любом отделении банка.</p>', '2', 'a:10:{s:9:\"recipient\";s:65:\"ООО \"Великолепный интернет-магазин\"\";s:3:\"inn\";s:5:\"12345\";s:7:\"account\";s:6:\"223456\";s:4:\"bank\";s:18:\"Альфабанк\";s:3:\"bik\";s:6:\"556677\";s:21:\"correspondent_account\";s:11:\"77777755555\";s:8:\"banknote\";s:7:\"руб.\";s:5:\"pense\";s:7:\"коп.\";s:5:\"purse\";s:2:\"ru\";s:10:\"secret_key\";s:0:\"\";}', '0', '2');
INSERT INTO `s_payment_methods` VALUES ('2', 'Webmoney', 'Webmoney wmz', '<p></p><div><p>Оплата через платежную систему&nbsp;<a href=\"http://www.webmoney.ru\">WebMoney</a>. У вас должен быть счет в этой системе для того, чтобы произвести оплату. Сразу после оформления заказа вы будете перенаправлены на специальную страницу системы WebMoney, где сможете произвести платеж в титульных знаках WMZ.</p></div><p>&nbsp;</p>', '2', 'a:2:{s:5:\"purse\";s:13:\"Z111111111111\";s:10:\"secret_key\";s:13:\"testsecretkey\";}', '1', '1');
INSERT INTO `s_payment_methods` VALUES ('3', 'Robokassa', 'Робокасса', '<p><span>RBK Money &ndash; это электронная платежная система, с помощью которой Вы сможете совершать платежи с персонального компьютера, коммуникатора или мобильного телефона.</span></p>', '2', 'a:4:{s:5:\"login\";s:0:\"\";s:9:\"password1\";s:0:\"\";s:9:\"password2\";s:0:\"\";s:8:\"language\";s:2:\"ru\";}', '1', '3');
INSERT INTO `s_payment_methods` VALUES ('4', 'Paypal', 'PayPal', '<p>Совершайте покупки безопасно, без раскрытия информации о своей кредитной карте. PayPal защитит вас, если возникнут проблемы с покупкой</p>', '1', 'a:16:{s:8:\"business\";s:0:\"\";s:4:\"mode\";s:7:\"sandbox\";s:9:\"recipient\";s:0:\"\";s:3:\"inn\";s:0:\"\";s:7:\"account\";s:0:\"\";s:4:\"bank\";s:0:\"\";s:3:\"bik\";s:0:\"\";s:21:\"correspondent_account\";s:0:\"\";s:8:\"banknote\";s:0:\"\";s:5:\"pense\";s:0:\"\";s:5:\"login\";s:0:\"\";s:9:\"password1\";s:0:\"\";s:9:\"password2\";s:0:\"\";s:8:\"language\";s:2:\"ru\";s:5:\"purse\";s:0:\"\";s:10:\"secret_key\";s:0:\"\";}', '0', '4');
INSERT INTO `s_payment_methods` VALUES ('5', 'Interkassa', 'Оплата через Интеркассу', '<p><span>Это удобный в использовании сервис, подключение к которому позволит Интернет-магазинам, веб-сайтам и прочим торговым площадкам принимать все возможные формы оплаты в максимально короткие сроки.</span></p>', '2', 'a:2:{s:18:\"interkassa_shop_id\";s:3:\"123\";s:21:\"interkassa_secret_key\";s:3:\"123\";}', '0', '5');
INSERT INTO `s_payment_methods` VALUES ('6', 'Liqpay', 'Оплата картой через Liqpay.com', '<p><span>Благодаря своей открытости и универсальности LiqPAY стремительно интегрируется со многими платежными системами и платформами и становится стандартом платежных операций.</span></p>', '2', 'a:5:{s:9:\"liqpay_id\";s:3:\"123\";s:11:\"liqpay_sign\";s:3:\"123\";s:12:\"pay_way_card\";s:1:\"1\";s:14:\"pay_way_liqpay\";s:1:\"1\";s:15:\"pay_way_delayed\";s:1:\"1\";}', '0', '6');
INSERT INTO `s_payment_methods` VALUES ('7', 'Pay2Pay', 'Оплата через Pay2Pay', '<p>Универсальный платежный сервис Pay2Pay призван облегчить и максимально упростить процесс приема электронных платежей на Вашем сайте. Мы открыты для всего нового и сверхсовременного.</p>', '2', 'a:5:{s:18:\"pay2pay_merchantid\";s:3:\"123\";s:14:\"pay2pay_secret\";s:3:\"123\";s:14:\"pay2pay_hidden\";s:3:\"123\";s:15:\"pay2pay_paymode\";s:3:\"123\";s:16:\"pay2pay_testmode\";s:1:\"1\";}', '0', '7');
INSERT INTO `s_payment_methods` VALUES ('8', 'Qiwi', 'Оплатить через QIWI', '<p><span>QIWI &mdash; удобный сервис для оплаты повседневных услуг</span></p>', '2', 'a:2:{s:10:\"qiwi_login\";s:3:\"123\";s:13:\"qiwi_password\";s:3:\"123\";}', '0', '8');
INSERT INTO `s_payment_methods` VALUES ('9', 'null', 'Приват 24', '<p>Номер счета для пополнения: хххх хххх хххх хххх</p><p>Получатель: Фамилия Имя Отчество</p>', '2', 'N;', '1', '9');

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА s_products: структура
--
-- ----------------------------------------------------------------------------

DROP TABLE IF EXISTS `s_products`;

CREATE TABLE `s_products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(255) NOT NULL DEFAULT '',
  `brand_id` int(11) DEFAULT NULL,
  `name` varchar(500) NOT NULL,
  `annotation` text NOT NULL,
  `body` longtext NOT NULL,
  `visible` tinyint(1) NOT NULL DEFAULT '1',
  `position` int(11) NOT NULL DEFAULT '0',
  `meta_title` varchar(500) NOT NULL,
  `meta_keywords` varchar(500) NOT NULL,
  `meta_description` varchar(500) NOT NULL,
  `created` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `featured` tinyint(1) DEFAULT NULL,
  `external_id` varchar(36) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `url` (`url`),
  KEY `brand_id` (`brand_id`),
  KEY `visible` (`visible`),
  KEY `position` (`position`),
  KEY `external_id` (`external_id`),
  KEY `hit` (`featured`),
  KEY `name` (`name`(333))
) ENGINE=MyISAM AUTO_INCREMENT=47 DEFAULT CHARSET=utf8;

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА s_products: содержимое
--
-- ----------------------------------------------------------------------------

INSERT INTO `s_products` VALUES ('17', 'kostyum-belyj', '0', 'Костюм белый', '<p>Samsung S7070 Diva &mdash; отличный телефон, оснащенный TFT-дисплеем, отображающим до 16 млн. цветов, с диагональю 2.8\" и камерой на 3 Mpx, делающей снимки с разрешением 2048 x 1536 px. Оснащен аккумулятором на 960 mAh, который позволяет аппарату работать до 660 часов в режиме ожидания и до 8 в режиме разговора. Для коммуникации может предложить: WAP браузер, EDGE, стерео Bluetooth, и, конечно, USB-порт.</p>', '<p>Одного взгляда на этот телефон достаточно, чтобы понять, что его покупатели - это женщины. Задняя панель сделана из белого рельефного пластика с блестящим оттенком. Лицевая панель украшена серебристыми узорами, а центральная клавиша, выполненная в стиле ограненного бриллианта.</p>', '1', '39', 'Костюм белый', 'Samsung S7070 Diva, Samsung, Мобильные телефоны', 'Samsung S7070 Diva &mdash; отличный телефон, оснащенный TFT-дисплеем, отображающим до 16 млн. цветов, с диагональю 2.8\" и камерой на 3 Mpx, делающей снимки с разрешением 2048 x 1536 px. Оснащен аккумулятором на 960 mAh, который позволяет аппарату работать до 660 часов в режиме ожидания и до 8 в режиме разговора. Для коммуникации может предложить: WAP браузер, EDGE, стерео Bluetooth, и, конечно, USB-порт.', '2011-10-18 17:16:54', '1', '');
INSERT INTO `s_products` VALUES ('44', 'kidtemp', '12', 'темп', '', '', '1', '44', 'темп', 'темп, Платья, Платья', 'платье темп', '2014-04-16 13:35:36', NULL, '');
INSERT INTO `s_products` VALUES ('45', 'plate', '0', 'Платье', '', '', '1', '45', 'Платье', 'Платье, Женщины', '', '2015-01-22 08:14:17', '1', '');
INSERT INTO `s_products` VALUES ('46', 'sgsv', '0', 'sgsv', '', '', '1', '46', 'sgsv', 'sgsv, Женщины', '', '2015-01-23 18:06:08', NULL, '');

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА s_products_categories: структура
--
-- ----------------------------------------------------------------------------

DROP TABLE IF EXISTS `s_products_categories`;

CREATE TABLE `s_products_categories` (
  `product_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `position` int(11) NOT NULL,
  PRIMARY KEY (`product_id`,`category_id`),
  KEY `position` (`position`),
  KEY `product_id` (`product_id`),
  KEY `category_id` (`category_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА s_products_categories: содержимое
--
-- ----------------------------------------------------------------------------

INSERT INTO `s_products_categories` VALUES ('17', '11', '0');
INSERT INTO `s_products_categories` VALUES ('17', '8', '1');
INSERT INTO `s_products_categories` VALUES ('44', '10', '0');
INSERT INTO `s_products_categories` VALUES ('45', '2', '0');
INSERT INTO `s_products_categories` VALUES ('46', '2', '0');

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА s_purchases: структура
--
-- ----------------------------------------------------------------------------

DROP TABLE IF EXISTS `s_purchases`;

CREATE TABLE `s_purchases` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL DEFAULT '0',
  `product_id` int(11) DEFAULT '0',
  `variant_id` int(11) DEFAULT NULL,
  `product_name` varchar(255) NOT NULL DEFAULT '',
  `variant_name` varchar(255) NOT NULL,
  `price` float(10,2) NOT NULL DEFAULT '0.00',
  `amount` int(11) NOT NULL DEFAULT '0',
  `sku` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`),
  KEY `product_id` (`product_id`),
  KEY `variant_id` (`variant_id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА s_purchases: содержимое
--
-- ----------------------------------------------------------------------------

INSERT INTO `s_purchases` VALUES ('8', '5', NULL, NULL, 'Костюм', '', '530.00', '1', '');
INSERT INTO `s_purchases` VALUES ('9', '5', NULL, NULL, 'Спортивный костюм', '', '50.00', '1', '');
INSERT INTO `s_purchases` VALUES ('10', '6', NULL, NULL, 'Платье', 'XL', '250.00', '1', 'F59329-XL');
INSERT INTO `s_purchases` VALUES ('11', '7', NULL, NULL, 'Платье', 'XL', '250.00', '1', 'F59329-XL');
INSERT INTO `s_purchases` VALUES ('12', '8', NULL, NULL, 'Платье', 'XL', '250.00', '2', 'F59329-XL');
INSERT INTO `s_purchases` VALUES ('13', '8', NULL, NULL, 'Платье', 'M', '240.00', '2', 'F59329-M');
INSERT INTO `s_purchases` VALUES ('14', '8', NULL, NULL, 'Платье', 'L', '230.00', '4', 'F59329-L');
INSERT INTO `s_purchases` VALUES ('15', '9', '45', '64', 'Платье', '36', '350.00', '1', '1');
INSERT INTO `s_purchases` VALUES ('16', '9', '45', '67', 'Платье', '42', '350.00', '1', '1');

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА s_related_products: структура
--
-- ----------------------------------------------------------------------------

DROP TABLE IF EXISTS `s_related_products`;

CREATE TABLE `s_related_products` (
  `product_id` int(11) NOT NULL,
  `related_id` int(11) NOT NULL,
  `position` int(11) NOT NULL,
  PRIMARY KEY (`product_id`,`related_id`),
  KEY `position` (`position`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА s_related_products: содержимое
--
-- ----------------------------------------------------------------------------

INSERT INTO `s_related_products` VALUES ('17', '0', '0');
INSERT INTO `s_related_products` VALUES ('44', '17', '0');

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА s_settings: структура
--
-- ----------------------------------------------------------------------------

DROP TABLE IF EXISTS `s_settings`;

CREATE TABLE `s_settings` (
  `setting_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `value` text NOT NULL,
  PRIMARY KEY (`setting_id`)
) ENGINE=MyISAM AUTO_INCREMENT=123 DEFAULT CHARSET=utf8;

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА s_settings: содержимое
--
-- ----------------------------------------------------------------------------

INSERT INTO `s_settings` VALUES ('8', 'site_name', 'Lemanta');
INSERT INTO `s_settings` VALUES ('9', 'company_name', 'Интернет-магазин женской одежды');
INSERT INTO `s_settings` VALUES ('50', 'units', 'шт');
INSERT INTO `s_settings` VALUES ('53', 'date_format', 'd.m.Y');
INSERT INTO `s_settings` VALUES ('54', 'order_email', 'Lemanta <office@lemanta.com>');
INSERT INTO `s_settings` VALUES ('55', 'comment_email', 'Lemanta <office@lemanta.com>');
INSERT INTO `s_settings` VALUES ('56', 'notify_from_email', 'Lemanta <office@lemanta.com>');
INSERT INTO `s_settings` VALUES ('57', 'decimals_point', ',');
INSERT INTO `s_settings` VALUES ('58', 'thousands_separator', ' ');
INSERT INTO `s_settings` VALUES ('59', 'products_num', '8');
INSERT INTO `s_settings` VALUES ('60', 'products_num_admin', '20');
INSERT INTO `s_settings` VALUES ('30', 'theme', 'lemanta');
INSERT INTO `s_settings` VALUES ('33', 'products_num', '8');
INSERT INTO `s_settings` VALUES ('34', 'products_num_admin', '20');
INSERT INTO `s_settings` VALUES ('111', 'last_1c_orders_export_date', '2011-07-30 21:31:56');
INSERT INTO `s_settings` VALUES ('112', 'license', 'bhbcfgkhfe iomjlglmpl rqwqxrtpz6 898495c7 cfee');
INSERT INTO `s_settings` VALUES ('113', 'max_order_amount', '50');
INSERT INTO `s_settings` VALUES ('114', 'watermark_offset_x', '150');
INSERT INTO `s_settings` VALUES ('115', 'watermark_offset_y', '150');
INSERT INTO `s_settings` VALUES ('116', 'watermark_transparency', '100');
INSERT INTO `s_settings` VALUES ('117', 'images_sharpen', '20');
INSERT INTO `s_settings` VALUES ('119', 'admin_email', 'ruslan ostap <rusostap@mail.ru>');
INSERT INTO `s_settings` VALUES ('120', 'pz_server', '');
INSERT INTO `s_settings` VALUES ('121', 'pz_password', '');
INSERT INTO `s_settings` VALUES ('122', 'pz_phones', 'a:1:{s:5:\"admin\";s:0:\"\";}');

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА s_users: структура
--
-- ----------------------------------------------------------------------------

DROP TABLE IF EXISTS `s_users`;

CREATE TABLE `s_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL DEFAULT '',
  `name` varchar(255) NOT NULL DEFAULT '',
  `group_id` int(11) NOT NULL DEFAULT '0',
  `enabled` tinyint(1) NOT NULL DEFAULT '0',
  `last_ip` varchar(15) DEFAULT NULL,
  `created` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `email` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА s_users: содержимое
--
-- ----------------------------------------------------------------------------

INSERT INTO `s_users` VALUES ('2', 'timur_tam@mail.ru', 'c26808abea741a59a45be360dc6ecd72', 'Timur', '0', '0', '78.26.173.64', '2015-01-27 11:18:39');

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА s_variants: структура
--
-- ----------------------------------------------------------------------------

DROP TABLE IF EXISTS `s_variants`;

CREATE TABLE `s_variants` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `sku` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` float(14,2) NOT NULL,
  `compare_price` float(14,2) DEFAULT NULL,
  `stock` mediumint(9) DEFAULT NULL,
  `position` int(11) NOT NULL,
  `attachment` varchar(255) NOT NULL,
  `external_id` varchar(36) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  KEY `sku` (`sku`),
  KEY `price` (`price`),
  KEY `stock` (`stock`),
  KEY `position` (`position`),
  KEY `external_id` (`external_id`)
) ENGINE=MyISAM AUTO_INCREMENT=70 DEFAULT CHARSET=utf8;

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА s_variants: содержимое
--
-- ----------------------------------------------------------------------------

INSERT INTO `s_variants` VALUES ('61', '17', '78', '40', '500.00', '0.00', NULL, '61', '', '');
INSERT INTO `s_variants` VALUES ('60', '17', '78', '38', '500.00', '0.00', NULL, '60', '', '');
INSERT INTO `s_variants` VALUES ('25', '17', '78', '36', '500.00', '0.00', '10', '25', '', '');
INSERT INTO `s_variants` VALUES ('57', '44', '13232123', '36', '123.00', '200.00', '1', '57', '', '');
INSERT INTO `s_variants` VALUES ('62', '44', '', '38', '200.00', '300.00', '10', '62', '', '');
INSERT INTO `s_variants` VALUES ('63', '44', '', '40', '250.00', '350.00', '5', '63', '', '');
INSERT INTO `s_variants` VALUES ('64', '45', '1', '36', '350.00', '0.00', NULL, '64', '', '');
INSERT INTO `s_variants` VALUES ('65', '45', '1', '38', '350.00', '0.00', NULL, '65', '', '');
INSERT INTO `s_variants` VALUES ('66', '45', '1', '40', '350.00', '0.00', NULL, '66', '', '');
INSERT INTO `s_variants` VALUES ('67', '45', '1', '42', '350.00', '0.00', NULL, '67', '', '');
INSERT INTO `s_variants` VALUES ('68', '46', 'g122', 'dbgas', '34.00', '0.00', '0', '68', '', '');
INSERT INTO `s_variants` VALUES ('69', '46', '', '', '0.00', '0.00', NULL, '69', '', '');

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА schools: структура
--
-- ----------------------------------------------------------------------------

DROP TABLE IF EXISTS `schools`;

CREATE TABLE `schools` (
  `school_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'Идентификатор учебного заведения',
  `country_id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Идентификатор страны',
  `region_id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Идентификатор области',
  `town_id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Идентификатор города',
  `enabled` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'Разрешена ли запись к использованию',
  `url` varchar(256) NOT NULL DEFAULT '' COMMENT 'Адрес страницы записи',
  `meta_title` varchar(256) NOT NULL DEFAULT '' COMMENT 'Мета заголовок страницы записи',
  `meta_keywords` varchar(512) NOT NULL DEFAULT '' COMMENT 'Мета ключевые слова страницы записи',
  `meta_description` varchar(512) NOT NULL DEFAULT '' COMMENT 'Мета описание страницы записи',
  `name` varchar(256) NOT NULL DEFAULT '' COMMENT 'Название города',
  `description` text NOT NULL COMMENT 'Описание города',
  `seo_description` text NOT NULL COMMENT 'SEO текст',
  `type_id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Идентификатор типа заведения',
  `phone` varchar(256) NOT NULL DEFAULT '' COMMENT 'Стационарные телефоны заведения',
  `mobile` varchar(256) NOT NULL DEFAULT '' COMMENT 'Мобильные телефоны заведения',
  `director` varchar(256) NOT NULL DEFAULT '' COMMENT 'Директор заведения',
  `email` varchar(256) NOT NULL DEFAULT '' COMMENT 'Емейл заведения',
  `lessons_ids` text NOT NULL COMMENT 'Идентификаторы преподаваемых предметов',
  `classes_ids` text NOT NULL COMMENT 'Идентификаторы классов',
  `ringb` varchar(512) NOT NULL DEFAULT '' COMMENT 'Время начала уроков',
  `ringe` varchar(512) NOT NULL DEFAULT '' COMMENT 'Время конца уроков',
  `collective1` text NOT NULL COMMENT 'Коллектив заведения - секция 1',
  `collective2` text NOT NULL COMMENT 'Коллектив заведения - секция 2',
  `collective3` text NOT NULL COMMENT 'Коллектив заведения - секция 3',
  `collective4` text NOT NULL COMMENT 'Коллектив заведения - секция 4',
  `address` varchar(512) NOT NULL DEFAULT '' COMMENT 'Адрес заведения',
  `images` text NOT NULL COMMENT 'Изображения записи',
  `images_alts` text NOT NULL COMMENT 'Подписи изображений записи',
  `images_texts` longtext NOT NULL COMMENT 'Описания изображений записи',
  `images_view` text NOT NULL COMMENT 'Признаки использования в слайдере изображений записи',
  `tags` varchar(256) NOT NULL DEFAULT '' COMMENT 'Теги записи',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Дата создания записи',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Дата изменения записи',
  `browsed` int(11) NOT NULL DEFAULT '0' COMMENT 'Количество просмотров записи',
  `order_num` int(11) NOT NULL DEFAULT '0' COMMENT 'Порядковый номер записи',
  PRIMARY KEY (`school_id`),
  KEY `country_id` (`country_id`),
  KEY `region_id` (`region_id`),
  KEY `town_id` (`town_id`),
  KEY `enabled` (`enabled`),
  KEY `url` (`url`),
  KEY `name` (`name`),
  KEY `type_id` (`type_id`),
  KEY `phone` (`phone`),
  KEY `mobile` (`mobile`),
  KEY `director` (`director`),
  KEY `email` (`email`),
  KEY `tags` (`tags`),
  KEY `created` (`created`),
  KEY `modified` (`modified`),
  KEY `browsed` (`browsed`),
  KEY `order_num` (`order_num`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА schools: содержимое
--
-- ----------------------------------------------------------------------------


-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА schools_classes: структура
--
-- ----------------------------------------------------------------------------

DROP TABLE IF EXISTS `schools_classes`;

CREATE TABLE `schools_classes` (
  `class_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'Идентификатор класса учебного заведения',
  `name` varchar(256) NOT NULL DEFAULT '' COMMENT 'Название класса учебного заведения',
  `lessons_ids` text NOT NULL COMMENT 'Идентификаторы преподаваемых предметов',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Дата создания записи',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Дата изменения записи',
  PRIMARY KEY (`class_id`),
  KEY `name` (`name`),
  KEY `created` (`created`),
  KEY `modified` (`modified`)
) ENGINE=MyISAM AUTO_INCREMENT=34 DEFAULT CHARSET=utf8;

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА schools_classes: содержимое
--
-- ----------------------------------------------------------------------------

INSERT INTO `schools_classes` VALUES ('1', '1-А класс', '', '2011-11-12 16:37:16', '0000-00-00 00:00:00');
INSERT INTO `schools_classes` VALUES ('2', '1-Б класс', '', '2011-11-12 16:37:16', '0000-00-00 00:00:00');
INSERT INTO `schools_classes` VALUES ('3', '1-В класс', '', '2011-11-12 16:37:16', '0000-00-00 00:00:00');
INSERT INTO `schools_classes` VALUES ('4', '2-А класс', '', '2011-11-12 16:37:16', '0000-00-00 00:00:00');
INSERT INTO `schools_classes` VALUES ('5', '2-Б класс', '', '2011-11-12 16:37:16', '0000-00-00 00:00:00');
INSERT INTO `schools_classes` VALUES ('6', '2-В класс', '', '2011-11-12 16:37:16', '0000-00-00 00:00:00');
INSERT INTO `schools_classes` VALUES ('7', '3-А класс', '', '2011-11-12 16:37:16', '0000-00-00 00:00:00');
INSERT INTO `schools_classes` VALUES ('8', '3-Б класс', '', '2011-11-12 16:37:16', '0000-00-00 00:00:00');
INSERT INTO `schools_classes` VALUES ('9', '3-В класс', '', '2011-11-12 16:37:16', '0000-00-00 00:00:00');
INSERT INTO `schools_classes` VALUES ('10', '4-А класс', '', '2011-11-12 16:37:16', '0000-00-00 00:00:00');
INSERT INTO `schools_classes` VALUES ('11', '4-Б класс', '', '2011-11-12 16:37:16', '0000-00-00 00:00:00');
INSERT INTO `schools_classes` VALUES ('12', '4-В класс', '', '2011-11-12 16:37:16', '0000-00-00 00:00:00');
INSERT INTO `schools_classes` VALUES ('13', '5-А класс', '', '2011-11-12 16:37:16', '0000-00-00 00:00:00');
INSERT INTO `schools_classes` VALUES ('14', '5-Б класс', '', '2011-11-12 16:37:16', '0000-00-00 00:00:00');
INSERT INTO `schools_classes` VALUES ('15', '5-В класс', '', '2011-11-12 16:37:16', '0000-00-00 00:00:00');
INSERT INTO `schools_classes` VALUES ('16', '6-А класс', '', '2011-11-12 16:37:16', '0000-00-00 00:00:00');
INSERT INTO `schools_classes` VALUES ('17', '6-Б класс', '', '2011-11-12 16:37:16', '0000-00-00 00:00:00');
INSERT INTO `schools_classes` VALUES ('18', '6-В класс', '', '2011-11-12 16:37:16', '0000-00-00 00:00:00');
INSERT INTO `schools_classes` VALUES ('19', '7-А класс', '', '2011-11-12 16:37:16', '0000-00-00 00:00:00');
INSERT INTO `schools_classes` VALUES ('20', '7-Б класс', '', '2011-11-12 16:37:16', '0000-00-00 00:00:00');
INSERT INTO `schools_classes` VALUES ('21', '7-В класс', '', '2011-11-12 16:37:16', '0000-00-00 00:00:00');
INSERT INTO `schools_classes` VALUES ('22', '8-А класс', '', '2011-11-12 16:37:16', '0000-00-00 00:00:00');
INSERT INTO `schools_classes` VALUES ('23', '8-Б класс', '', '2011-11-12 16:37:16', '0000-00-00 00:00:00');
INSERT INTO `schools_classes` VALUES ('24', '8-В класс', '', '2011-11-12 16:37:16', '0000-00-00 00:00:00');
INSERT INTO `schools_classes` VALUES ('25', '9-А класс', '', '2011-11-12 16:37:16', '0000-00-00 00:00:00');
INSERT INTO `schools_classes` VALUES ('26', '9-Б класс', '', '2011-11-12 16:37:16', '0000-00-00 00:00:00');
INSERT INTO `schools_classes` VALUES ('27', '9-В класс', '', '2011-11-12 16:37:16', '0000-00-00 00:00:00');
INSERT INTO `schools_classes` VALUES ('28', '10-А класс', '', '2011-11-12 16:37:16', '0000-00-00 00:00:00');
INSERT INTO `schools_classes` VALUES ('29', '10-Б класс', '', '2011-11-12 16:37:16', '0000-00-00 00:00:00');
INSERT INTO `schools_classes` VALUES ('30', '10-В класс', '', '2011-11-12 16:37:16', '0000-00-00 00:00:00');
INSERT INTO `schools_classes` VALUES ('31', '11-А класс', '', '2011-11-12 16:37:16', '0000-00-00 00:00:00');
INSERT INTO `schools_classes` VALUES ('32', '11-Б класс', '', '2011-11-12 16:37:16', '0000-00-00 00:00:00');
INSERT INTO `schools_classes` VALUES ('33', '11-В класс', '', '2011-11-12 16:37:16', '0000-00-00 00:00:00');

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА schools_lessons: структура
--
-- ----------------------------------------------------------------------------

DROP TABLE IF EXISTS `schools_lessons`;

CREATE TABLE `schools_lessons` (
  `lesson_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'Идентификатор предмета учебного заведения',
  `name` varchar(256) NOT NULL DEFAULT '' COMMENT 'Название предмета учебного заведения',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Дата создания записи',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Дата изменения записи',
  PRIMARY KEY (`lesson_id`),
  KEY `name` (`name`),
  KEY `created` (`created`),
  KEY `modified` (`modified`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА schools_lessons: содержимое
--
-- ----------------------------------------------------------------------------

INSERT INTO `schools_lessons` VALUES ('1', 'Физика', '2011-11-12 16:37:16', '0000-00-00 00:00:00');
INSERT INTO `schools_lessons` VALUES ('2', 'Алгебра', '2011-11-12 16:37:16', '0000-00-00 00:00:00');
INSERT INTO `schools_lessons` VALUES ('3', 'Английский язык', '2011-11-12 16:37:16', '0000-00-00 00:00:00');
INSERT INTO `schools_lessons` VALUES ('4', 'Биология', '2011-11-12 16:37:16', '0000-00-00 00:00:00');
INSERT INTO `schools_lessons` VALUES ('5', 'География', '2011-11-12 16:37:16', '0000-00-00 00:00:00');
INSERT INTO `schools_lessons` VALUES ('6', 'Геометрия', '2011-11-12 16:37:16', '0000-00-00 00:00:00');
INSERT INTO `schools_lessons` VALUES ('7', 'Изобразительное искусство', '2011-11-12 16:37:16', '0000-00-00 00:00:00');
INSERT INTO `schools_lessons` VALUES ('8', 'Информатика и ИКТ', '2011-11-12 16:37:16', '0000-00-00 00:00:00');
INSERT INTO `schools_lessons` VALUES ('9', 'История', '2011-11-12 16:37:16', '0000-00-00 00:00:00');
INSERT INTO `schools_lessons` VALUES ('10', 'Русская литература', '2011-11-12 16:37:16', '0000-00-00 00:00:00');
INSERT INTO `schools_lessons` VALUES ('11', 'МХК', '2011-11-12 16:37:16', '0000-00-00 00:00:00');
INSERT INTO `schools_lessons` VALUES ('12', 'Математика', '2011-11-12 16:37:16', '0000-00-00 00:00:00');
INSERT INTO `schools_lessons` VALUES ('13', 'Немецкий язык', '2011-11-12 16:37:16', '0000-00-00 00:00:00');
INSERT INTO `schools_lessons` VALUES ('14', 'Обществознание', '2011-11-12 16:37:16', '0000-00-00 00:00:00');
INSERT INTO `schools_lessons` VALUES ('15', 'Основы безопасности жизнедеятельности', '2011-11-12 16:37:16', '0000-00-00 00:00:00');
INSERT INTO `schools_lessons` VALUES ('16', 'Природоведение', '2011-11-12 16:37:16', '0000-00-00 00:00:00');
INSERT INTO `schools_lessons` VALUES ('17', 'Русский язык', '2011-11-12 16:37:16', '0000-00-00 00:00:00');
INSERT INTO `schools_lessons` VALUES ('18', 'Технология', '2011-11-12 16:37:16', '0000-00-00 00:00:00');
INSERT INTO `schools_lessons` VALUES ('19', 'Физкультура', '2011-11-12 16:37:16', '0000-00-00 00:00:00');
INSERT INTO `schools_lessons` VALUES ('20', 'Французский язык', '2011-11-12 16:37:16', '0000-00-00 00:00:00');
INSERT INTO `schools_lessons` VALUES ('21', 'Химия', '2011-11-12 16:37:16', '0000-00-00 00:00:00');
INSERT INTO `schools_lessons` VALUES ('22', 'Черчение', '2011-11-12 16:37:16', '0000-00-00 00:00:00');
INSERT INTO `schools_lessons` VALUES ('23', 'Чтение', '2011-11-12 16:37:16', '0000-00-00 00:00:00');

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА schools_types: структура
--
-- ----------------------------------------------------------------------------

DROP TABLE IF EXISTS `schools_types`;

CREATE TABLE `schools_types` (
  `type_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'Идентификатор типа учебного заведения',
  `name` varchar(256) NOT NULL DEFAULT '' COMMENT 'Название типа учебного заведения',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Дата создания записи',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Дата изменения записи',
  PRIMARY KEY (`type_id`),
  KEY `name` (`name`),
  KEY `created` (`created`),
  KEY `modified` (`modified`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА schools_types: содержимое
--
-- ----------------------------------------------------------------------------

INSERT INTO `schools_types` VALUES ('1', 'Вечерняя школа', '2011-11-12 16:37:16', '0000-00-00 00:00:00');
INSERT INTO `schools_types` VALUES ('2', 'Гимназия', '2011-11-12 16:37:16', '0000-00-00 00:00:00');
INSERT INTO `schools_types` VALUES ('3', 'Детский дом', '2011-11-12 16:37:16', '0000-00-00 00:00:00');
INSERT INTO `schools_types` VALUES ('4', 'Детский сад', '2011-11-12 16:37:16', '0000-00-00 00:00:00');
INSERT INTO `schools_types` VALUES ('5', 'Кадетский корпус', '2011-11-12 16:37:16', '0000-00-00 00:00:00');
INSERT INTO `schools_types` VALUES ('6', 'Колледж', '2011-11-12 16:37:16', '0000-00-00 00:00:00');
INSERT INTO `schools_types` VALUES ('7', 'Лицей', '2011-11-12 16:37:16', '0000-00-00 00:00:00');
INSERT INTO `schools_types` VALUES ('8', 'Общеобразовательная школа', '2011-11-12 16:37:16', '0000-00-00 00:00:00');
INSERT INTO `schools_types` VALUES ('9', 'Техникум', '2011-11-12 16:37:16', '0000-00-00 00:00:00');
INSERT INTO `schools_types` VALUES ('10', 'Училище', '2011-11-12 16:37:16', '0000-00-00 00:00:00');
INSERT INTO `schools_types` VALUES ('11', 'Физико-математическая школа', '2011-11-12 16:37:16', '0000-00-00 00:00:00');
INSERT INTO `schools_types` VALUES ('12', 'Центр дополнительного образования', '2011-11-12 16:37:16', '0000-00-00 00:00:00');
INSERT INTO `schools_types` VALUES ('13', 'Центр образования', '2011-11-12 16:37:16', '0000-00-00 00:00:00');
INSERT INTO `schools_types` VALUES ('14', 'Частная школа', '2011-11-12 16:37:16', '0000-00-00 00:00:00');
INSERT INTO `schools_types` VALUES ('15', 'Школа-интернат', '2011-11-12 16:37:16', '0000-00-00 00:00:00');

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА searches: структура
--
-- ----------------------------------------------------------------------------

DROP TABLE IF EXISTS `searches`;

CREATE TABLE `searches` (
  `search_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'Идентификатор поисковой фразы',
  `name` varchar(256) NOT NULL DEFAULT '' COMMENT 'Поисковая фраза',
  `escort_url` varchar(256) NOT NULL DEFAULT '' COMMENT 'Сопровождаемый URL',
  `target_url` varchar(256) NOT NULL DEFAULT '' COMMENT 'Предлагавшийся URL',
  `referer` varchar(256) NOT NULL DEFAULT '' COMMENT 'Источник трафика',
  `enabled` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'Признак Запись разрешена',
  `deleted` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Признак Запись удалена',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Дата создания записи',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Дата изменения записи',
  `browsed` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Счетчик сопровождений',
  PRIMARY KEY (`search_id`),
  KEY `name` (`name`),
  KEY `escort_url` (`escort_url`),
  KEY `target_url` (`target_url`),
  KEY `referer` (`referer`),
  KEY `enabled` (`enabled`),
  KEY `deleted` (`deleted`),
  KEY `created` (`created`),
  KEY `modified` (`modified`),
  KEY `browsed` (`browsed`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА searches: содержимое
--
-- ----------------------------------------------------------------------------

INSERT INTO `searches` VALUES ('1', 'пл', '', 'test-lemanta/search', 'localhost', '1', '0', '2015-02-04 04:53:14', '0000-00-00 00:00:00', '1');
INSERT INTO `searches` VALUES ('2', 'пла', '', 'test-lemanta/', 'localhost', '1', '0', '2015-02-04 04:54:10', '0000-00-00 00:00:00', '1');
INSERT INTO `searches` VALUES ('3', 'lemanta com', '', 'products/platya/platya-s-baskoj/plate-kris--2915', 'yandex.ru', '1', '0', '2015-02-09 12:17:45', '0000-00-00 00:00:00', '3');
INSERT INTO `searches` VALUES ('4', '- 246', '', '', 'lemanta.com', '1', '0', '2015-02-10 19:52:44', '0000-00-00 00:00:00', '1');
INSERT INTO `searches` VALUES ('5', 'женская одежда', '', 'files/products/20702549.2000x2000w.jpg?6d63d512edf5b7ff84887937afaf02dc', 'go.mail.ru', '1', '0', '2015-02-11 14:55:38', '0000-00-00 00:00:00', '3');

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА sections: структура
--
-- ----------------------------------------------------------------------------

DROP TABLE IF EXISTS `sections`;

CREATE TABLE `sections` (
  `section_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'Идентификатор записи',
  `url` varchar(256) NOT NULL DEFAULT '' COMMENT 'Адрес страницы',
  `parent` int(11) DEFAULT NULL,
  `name` varchar(256) NOT NULL DEFAULT '' COMMENT 'Название',
  `header` varchar(256) NOT NULL DEFAULT '' COMMENT 'Название (заголовок)',
  `meta_title` varchar(256) NOT NULL DEFAULT '' COMMENT 'Мета заголовок',
  `meta_description` varchar(512) NOT NULL DEFAULT '' COMMENT 'Мета описание',
  `meta_keywords` varchar(512) NOT NULL DEFAULT '' COMMENT 'Мета ключевые слова',
  `body` longtext NOT NULL,
  `menu_id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Идентификатор меню',
  `order_num` int(11) NOT NULL DEFAULT '0',
  `module_id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Идентификатор модуля',
  `enabled` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `objects` varchar(512) NOT NULL DEFAULT '',
  `user_id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Идентификатор пользователя',
  `hidden` tinyint(1) NOT NULL DEFAULT '0',
  `url_special` tinyint(1) NOT NULL DEFAULT '0',
  `images` text NOT NULL,
  `images_alts` text NOT NULL,
  `images_texts` longtext NOT NULL,
  `browsed` int(11) NOT NULL DEFAULT '0',
  `images_view` text NOT NULL,
  `seo_description` text NOT NULL,
  `tags` varchar(256) NOT NULL DEFAULT '' COMMENT 'Теги записи',
  `template` varchar(256) NOT NULL DEFAULT '' COMMENT 'Нестандартный шаблон для отображения',
  PRIMARY KEY (`section_id`),
  KEY `order_num` (`order_num`),
  KEY `module_id` (`module_id`),
  KEY `url` (`url`),
  KEY `user_id` (`user_id`),
  KEY `hidden` (`hidden`),
  KEY `browsed` (`browsed`),
  KEY `tags` (`tags`),
  KEY `enabled` (`enabled`),
  KEY `menu_id` (`menu_id`),
  KEY `name` (`name`),
  KEY `header` (`header`),
  KEY `template` (`template`),
  KEY `created` (`created`),
  KEY `modified` (`modified`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА sections: содержимое
--
-- ----------------------------------------------------------------------------

INSERT INTO `sections` VALUES ('1', 'mainpage', NULL, 'Главная', 'Главная страница', 'Интернет магазин одежды', 'Главная страница нашего интернет магазина одежды.', 'главная страница, новинки', '', '2', '9', '4', '1', '2014-11-12 16:29:54', '2015-02-07 22:46:38', '', '0', '0', '0', 'main-slide1_1_1_61480713.jpg|main-slide2_1_2_2908326.jpg|main-slide3_1_3_28118897.jpg|main-slide4_1_4_80758667.jpg', 'Здесь название картинки|Баннер 2|Баннер 3|Баннер 4', 'Эта картинка и ее текст загружена в страницу Главная|Распродажа!!!|Скидки!!!|Любую из картинок слайдера можно отключить', '0', '1|1|1|1', '', 'главная, новинки', '');
INSERT INTO `sections` VALUES ('2', 'dostavka', NULL, 'Доставка', 'Способы доставки', 'Способы доставки', 'Доставка по городам Украины осуществляется транспортно-экспедиторскими компаниями-партнерами на основе 100 предоплаты. Стоимость доставки зависит от веса, объема, стоимости товара, способа доставки и расстояния до Вашего города. Рассчитывается по каждому конкретному заказу.', 'способы, доставка', '<p>Доставка по городам Украины осуществляется транспортно-экспедиторскими компаниями-партнерами на основе <b>100% предоплаты.</b> Стоимость доставки зависит от веса, объема, стоимости товара, способа доставки и расстояния до Вашего города. Рассчитывается по каждому конкретному заказу.<br /><br />Достаточно сделать заказ установленной формы (купить товар) и система Интернет-магазина после обработки, которая занимает 2-3 рабочих дня, вышлет Вам в электронном виде все необходимые условия доставки, включая счета для оплаты.</p><p><b>Доставка до Вашего города считается отдельно транспортно-экспедиторскими компаниями.</b></p>', '2', '3', '1', '1', '2015-02-02 12:15:43', '2015-02-21 21:35:38', '', '0', '0', '1', '', '', '', '29', '', '', '', '');
INSERT INTO `sections` VALUES ('3', 'oplata', NULL, 'Оплата', 'Способы оплаты', 'Способы оплаты', 'Минимальная сумма заказа 1000 гривен. Товар будет отправлен только после 100 оплаты. Оплата товара может быть произведена как наличными, так и по безналичному расчету.', 'способы, оплата', '<p>Минимальная сумма заказа 1000 гривен.</p><p>Товар будет отправлен только после 100% оплаты.</p><p>Оплата товара может быть произведена как наличными (гривны), так и по безналичному расчёту (доставка не включается в стоимость товара).</p>', '2', '2', '1', '1', '2015-02-02 12:18:53', '2015-02-02 12:19:34', '', '0', '0', '1', '', '', '', '26', '', '', '', '');
INSERT INTO `sections` VALUES ('4', 'contact', NULL, 'Контакты', 'Контакты', 'Контакты', '', 'контакты, обратная связь', '<p>г. Одесса&nbsp;</p><p>Промышленный рынок 7 км.</p><p>2 площадка</p><p>&nbsp;</p><p>т. (098) 053-22-33</p><p>E-mail: <a href=\"mailto:office@lemanta.com\" target=\"_blank\">office@lemanta.com</a></p><p>Skype: Lemanta2014</p>', '2', '1', '10', '1', '2015-02-02 12:23:50', '2015-02-21 21:36:15', '', '0', '0', '1', '', '', '', '0', '', '', '', '');
INSERT INTO `sections` VALUES ('6', 'catalog/devochki', NULL, 'Девочки', 'Девочки', 'Девочки', '', '', '', '2', '7', '1', '1', '2015-02-02 13:48:34', '2015-02-02 13:49:23', '', '0', '0', '1', '', '', '', '0', '', '', '', '');
INSERT INTO `sections` VALUES ('5', 'blog', NULL, 'Новости', 'Новости', 'Новости', '', 'новости', '', '2', '5', '3', '1', '2015-02-02 12:29:24', '2015-02-21 21:35:09', '', '0', '0', '1', '', '', '', '35', '', '', '', '');
INSERT INTO `sections` VALUES ('7', 'catalog/boys', NULL, 'Мальчики', 'Мальчики', 'Мальчики', '', '', '', '2', '6', '1', '1', '2015-02-02 13:50:20', '2015-02-02 13:50:20', '', '0', '0', '1', '', '', '', '0', '', '', '', '');
INSERT INTO `sections` VALUES ('8', 'catalog/zhenschiny', NULL, 'Женщины', 'Женщины', 'Женщины', '', '', '', '2', '8', '1', '1', '2015-02-03 19:16:16', '2015-02-03 19:19:02', '', '0', '0', '1', '', '', '', '0', '', '', '', '');

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА settings: структура
--
-- ----------------------------------------------------------------------------

DROP TABLE IF EXISTS `settings`;

CREATE TABLE `settings` (
  `setting_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'Идентификатор записи',
  `name` varchar(256) NOT NULL DEFAULT '' COMMENT 'Название',
  `value` text NOT NULL,
  `description` varchar(512) NOT NULL DEFAULT '',
  `category` varchar(128) NOT NULL DEFAULT '' COMMENT 'Категория настройки',
  PRIMARY KEY (`setting_id`),
  KEY `name` (`name`),
  KEY `category` (`category`),
  KEY `description` (`description`(333))
) ENGINE=MyISAM AUTO_INCREMENT=547 DEFAULT CHARSET=utf8;

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА settings: содержимое
--
-- ----------------------------------------------------------------------------

INSERT INTO `settings` VALUES ('2', 'main_section', 'mainpage', '', '');
INSERT INTO `settings` VALUES ('4', 'footer_text', '&copy; 2014 Интернет-магазин Демо', '', '');
INSERT INTO `settings` VALUES ('5', 'left_text', 'Мы осуществляем бесплатную доставку по Украине для заказов от 250 грн.', '', '');
INSERT INTO `settings` VALUES ('8', 'site_name', 'Lemanta', '', '');
INSERT INTO `settings` VALUES ('9', 'company_name', 'Lemanta', '', '');
INSERT INTO `settings` VALUES ('10', 'admin_email', 'office@lemanta.com', '', '');
INSERT INTO `settings` VALUES ('14', 'counters', '<!-- внесите в это поле js-скрипты используемых вами счетчиков, Яндекс.Метрики, Google-аналитики и т.п. -->\r\n\r\n<img src=\"http://d8.cc.b0.a2.top.mail.ru/counter?js=na;id=2148518;t=216\" alt=\"Рейтинг@Mail.ru\" />', '', '');
INSERT INTO `settings` VALUES ('66', 'technical_works_enabled', '0', '', '');
INSERT INTO `settings` VALUES ('67', 'technical_works_html', '<html>\r\n  <head>\r\n    <meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">\r\n    <meta http-equiv=\"Content-Language\" content=\"ru\">\r\n    <meta http-equiv=\"Expires\" content=\"0\">\r\n    <meta http-equiv=\"Refresh\" content=\"30\">\r\n    <title>Технические работы на сайте</title>\r\n  </head>\r\n  <body>\r\n    <center>\r\n      <br><br><br><br><br>\r\n      <table align=\"center\" border=\"0\" cellpadding=\"20\" cellspacing=\"0\">\r\n        <tr>\r\n          <td nowrap style=\"background-color: #E0E0E0; border: #C0C0C0 1px solid; color: #000000; font-family: Verdana, Tahoma, Arial; font-size: 10pt;\">\r\n            Сейчас на сайте ведутся технические работы.<br>\r\n            Ожидаемое время окончания работ: {$date} {$time}\r\n          </td>\r\n        </tr>\r\n      </table>\r\n    </center>\r\n  </body>\r\n</html>', '', '');
INSERT INTO `settings` VALUES ('22', 'product_thumbnail_width', '150', '', '');
INSERT INTO `settings` VALUES ('23', 'product_thumbnail_height', '200', '', '');
INSERT INTO `settings` VALUES ('24', 'product_image_width', '200', '', '');
INSERT INTO `settings` VALUES ('25', 'product_image_height', '267', '', '');
INSERT INTO `settings` VALUES ('26', 'image_quality', '100', '', '');
INSERT INTO `settings` VALUES ('15', 'phones', '', '', '');
INSERT INTO `settings` VALUES ('27', 'csv_import_delimiter', ';', '', '');
INSERT INTO `settings` VALUES ('28', 'csv_import_columns', 'ctg, brnd, name, prc', '', '');
INSERT INTO `settings` VALUES ('29', 'file_import_charset', 'CP1251', '', '');
INSERT INTO `settings` VALUES ('30', 'theme', 'lemanta', '', '');
INSERT INTO `settings` VALUES ('31', 'product_adimage_width', '500', '', '');
INSERT INTO `settings` VALUES ('32', 'product_adimage_height', '800', '', '');
INSERT INTO `settings` VALUES ('33', 'products_num', '24', 'Товары - отображение - число записей в списке на стороне клиента', '');
INSERT INTO `settings` VALUES ('34', 'products_num_admin', '20', '', '');
INSERT INTO `settings` VALUES ('35', 'notify_from_email', 'office@lemanta.com', '', '');
INSERT INTO `settings` VALUES ('36', 'file_export_charset', 'CP1251', '', '');
INSERT INTO `settings` VALUES ('37', 'csv_export_columns', 'ctg, brnd, name, prc', '', '');
INSERT INTO `settings` VALUES ('38', 'csv_export_delimiter', ';', '', '');
INSERT INTO `settings` VALUES ('3', 'main_mobile_section', '157', '', '');
INSERT INTO `settings` VALUES ('39', 'meta_autofill', '1', '', '');
INSERT INTO `settings` VALUES ('40', 'mainpage_no_hit', '', '', '');
INSERT INTO `settings` VALUES ('41', 'mainpage_hit_random', '', '', '');
INSERT INTO `settings` VALUES ('42', 'mainpage_hit_count', '10', '', '');
INSERT INTO `settings` VALUES ('43', 'mainpage_hit_columns', '2', '', '');
INSERT INTO `settings` VALUES ('44', 'mainpage_no_newest', '', '', '');
INSERT INTO `settings` VALUES ('45', 'mainpage_newest_random', '', '', '');
INSERT INTO `settings` VALUES ('46', 'mainpage_newest_count', '10', '', '');
INSERT INTO `settings` VALUES ('47', 'mainpage_newest_columns', '2', '', '');
INSERT INTO `settings` VALUES ('48', 'mainpage_no_actional', '', '', '');
INSERT INTO `settings` VALUES ('49', 'mainpage_actional_random', '', '', '');
INSERT INTO `settings` VALUES ('50', 'mainpage_actional_count', '10', '', '');
INSERT INTO `settings` VALUES ('51', 'mainpage_actional_columns', '2', '', '');
INSERT INTO `settings` VALUES ('52', 'mainpage_no_awaited', '', '', '');
INSERT INTO `settings` VALUES ('53', 'mainpage_awaited_random', '', '', '');
INSERT INTO `settings` VALUES ('54', 'mainpage_awaited_count', '10', '', '');
INSERT INTO `settings` VALUES ('55', 'mainpage_awaited_columns', '2', '', '');
INSERT INTO `settings` VALUES ('56', 'mainpage_no_ordered', '', '', '');
INSERT INTO `settings` VALUES ('57', 'mainpage_ordered_random', '', '', '');
INSERT INTO `settings` VALUES ('58', 'mainpage_ordered_count', '10', '', '');
INSERT INTO `settings` VALUES ('59', 'mainpage_ordered_columns', '2', '', '');
INSERT INTO `settings` VALUES ('60', 'mainpage_no_commented', '', '', '');
INSERT INTO `settings` VALUES ('61', 'mainpage_commented_random', '', '', '');
INSERT INTO `settings` VALUES ('62', 'mainpage_commented_count', '10', '', '');
INSERT INTO `settings` VALUES ('63', 'mainpage_commented_columns', '2', '', '');
INSERT INTO `settings` VALUES ('64', 'mainpage_no_articles', '', '', '');
INSERT INTO `settings` VALUES ('65', 'mainpage_sortform_enabled', '0', '', '');
INSERT INTO `settings` VALUES ('68', 'technical_works_date', '', '', '');
INSERT INTO `settings` VALUES ('69', 'technical_works_time', '', '', '');
INSERT INTO `settings` VALUES ('70', 'images_watermark_enabled', '0', '', '');
INSERT INTO `settings` VALUES ('71', 'images_watermark_location', '8', '', '');
INSERT INTO `settings` VALUES ('72', 'images_watermark_transparency', '75', '', '');
INSERT INTO `settings` VALUES ('73', 'images_caching_enabled', '0', '', '');
INSERT INTO `settings` VALUES ('74', 'images_caching_for_localhost_enabled', '0', '', '');
INSERT INTO `settings` VALUES ('75', 'images_caching_lifetime', '604800', '', '');
INSERT INTO `settings` VALUES ('76', 'images_caching_filelimit', '5', '', '');
INSERT INTO `settings` VALUES ('77', 'images_caching_timelimit', '5', '', '');
INSERT INTO `settings` VALUES ('78', 'images_caching_ip_resolves', '', '', '');
INSERT INTO `settings` VALUES ('79', 'files_folder_prefix', '', '', '');
INSERT INTO `settings` VALUES ('80', 'images_folder_prefix', '', '', '');
INSERT INTO `settings` VALUES ('81', 'prepath_images_template_used', '', '', '');
INSERT INTO `settings` VALUES ('82', 'livehelp_siteheart_id', '123', '', '');
INSERT INTO `settings` VALUES ('83', 'edit_order_mode', '2', '', '');
INSERT INTO `settings` VALUES ('84', 'sort_form_enabled', '1', '', '');
INSERT INTO `settings` VALUES ('85', 'sort_form_default_method', '1', '', '');
INSERT INTO `settings` VALUES ('86', 'sort_form_default_descending', '0', '', '');
INSERT INTO `settings` VALUES ('87', 'goods_wysiwyg_disabled', '0', '', '');
INSERT INTO `settings` VALUES ('88', 'goods_wysiwyg_disabled_mode', '0', '', '');
INSERT INTO `settings` VALUES ('89', 'categories_wysiwyg_disabled', '', 'Категории - редактирование - запрещен ли визуальный редактор', '');
INSERT INTO `settings` VALUES ('90', 'categories_wysiwyg_disabled_mode', '0', '', '');
INSERT INTO `settings` VALUES ('91', 'brands_wysiwyg_disabled', '', 'Бренды - редактирование - запрещен ли визуальный редактор', '');
INSERT INTO `settings` VALUES ('92', 'brands_wysiwyg_disabled_mode', '0', '', '');
INSERT INTO `settings` VALUES ('93', 'static_wysiwyg_disabled', '0', '', '');
INSERT INTO `settings` VALUES ('94', 'static_wysiwyg_disabled_mode', '0', '', '');
INSERT INTO `settings` VALUES ('95', 'news_wysiwyg_disabled', '', 'Новости - редактирование - запрещен ли визуальный редактор', '');
INSERT INTO `settings` VALUES ('96', 'news_wysiwyg_disabled_mode', '0', '', '');
INSERT INTO `settings` VALUES ('97', 'articles_wysiwyg_disabled', '', 'Статьи - редактирование - запрещен ли визуальный редактор', '');
INSERT INTO `settings` VALUES ('98', 'articles_wysiwyg_disabled_mode', '0', '', '');
INSERT INTO `settings` VALUES ('99', 'deliveries_wysiwyg_disabled', '0', '', '');
INSERT INTO `settings` VALUES ('100', 'deliveries_wysiwyg_disabled_mode', '0', '', '');
INSERT INTO `settings` VALUES ('101', 'delivery_sort_method', '', '', '');
INSERT INTO `settings` VALUES ('102', 'delivery_conflict_method', '0', '', '');
INSERT INTO `settings` VALUES ('103', 'articles_sort_method', '1', '', '');
INSERT INTO `settings` VALUES ('104', 'articles_goods_header', 'Статьи о товаре', '', '');
INSERT INTO `settings` VALUES ('105', 'articles_main_header', 'Статьи', '', '');
INSERT INTO `settings` VALUES ('106', 'articles_main_maxcount', '10', '', '');
INSERT INTO `settings` VALUES ('107', 'quickorder_sort_method', '0', '', '');
INSERT INTO `settings` VALUES ('108', 'quickorder_title_text', 'Быстрый заказ', '', '');
INSERT INTO `settings` VALUES ('109', 'quickorder_info_text', '<div class=\"configurator_text\">\r\nЧтобы сделать быстрый заказ, необходимо заполнить контактно-доставочную информацию по формируемому заказу, в таблице выбрать и указать требуемое количество желаемых товаров, при необходимости щелкая по ссылкам категорий для разворота или сворачивания их подкатегорий, и затем отправить оформленный заказ.\r\n</div>\r\n<div class=\"configurator_text\">\r\nЕсли информация по заказу заполнена правильно, он будет сформирован и вы попадёте на страницу этого заказа. Если же какие-то из необходимых полей окажутся незаполненными, содержимое заказа будет направлено в корзину, страница которой немедленно откроется, чтобы вы могли указать недостающие сведения.\r\n</div>', '', '');
INSERT INTO `settings` VALUES ('110', 'quickorder_show_info', '1', '', '');
INSERT INTO `settings` VALUES ('111', 'quickorder_label_name', 'Фамилия', '', '');
INSERT INTO `settings` VALUES ('112', 'quickorder_show_name', '1', '', '');
INSERT INTO `settings` VALUES ('113', 'quickorder_label_name2', 'Отчество', '', '');
INSERT INTO `settings` VALUES ('114', 'quickorder_show_name2', '', '', '');
INSERT INTO `settings` VALUES ('115', 'quickorder_label_name3', 'Имя', '', '');
INSERT INTO `settings` VALUES ('116', 'quickorder_show_name3', '', '', '');
INSERT INTO `settings` VALUES ('117', 'quickorder_label_email', 'Е-мейл', '', '');
INSERT INTO `settings` VALUES ('118', 'quickorder_show_email', '', '', '');
INSERT INTO `settings` VALUES ('119', 'quickorder_label_email2', 'Ещё (Е-мейл)', '', '');
INSERT INTO `settings` VALUES ('120', 'quickorder_show_email2', '', '', '');
INSERT INTO `settings` VALUES ('121', 'quickorder_label_phone', 'Телефон', '', '');
INSERT INTO `settings` VALUES ('122', 'quickorder_show_phone', '1', '', '');
INSERT INTO `settings` VALUES ('123', 'quickorder_label_phone2', 'Ещё (Телефон)', '', '');
INSERT INTO `settings` VALUES ('124', 'quickorder_show_phone2', '', '', '');
INSERT INTO `settings` VALUES ('125', 'quickorder_label_address', 'Страна', '', '');
INSERT INTO `settings` VALUES ('126', 'quickorder_show_address', '', '', '');
INSERT INTO `settings` VALUES ('127', 'quickorder_label_address_2', 'Область', '', '');
INSERT INTO `settings` VALUES ('128', 'quickorder_show_address_2', '', '', '');
INSERT INTO `settings` VALUES ('129', 'quickorder_label_address_3', 'Город', '', '');
INSERT INTO `settings` VALUES ('130', 'quickorder_show_address_3', '', '', '');
INSERT INTO `settings` VALUES ('131', 'quickorder_label_address_4', 'Улица', '', '');
INSERT INTO `settings` VALUES ('132', 'quickorder_show_address_4', '', '', '');
INSERT INTO `settings` VALUES ('133', 'quickorder_label_address_5', 'Дом', '', '');
INSERT INTO `settings` VALUES ('134', 'quickorder_show_address_5', '', '', '');
INSERT INTO `settings` VALUES ('135', 'quickorder_label_address_6', 'Корпус', '', '');
INSERT INTO `settings` VALUES ('136', 'quickorder_show_address_6', '', '', '');
INSERT INTO `settings` VALUES ('137', 'quickorder_label_address_7', 'Подъезд', '', '');
INSERT INTO `settings` VALUES ('138', 'quickorder_show_address_7', '', '', '');
INSERT INTO `settings` VALUES ('139', 'quickorder_label_address_8', 'Код', '', '');
INSERT INTO `settings` VALUES ('140', 'quickorder_show_address_8', '', '', '');
INSERT INTO `settings` VALUES ('141', 'quickorder_label_address_9', 'Квартира', '', '');
INSERT INTO `settings` VALUES ('142', 'quickorder_show_address_9', '', '', '');
INSERT INTO `settings` VALUES ('143', 'quickorder_label_address_10', 'Индекс', '', '');
INSERT INTO `settings` VALUES ('144', 'quickorder_show_address_10', '', '', '');
INSERT INTO `settings` VALUES ('145', 'quickorder_label_address2', 'Ещё (Страна)', '', '');
INSERT INTO `settings` VALUES ('146', 'quickorder_show_address2', '', '', '');
INSERT INTO `settings` VALUES ('147', 'quickorder_label_address2_2', 'Ещё (Область)', '', '');
INSERT INTO `settings` VALUES ('148', 'quickorder_show_address2_2', '', '', '');
INSERT INTO `settings` VALUES ('149', 'quickorder_label_address2_3', 'Ещё (Город)', '', '');
INSERT INTO `settings` VALUES ('150', 'quickorder_show_address2_3', '', '', '');
INSERT INTO `settings` VALUES ('151', 'quickorder_label_address2_4', 'Ещё (Улица)', '', '');
INSERT INTO `settings` VALUES ('152', 'quickorder_show_address2_4', '', '', '');
INSERT INTO `settings` VALUES ('153', 'quickorder_label_address2_5', 'Дом', '', '');
INSERT INTO `settings` VALUES ('154', 'quickorder_show_address2_5', '', '', '');
INSERT INTO `settings` VALUES ('155', 'quickorder_label_address2_6', 'Корпус', '', '');
INSERT INTO `settings` VALUES ('156', 'quickorder_show_address2_6', '', '', '');
INSERT INTO `settings` VALUES ('157', 'quickorder_label_address2_7', 'Подъезд', '', '');
INSERT INTO `settings` VALUES ('158', 'quickorder_show_address2_7', '', '', '');
INSERT INTO `settings` VALUES ('159', 'quickorder_label_address2_8', 'Код', '', '');
INSERT INTO `settings` VALUES ('160', 'quickorder_show_address2_8', '', '', '');
INSERT INTO `settings` VALUES ('161', 'quickorder_label_address2_9', 'Квартира', '', '');
INSERT INTO `settings` VALUES ('162', 'quickorder_show_address2_9', '', '', '');
INSERT INTO `settings` VALUES ('163', 'quickorder_label_address2_10', 'Ещё (Индекс)', '', '');
INSERT INTO `settings` VALUES ('164', 'quickorder_show_address2_10', '', '', '');
INSERT INTO `settings` VALUES ('165', 'quickorder_label_to_date', 'Желательно', '', '');
INSERT INTO `settings` VALUES ('166', 'quickorder_show_to_date', '', '', '');
INSERT INTO `settings` VALUES ('167', 'quickorder_to_date_editable', '0', '', '');
INSERT INTO `settings` VALUES ('168', 'quickorder_label_to_time', 'время', '', '');
INSERT INTO `settings` VALUES ('169', 'quickorder_show_to_time', '', '', '');
INSERT INTO `settings` VALUES ('170', 'quickorder_to_time_editable', '0', '', '');
INSERT INTO `settings` VALUES ('171', 'quickorder_label_comment', 'Комментарий к заказу', '', '');
INSERT INTO `settings` VALUES ('172', 'quickorder_show_comment', '', '', '');
INSERT INTO `settings` VALUES ('173', 'quickorder_label_delivery', 'Доставка', '', '');
INSERT INTO `settings` VALUES ('174', 'quickorder_show_delivery', '', '', '');
INSERT INTO `settings` VALUES ('175', 'quickorder_header_category', 'Категория', '', '');
INSERT INTO `settings` VALUES ('176', 'quickorder_header_name', 'Наименование', '', '');
INSERT INTO `settings` VALUES ('177', 'quickorder_header_quantity', 'Кол-во', '', '');
INSERT INTO `settings` VALUES ('178', 'quickorder_header_sum', 'Сумма', '', '');
INSERT INTO `settings` VALUES ('179', 'quickorder_submit_text', 'Сделать заказ', '', '');
INSERT INTO `settings` VALUES ('180', 'quickorder_captcha_protecting', '0', '', '');
INSERT INTO `settings` VALUES ('181', 'cart_enable_reservation', '0', '', '');
INSERT INTO `settings` VALUES ('182', 'cart_reservation_text', 'Этот товар оформляется под заказ, срок поставки будет уточнен менеджером при личном контакте.', '', '');
INSERT INTO `settings` VALUES ('183', 'cart_open_method', '1', '', '');
INSERT INTO `settings` VALUES ('184', 'cart_title_text', 'Корзина', '', '');
INSERT INTO `settings` VALUES ('185', 'cart_info_text', '<div class=\"cart_text\">\r\nДля оформления заказа необходимо развернуть ниже секцию с информацией о покупателе, ввести контактную информацию, если её поля пустые, и отправить заказ.\r\n</div>\r\n<div class=\"cart_text\">Другой способ доставки можно выбрать развернув секцию с информацией о вариантах доставки.\r\n</div>\r\n<div class=\"cart_text\">Чтобы удалить товар из корзины, нажмите в приведённом ниже счёте красный крестик справа от лишнего товара.\r\n</div>\r\n<div class=\"cart_text\">Выбрать другое количество заказываемого товара, если на текущий момент он имеется не в единичном экземпляре, можно в выпадающем списке колонки количества напротив нужного товара.\r\n</div>', '', '');
INSERT INTO `settings` VALUES ('186', 'cart_show_info', '1', '', '');
INSERT INTO `settings` VALUES ('187', 'cart_header_number', '№', '', '');
INSERT INTO `settings` VALUES ('188', 'cart_header_name', 'Товар', '', '');
INSERT INTO `settings` VALUES ('189', 'cart_header_quantity', 'Кол-во', '', '');
INSERT INTO `settings` VALUES ('190', 'cart_header_price', 'Цена', '', '');
INSERT INTO `settings` VALUES ('191', 'cart_header_sum', 'Сумма', '', '');
INSERT INTO `settings` VALUES ('192', 'cart_contacts_maximize', '0', '', '');
INSERT INTO `settings` VALUES ('193', 'cart_deliveries_maximize', '0', '', '');
INSERT INTO `settings` VALUES ('194', 'cart_submit_text', 'Сделать заказ', '', '');
INSERT INTO `settings` VALUES ('195', 'cart_captcha_protecting', '0', '', '');
INSERT INTO `settings` VALUES ('196', 'before_import_operation', '0', '', '');
INSERT INTO `settings` VALUES ('197', 'import_marketing_params_updating', '0', '', '');
INSERT INTO `settings` VALUES ('198', 'import_financial_params_updating', '0', '', '');
INSERT INTO `settings` VALUES ('199', 'delete_goods_ancient', '0', '', '');
INSERT INTO `settings` VALUES ('200', 'delete_goods_ancientQ0_lifetime', '30', '', '');
INSERT INTO `settings` VALUES ('201', 'delete_goods_ancientS0_lifetime', '1000000', '', '');
INSERT INTO `settings` VALUES ('202', 'auto_import_disabled', '1', '', '');
INSERT INTO `settings` VALUES ('203', 'auto_import_enabled_for_localhost', '0', '', '');
INSERT INTO `settings` VALUES ('204', 'auto_import_url', '', '', '');
INSERT INTO `settings` VALUES ('205', 'auto_import_lifetime', '3600', '', '');
INSERT INTO `settings` VALUES ('206', 'auto_import_format', 'csv', '', '');
INSERT INTO `settings` VALUES ('207', 'rss_products_count', '9', '', '');
INSERT INTO `settings` VALUES ('208', 'rss_news_count', '3', '', '');
INSERT INTO `settings` VALUES ('209', 'rss_articles_count', '3', '', '');
INSERT INTO `settings` VALUES ('210', 'rss_modified_analize', '0', '', '');
INSERT INTO `settings` VALUES ('211', 'rss_title_text', 'Новинки магазина одежды Lemanta', '', '');
INSERT INTO `settings` VALUES ('212', 'rss_description_text', 'Магазин одежды Lemanta', '', '');
INSERT INTO `settings` VALUES ('213', 'rss_copyright_text', 'Copyright 2014 Магазин одежды Lemanta', '', '');
INSERT INTO `settings` VALUES ('214', 'rss_without_announce', '0', '', '');
INSERT INTO `settings` VALUES ('215', 'rss_enabled_tags', 'b, em, i, u, strong, span, br, p, div, ol, ul, li', '', '');
INSERT INTO `settings` VALUES ('216', 'vkontakte_publish_enabled', '1', '', '');
INSERT INTO `settings` VALUES ('217', 'vkontakte_publish_selected_only', '0', '', '');
INSERT INTO `settings` VALUES ('218', 'vkontakte_publish_javascript', '1', '', '');
INSERT INTO `settings` VALUES ('219', 'vkontakte_publish_label', 'Разместить у себя<br>ВКонтакте', '', '');
INSERT INTO `settings` VALUES ('220', 'vkontakte_wishlist_enabled', '0', '', '');
INSERT INTO `settings` VALUES ('221', 'vkontakte_wishlist_selected_only', '0', '', '');
INSERT INTO `settings` VALUES ('222', 'vkontakte_wishlist_testmode', '1', '', '');
INSERT INTO `settings` VALUES ('223', 'vkontakte_wishlist_delivery_cost', '', '', '');
INSERT INTO `settings` VALUES ('224', 'vkontakte_wishlist_cost_increase', '0', '', '');
INSERT INTO `settings` VALUES ('225', 'vkontakte_wishlist_label', 'Хочу', '', '');
INSERT INTO `settings` VALUES ('226', 'vkontakte_wishlist_label_right', 'Подарок', '', '');
INSERT INTO `settings` VALUES ('227', 'vkontakte_wishlist_merchantid', '123', '', '');
INSERT INTO `settings` VALUES ('228', 'vkontakte_wishlist_secret', '12345', '', '');
INSERT INTO `settings` VALUES ('229', 'vkontakte_payment_enabled', '0', '', '');
INSERT INTO `settings` VALUES ('230', 'vkontakte_payment_testmode', '1', '', '');
INSERT INTO `settings` VALUES ('231', 'vkontakte_payment_cost_increase', '0', '', '');
INSERT INTO `settings` VALUES ('232', 'vkontakte_payment_result_url', '', '', '');
INSERT INTO `settings` VALUES ('233', 'vkontakte_payment_fail_url', '', '', '');
INSERT INTO `settings` VALUES ('234', 'vkontakte_payment_label', 'Оплатить', '', '');
INSERT INTO `settings` VALUES ('235', 'vkontakte_payment_label_right', 'Контакте', '', '');
INSERT INTO `settings` VALUES ('236', 'vkontakte_payment_merchantid', '123', '', '');
INSERT INTO `settings` VALUES ('237', 'vkontakte_payment_secret', '12345', '', '');
INSERT INTO `settings` VALUES ('238', 'affiliates_enabled', '0', '', '');
INSERT INTO `settings` VALUES ('239', 'affiliates_referal_cost', '0.0001', '', '');
INSERT INTO `settings` VALUES ('240', 'affiliates_referal_lifetime', '31536000', '', '');
INSERT INTO `settings` VALUES ('241', 'affiliates_referal_urlchecking', '1', '', '');
INSERT INTO `settings` VALUES ('242', 'affiliates_registration_cost', '0.0000', '', '');
INSERT INTO `settings` VALUES ('243', 'affiliates_commission_percent', '9.95', '', '');
INSERT INTO `settings` VALUES ('244', 'affiliates_commission_percent_gift', '0.05', '', '');
INSERT INTO `settings` VALUES ('245', 'affiliates_commission_full', '0', '', '');
INSERT INTO `settings` VALUES ('246', 'affiliates_commission_limit', '', '', '');
INSERT INTO `settings` VALUES ('247', 'product_adimage_effect', 'enlarge', '', '');
INSERT INTO `settings` VALUES ('248', 'catalog_menu_mode', '1', '', '');
INSERT INTO `settings` VALUES ('249', 'catalog_menu_noempty', '1', '', '');
INSERT INTO `settings` VALUES ('250', 'catalog_menu_nocount', '', '', '');
INSERT INTO `settings` VALUES ('251', 'catalog_menu_adminedit', '', '', '');
INSERT INTO `settings` VALUES ('252', 'productpage_block_columns', '2', '', '');
INSERT INTO `settings` VALUES ('253', 'productpage_no_mores', '', '', '');
INSERT INTO `settings` VALUES ('254', 'productpage_mores_excludeme', '1', '', '');
INSERT INTO `settings` VALUES ('255', 'productpage_mores_spacefill', '', '', '');
INSERT INTO `settings` VALUES ('256', 'productpage_mores_count', '6', '', '');
INSERT INTO `settings` VALUES ('257', 'productpage_mores_caption', 'Похожие продукты', '', '');
INSERT INTO `settings` VALUES ('258', 'productpage_no_hits', '', '', '');
INSERT INTO `settings` VALUES ('259', 'productpage_hits_excludeme', '', '', '');
INSERT INTO `settings` VALUES ('260', 'productpage_hits_spacefill', '', '', '');
INSERT INTO `settings` VALUES ('261', 'productpage_hits_count', '4', '', '');
INSERT INTO `settings` VALUES ('262', 'productpage_hits_caption', 'Хиты продаж', '', '');
INSERT INTO `settings` VALUES ('263', 'productpage_no_newests', '', '', '');
INSERT INTO `settings` VALUES ('264', 'productpage_newests_excludeme', '', '', '');
INSERT INTO `settings` VALUES ('265', 'productpage_newests_spacefill', '', '', '');
INSERT INTO `settings` VALUES ('266', 'productpage_newests_count', '4', '', '');
INSERT INTO `settings` VALUES ('267', 'productpage_newests_caption', 'Новые поступления', '', '');
INSERT INTO `settings` VALUES ('268', 'productpage_no_actionals', '', '', '');
INSERT INTO `settings` VALUES ('269', 'productpage_actionals_excludeme', '', '', '');
INSERT INTO `settings` VALUES ('270', 'productpage_actionals_spacefill', '', '', '');
INSERT INTO `settings` VALUES ('271', 'productpage_actionals_count', '4', '', '');
INSERT INTO `settings` VALUES ('272', 'productpage_actionals_caption', 'Специальное предложение', '', '');
INSERT INTO `settings` VALUES ('273', 'productpage_no_awaiteds', '', '', '');
INSERT INTO `settings` VALUES ('274', 'productpage_awaiteds_excludeme', '', '', '');
INSERT INTO `settings` VALUES ('275', 'productpage_awaiteds_spacefill', '', '', '');
INSERT INTO `settings` VALUES ('276', 'productpage_awaiteds_count', '4', '', '');
INSERT INTO `settings` VALUES ('277', 'productpage_awaiteds_caption', 'Скоро в продаже', '', '');
INSERT INTO `settings` VALUES ('278', 'productpage_no_ordereds', '', '', '');
INSERT INTO `settings` VALUES ('279', 'productpage_ordereds_excludeme', '', '', '');
INSERT INTO `settings` VALUES ('280', 'productpage_ordereds_spacefill', '', '', '');
INSERT INTO `settings` VALUES ('281', 'productpage_ordereds_count', '4', '', '');
INSERT INTO `settings` VALUES ('282', 'productpage_ordereds_caption', 'Что покупают другие', '', '');
INSERT INTO `settings` VALUES ('283', 'productpage_no_commenteds', '', '', '');
INSERT INTO `settings` VALUES ('284', 'productpage_commenteds_excludeme', '', '', '');
INSERT INTO `settings` VALUES ('285', 'productpage_commenteds_spacefill', '', '', '');
INSERT INTO `settings` VALUES ('286', 'productpage_commenteds_count', '4', '', '');
INSERT INTO `settings` VALUES ('287', 'productpage_commenteds_caption', 'О чём отзываются', '', '');
INSERT INTO `settings` VALUES ('288', 'product_category_show', '1', '', '');
INSERT INTO `settings` VALUES ('289', 'product_brand_show', '1', '', '');
INSERT INTO `settings` VALUES ('290', 'comment_next_time', '30', '', '');
INSERT INTO `settings` VALUES ('291', 'sections_files_folder_prefix', '', 'Специальные страницы - изображения - префикс папки с файлами изображений', '');
INSERT INTO `settings` VALUES ('292', 'sections_images_quality', '90', 'Специальные страницы - изображения - качество', '');
INSERT INTO `settings` VALUES ('293', 'sections_images_width', '4096', 'Специальные страницы - изображения - предельная ширина', '');
INSERT INTO `settings` VALUES ('294', 'sections_images_height', '3072', 'Специальные страницы - изображения - предельная высота', '');
INSERT INTO `settings` VALUES ('295', 'sections_thumbnail_width', '320', 'Специальные страницы - миниатюры - предельная ширина', '');
INSERT INTO `settings` VALUES ('296', 'sections_thumbnail_height', '240', 'Специальные страницы - миниатюры - предельная высота', '');
INSERT INTO `settings` VALUES ('297', 'sections_watermark_transparency', '50', 'Специальные страницы - водяной знак - процент видимости на картинке', '');
INSERT INTO `settings` VALUES ('298', 'sections_images_exactly', '', 'Специальные страницы - изображения - подгонять ли размеры картинок, меньших предельных размеров', '');
INSERT INTO `settings` VALUES ('299', 'sections_watermark_enabled', '', 'Специальные страницы - водяной знак - разрешено ли накладывать на картинку', '');
INSERT INTO `settings` VALUES ('300', 'sections_watermark_location', '8', 'Специальные страницы - водяной знак - расположение', '');
INSERT INTO `settings` VALUES ('301', 'sections_wysiwyg_disabled', '', 'Специальные страницы - редактирование - запрещен ли визуальный редактор', '');
INSERT INTO `settings` VALUES ('302', 'sections_wysiwyg_disabled_mode', '0', 'Специальные страницы - редактирование - режим обработки текста при отключенном визуальном редакторе', '');
INSERT INTO `settings` VALUES ('303', 'sections_meta_autofill', '1', 'Специальные страницы - редактирование - заполнять ли пустые поля мета информации автоматически', '');
INSERT INTO `settings` VALUES ('304', 'sections_sort_method', '1', 'Специальные страницы - отображение - способ сортировки на стороне клиента', '');
INSERT INTO `settings` VALUES ('305', 'sms_TurboSmsUA_sender', '', 'SMS шлюзы - TurboSMS.ua - альфа имя (название отправителя)', '');
INSERT INTO `settings` VALUES ('306', 'sms_TurboSmsUA_protocol', 'http', 'SMS шлюзы - TurboSMS.ua - протокол сервера', '');
INSERT INTO `settings` VALUES ('307', 'sms_TurboSmsUA_server', 'turbosms.in.ua/api/wsdl.html', 'SMS шлюзы - TurboSMS.ua - адрес сервера', '');
INSERT INTO `settings` VALUES ('308', 'sms_TurboSmsUA_port', '', 'SMS шлюзы - TurboSMS.ua - порт сервера', '');
INSERT INTO `settings` VALUES ('309', 'sms_TurboSmsUA_login', '', 'SMS шлюзы - TurboSMS.ua - логин доступа', '');
INSERT INTO `settings` VALUES ('310', 'sms_TurboSmsUA_password', '', 'SMS шлюзы - TurboSMS.ua - пароль доступа', '');
INSERT INTO `settings` VALUES ('311', 'sms_TurboSmsUA_admin_phone', '', 'SMS шлюзы - TurboSMS.ua - уведомительный телефон администратора', '');
INSERT INTO `settings` VALUES ('312', 'sms_TurboSmsUA_filter', '', 'SMS шлюзы - TurboSMS.ua - фильтр телефонных номеров', '');
INSERT INTO `settings` VALUES ('313', 'sms_TurboSmsUA_charset', 'UTF-8', 'SMS шлюзы - TurboSMS.ua - символьная кодировка шлюза', '');
INSERT INTO `settings` VALUES ('314', 'sms_TurboSmsUA_number', '3', 'SMS шлюзы - TurboSMS.ua - порядковый номер шлюза', '');
INSERT INTO `settings` VALUES ('315', 'sms_TurboSmsUA_enabled', '0', 'SMS шлюзы - TurboSMS.ua - разрешено ли использовать шлюз', '');
INSERT INTO `settings` VALUES ('316', 'sms_TurboSmsUA_explained', '1', 'SMS шлюзы - TurboSMS.ua - разрешено ли помещать разъяснения ошибок в историю шлюза', '');
INSERT INTO `settings` VALUES ('317', 'sms_AlphaSmsComUA_sender', '', 'SMS шлюзы - AlphaSMS.com.ua - альфа имя (название отправителя)', '');
INSERT INTO `settings` VALUES ('318', 'sms_AlphaSmsComUA_protocol', 'https', 'SMS шлюзы - AlphaSMS.com.ua - протокол сервера', '');
INSERT INTO `settings` VALUES ('319', 'sms_AlphaSmsComUA_server', 'alphasms.com.ua/api/http.php', 'SMS шлюзы - AlphaSMS.com.ua - адрес сервера', '');
INSERT INTO `settings` VALUES ('320', 'sms_AlphaSmsComUA_port', '', 'SMS шлюзы - AlphaSMS.com.ua - порт сервера', '');
INSERT INTO `settings` VALUES ('321', 'sms_AlphaSmsComUA_login', '', 'SMS шлюзы - AlphaSMS.com.ua - логин доступа', '');
INSERT INTO `settings` VALUES ('322', 'sms_AlphaSmsComUA_password', '', 'SMS шлюзы - AlphaSMS.com.ua - пароль доступа', '');
INSERT INTO `settings` VALUES ('323', 'sms_AlphaSmsComUA_admin_phone', '', 'SMS шлюзы - AlphaSMS.com.ua - уведомительный телефон администратора', '');
INSERT INTO `settings` VALUES ('324', 'sms_AlphaSmsComUA_filter', '', 'SMS шлюзы - AlphaSMS.com.ua - фильтр телефонных номеров', '');
INSERT INTO `settings` VALUES ('325', 'sms_AlphaSmsComUA_charset', 'UTF-8', 'SMS шлюзы - AlphaSMS.com.ua - символьная кодировка шлюза', '');
INSERT INTO `settings` VALUES ('326', 'sms_AlphaSmsComUA_number', '4', 'SMS шлюзы - AlphaSMS.com.ua - порядковый номер шлюза', '');
INSERT INTO `settings` VALUES ('327', 'sms_AlphaSmsComUA_enabled', '0', 'SMS шлюзы - AlphaSMS.com.ua - разрешено ли использовать шлюз', '');
INSERT INTO `settings` VALUES ('328', 'sms_AlphaSmsComUA_explained', '1', 'SMS шлюзы - AlphaSMS.com.ua - разрешено ли помещать разъяснения ошибок в историю шлюза', '');
INSERT INTO `settings` VALUES ('329', 'sms_BusinessLifeComUA_sender', '', 'SMS шлюзы - BusinessLife.com.ua - альфа имя (название отправителя)', '');
INSERT INTO `settings` VALUES ('330', 'sms_BusinessLifeComUA_protocol', 'http', 'SMS шлюзы - BusinessLife.com.ua - протокол сервера', '');
INSERT INTO `settings` VALUES ('331', 'sms_BusinessLifeComUA_server', '212.58.160.139', 'SMS шлюзы - BusinessLife.com.ua - адрес сервера', '');
INSERT INTO `settings` VALUES ('332', 'sms_BusinessLifeComUA_port', '16001', 'SMS шлюзы - BusinessLife.com.ua - порт сервера', '');
INSERT INTO `settings` VALUES ('333', 'sms_BusinessLifeComUA_login', '', 'SMS шлюзы - BusinessLife.com.ua - логин доступа', '');
INSERT INTO `settings` VALUES ('334', 'sms_BusinessLifeComUA_password', '', 'SMS шлюзы - BusinessLife.com.ua - пароль доступа', '');
INSERT INTO `settings` VALUES ('335', 'sms_BusinessLifeComUA_admin_phone', '', 'SMS шлюзы - BusinessLife.com.ua - уведомительный телефон администратора', '');
INSERT INTO `settings` VALUES ('336', 'sms_BusinessLifeComUA_filter', '', 'SMS шлюзы - BusinessLife.com.ua - фильтр телефонных номеров', '');
INSERT INTO `settings` VALUES ('337', 'sms_BusinessLifeComUA_charset', 'UTF-16BE', 'SMS шлюзы - BusinessLife.com.ua - символьная кодировка шлюза', '');
INSERT INTO `settings` VALUES ('338', 'sms_BusinessLifeComUA_number', '5', 'SMS шлюзы - BusinessLife.com.ua - порядковый номер шлюза', '');
INSERT INTO `settings` VALUES ('339', 'sms_BusinessLifeComUA_enabled', '0', 'SMS шлюзы - BusinessLife.com.ua - разрешено ли использовать шлюз', '');
INSERT INTO `settings` VALUES ('340', 'sms_BusinessLifeComUA_explained', '1', 'SMS шлюзы - BusinessLife.com.ua - разрешено ли помещать разъяснения ошибок в историю шлюза', '');
INSERT INTO `settings` VALUES ('341', 'sms_ePochtaSMS_sender', '', 'SMS шлюзы - ePochtaSMS - альфа имя (название отправителя)', '');
INSERT INTO `settings` VALUES ('342', 'sms_ePochtaSMS_protocol', 'http', 'SMS шлюзы - ePochtaSMS - протокол сервера', '');
INSERT INTO `settings` VALUES ('343', 'sms_ePochtaSMS_server', 'atompark.com/members/sms/xml', 'SMS шлюзы - ePochtaSMS - адрес сервера', '');
INSERT INTO `settings` VALUES ('344', 'sms_ePochtaSMS_port', '', 'SMS шлюзы - ePochtaSMS - порт сервера', '');
INSERT INTO `settings` VALUES ('345', 'sms_ePochtaSMS_login', '', 'SMS шлюзы - ePochtaSMS - логин доступа', '');
INSERT INTO `settings` VALUES ('346', 'sms_ePochtaSMS_password', '', 'SMS шлюзы - ePochtaSMS - пароль доступа', '');
INSERT INTO `settings` VALUES ('347', 'sms_ePochtaSMS_admin_phone', '', 'SMS шлюзы - ePochtaSMS - уведомительный телефон администратора', '');
INSERT INTO `settings` VALUES ('348', 'sms_ePochtaSMS_filter', '', 'SMS шлюзы - ePochtaSMS - фильтр телефонных номеров', '');
INSERT INTO `settings` VALUES ('349', 'sms_ePochtaSMS_charset', 'UTF-8', 'SMS шлюзы - ePochtaSMS - символьная кодировка шлюза', '');
INSERT INTO `settings` VALUES ('350', 'sms_ePochtaSMS_number', '2', 'SMS шлюзы - ePochtaSMS - порядковый номер шлюза', '');
INSERT INTO `settings` VALUES ('351', 'sms_ePochtaSMS_enabled', '0', 'SMS шлюзы - ePochtaSMS - разрешено ли использовать шлюз', '');
INSERT INTO `settings` VALUES ('352', 'sms_ePochtaSMS_explained', '1', 'SMS шлюзы - ePochtaSMS - разрешено ли помещать разъяснения ошибок в историю шлюза', '');
INSERT INTO `settings` VALUES ('353', 'sms_RFSmsRU_sender', '', 'SMS шлюзы - RFSMS.ru - альфа имя (название отправителя)', '');
INSERT INTO `settings` VALUES ('354', 'sms_RFSmsRU_protocol', 'https', 'SMS шлюзы - RFSMS.ru - протокол сервера', '');
INSERT INTO `settings` VALUES ('355', 'sms_RFSmsRU_server', 'transport.rfsms.ru', 'SMS шлюзы - RFSMS.ru - адрес сервера', '');
INSERT INTO `settings` VALUES ('356', 'sms_RFSmsRU_port', '7214', 'SMS шлюзы - RFSMS.ru - порт сервера', '');
INSERT INTO `settings` VALUES ('357', 'sms_RFSmsRU_login', '', 'SMS шлюзы - RFSMS.ru - логин доступа', '');
INSERT INTO `settings` VALUES ('358', 'sms_RFSmsRU_password', '', 'SMS шлюзы - RFSMS.ru - пароль доступа', '');
INSERT INTO `settings` VALUES ('359', 'sms_RFSmsRU_admin_phone', '', 'SMS шлюзы - RFSMS.ru - уведомительный телефон администратора', '');
INSERT INTO `settings` VALUES ('360', 'sms_RFSmsRU_filter', '', 'SMS шлюзы - RFSMS.ru - фильтр телефонных номеров', '');
INSERT INTO `settings` VALUES ('361', 'sms_RFSmsRU_charset', 'UTF-8', 'SMS шлюзы - RFSMS.ru - символьная кодировка шлюза', '');
INSERT INTO `settings` VALUES ('362', 'sms_RFSmsRU_number', '1', 'SMS шлюзы - RFSMS.ru - порядковый номер шлюза', '');
INSERT INTO `settings` VALUES ('363', 'sms_RFSmsRU_enabled', '0', 'SMS шлюзы - RFSMS.ru - разрешено ли использовать шлюз', '');
INSERT INTO `settings` VALUES ('364', 'sms_RFSmsRU_explained', '1', 'SMS шлюзы - RFSMS.ru - разрешено ли помещать разъяснения ошибок в историю шлюза', '');
INSERT INTO `settings` VALUES ('365', 'cart_auto_registration', '0', '', '');
INSERT INTO `settings` VALUES ('366', 'cart_auto_registration_msg', 'Обратите внимание! Наш магазин предоставляет скидки постоянным клиентам. Если при оформлении заказа Вы заполните свой емейл, и ещё не имеете регистрации в нашем магазине, автоматически зарегистрируем Вас как постоянного клиента и вышлем пароль на указанный емейл.', '', '');
INSERT INTO `settings` VALUES ('367', 'products_images_resizing', '1', 'Обрабатывать ли изображения после загрузки', 'Товары');
INSERT INTO `settings` VALUES ('368', 'products_thumbnail_resizing', '1', 'Обрабатывать ли миниатюры после загрузки', 'Товары');
INSERT INTO `settings` VALUES ('369', 'products_sort_descending', '0', 'Противоположное направление сортировки записей в списке на клиентской стороне', 'Товары');
INSERT INTO `settings` VALUES ('370', 'products_main_title', 'Товары', 'Дефолтный заголовок страницы', 'Товары');
INSERT INTO `settings` VALUES ('371', 'products_main_path', 'Товары', 'Название страницы в хлебных крошках', 'Товары');
INSERT INTO `settings` VALUES ('372', 'products_main_keywords', 'товары', 'Дефолтный список ключевых слов страницы', 'Товары');
INSERT INTO `settings` VALUES ('373', 'products_main_description', 'Список товаров, предлагаемых нашим магазином.', 'Дефолтное мета описание страницы', 'Товары');
INSERT INTO `settings` VALUES ('374', 'products_show_all_disabled', '0', 'Запрещен ли просмотр всех записей на одной странице клиентской стороны', 'Товары');
INSERT INTO `settings` VALUES ('375', 'users_captcha_disabled', '0', 'Отключена ли капча', 'Авторизация');
INSERT INTO `settings` VALUES ('376', 'users_next_lifetime', '10', 'Антиспам пауза в секундах между постами', 'Авторизация');
INSERT INTO `settings` VALUES ('377', 'users_email_disabled', '0', 'Отключен ли емейл админу об успешном принятии формы', 'Авторизация');
INSERT INTO `settings` VALUES ('378', 'users_sms_disabled', '1', 'Отключена ли SMS админу об успешном принятии формы', 'Авторизация');
INSERT INTO `settings` VALUES ('379', 'users_email_user_disabled', '1', 'Отключен ли емейл клиенту об успешном принятии формы', 'Авторизация');
INSERT INTO `settings` VALUES ('380', 'users_sms_user_disabled', '1', 'Отключена ли SMS клиенту об успешном принятии формы', 'Авторизация');
INSERT INTO `settings` VALUES ('381', 'feedback_captcha_disabled', '0', 'Отключена ли капча', 'Обратная связь');
INSERT INTO `settings` VALUES ('382', 'feedback_next_lifetime', '180', 'Антиспам пауза в секундах между постами', 'Обратная связь');
INSERT INTO `settings` VALUES ('383', 'feedback_email_disabled', '0', 'Отключен ли емейл админу об успешном принятии формы', 'Обратная связь');
INSERT INTO `settings` VALUES ('384', 'feedback_sms_disabled', '1', 'Отключена ли SMS админу об успешном принятии формы', 'Обратная связь');
INSERT INTO `settings` VALUES ('385', 'feedback_email_user_disabled', '1', 'Отключен ли емейл клиенту об успешном принятии формы', 'Обратная связь');
INSERT INTO `settings` VALUES ('386', 'feedback_sms_user_disabled', '1', 'Отключена ли SMS клиенту об успешном принятии формы', 'Обратная связь');
INSERT INTO `settings` VALUES ('387', 'news_images_resizing', '1', 'Обрабатывать ли изображения после загрузки', 'Новости');
INSERT INTO `settings` VALUES ('388', 'news_thumbnail_resizing', '1', 'Обрабатывать ли миниатюры после загрузки', 'Новости');
INSERT INTO `settings` VALUES ('389', 'news_sort_descending', '1', 'Противоположное направление сортировки записей в списке на клиентской стороне', 'Новости');
INSERT INTO `settings` VALUES ('390', 'news_sort_laconical', '0', 'Лаконичность сортировки записей (отсечение не имеющих смысла)', 'Новости');
INSERT INTO `settings` VALUES ('391', 'news_main_keywords', 'новости, новость', 'Дефолтный список ключевых слов страницы', 'Новости');
INSERT INTO `settings` VALUES ('392', 'news_main_description', 'Список новостей нашего магазина.', 'Дефолтное мета описание страницы', 'Новости');
INSERT INTO `settings` VALUES ('393', 'news_num', '24', 'Число записей в списке на странице клиентской стороны', 'Новости');
INSERT INTO `settings` VALUES ('394', 'news_num_admin', '50', 'Число записей в списке на странице админпанели', 'Новости');
INSERT INTO `settings` VALUES ('395', 'news_show_all_disabled', '0', 'Запрещен ли просмотр всех записей на одной странице клиентской стороны', 'Новости');
INSERT INTO `settings` VALUES ('396', 'products_files_folder_prefix', '', 'Товары - изображения - префикс папки с файлами изображений', '');
INSERT INTO `settings` VALUES ('397', 'products_images_quality', '90', 'Товары - изображения - качество', '');
INSERT INTO `settings` VALUES ('398', 'products_images_width', '4096', 'Товары - изображения - предельная ширина', '');
INSERT INTO `settings` VALUES ('399', 'products_images_height', '3072', 'Товары - изображения - предельная высота', '');
INSERT INTO `settings` VALUES ('400', 'products_thumbnail_width', '320', 'Товары - миниатюры - предельная ширина', '');
INSERT INTO `settings` VALUES ('401', 'products_thumbnail_height', '240', 'Товары - миниатюры - предельная высота', '');
INSERT INTO `settings` VALUES ('402', 'products_watermark_transparency', '50', 'Товары - водяной знак - процент видимости на картинке', '');
INSERT INTO `settings` VALUES ('403', 'products_images_exactly', '', 'Товары - изображения - подгонять ли размеры картинок, меньших предельных размеров', '');
INSERT INTO `settings` VALUES ('404', 'products_watermark_enabled', '', 'Товары - водяной знак - разрешено ли накладывать на картинку', '');
INSERT INTO `settings` VALUES ('405', 'products_watermark_location', '8', 'Товары - водяной знак - расположение', '');
INSERT INTO `settings` VALUES ('406', 'products_wysiwyg_disabled', '', 'Товары - редактирование - запрещен ли визуальный редактор', '');
INSERT INTO `settings` VALUES ('407', 'products_wysiwyg_disabled_mode', '0', 'Товары - редактирование - режим обработки текста при отключенном визуальном редакторе', '');
INSERT INTO `settings` VALUES ('408', 'products_meta_autofill', '1', 'Товары - редактирование - заполнять ли пустые поля мета информации автоматически', '');
INSERT INTO `settings` VALUES ('409', 'products_sort_method', '0', 'Товары - отображение - способ сортировки на стороне клиента', '');
INSERT INTO `settings` VALUES ('410', 'products_sort_direction', '', 'Товары - отображение - направление сортировки на стороне клиента', '');
INSERT INTO `settings` VALUES ('411', 'products_sort_laconical', '', 'Товары - отображение - лаконичность сортировки на стороне клиента', '');
INSERT INTO `settings` VALUES ('412', 'products_hit_title', 'Хиты продаж', 'Товары - отображение - оглавление списка \"Хиты продаж\" на стороне клиента', '');
INSERT INTO `settings` VALUES ('413', 'products_hit_path', 'Популярные', 'Товары - отображение - путевое название списка \"Хиты продаж\" в навигаторе на стороне клиента', '');
INSERT INTO `settings` VALUES ('414', 'products_hit_keywords', 'хит продаж, популярный товар', 'Товары - отображение - ключевые слова списка \"Хиты продаж\"', '');
INSERT INTO `settings` VALUES ('415', 'products_hit_description', 'Список хитов продаж интернет-магазина.', 'Товары - отображение - мета описание списка \"Хиты продаж\"', '');
INSERT INTO `settings` VALUES ('416', 'products_hit_maxcount', '8', 'Товары - отображение - длина списка \"Хиты продаж\", когда выводится в виде блока', '');
INSERT INTO `settings` VALUES ('417', 'products_main_hit_enabled', '1', 'Товары - отображение - виден ли список \"Хиты продаж\" на главной странице', '');
INSERT INTO `settings` VALUES ('418', 'products_hit_enabled', '1', 'Товары - отображение - виден ли список \"Хиты продаж\" на странице товара', '');
INSERT INTO `settings` VALUES ('419', 'products_hit_random', '1', 'Товары - отображение - перемешать ли случайно список \"Хиты продаж\", когда выводится в виде блока', '');
INSERT INTO `settings` VALUES ('420', 'products_newest_title', 'Новые поступления', 'Товары - отображение - оглавление списка \"Новые поступления\" на стороне клиента', '');
INSERT INTO `settings` VALUES ('421', 'products_newest_path', 'Новые', 'Товары - отображение - путевое название списка \"Новые поступления\" в навигаторе на стороне клиента', '');
INSERT INTO `settings` VALUES ('422', 'products_newest_keywords', 'новый товар, новинки, новые поступления', 'Товары - отображение - ключевые слова списка \"Новые поступления\"', '');
INSERT INTO `settings` VALUES ('423', 'products_newest_description', 'Список новинок интернет-магазина.', 'Товары - отображение - мета описание списка \"Новые поступления\"', '');
INSERT INTO `settings` VALUES ('424', 'products_newest_maxcount', '6', 'Товары - отображение - длина списка \"Новые поступления\", когда выводится в виде блока', '');
INSERT INTO `settings` VALUES ('425', 'products_main_newest_enabled', '1', 'Товары - отображение - виден ли список \"Новые поступления\" на главной странице', '');
INSERT INTO `settings` VALUES ('426', 'products_newest_enabled', '1', 'Товары - отображение - виден ли список \"Новые поступления\" на странице товара', '');
INSERT INTO `settings` VALUES ('427', 'products_newest_random', '1', 'Товары - отображение - перемешать ли случайно список \"Новые поступления\", когда выводится в виде блока', '');
INSERT INTO `settings` VALUES ('428', 'products_newest_days', '0', 'Товары - отображение - число последних дней, добавленные товары которых подмешивать в список новинок', '');
INSERT INTO `settings` VALUES ('429', 'products_actional_title', 'Специальное предложение', 'Товары - отображение - оглавление списка \"Акционные\" на стороне клиента', '');
INSERT INTO `settings` VALUES ('430', 'products_actional_path', 'Акционные', 'Товары - отображение - путевое название списка \"Акционные\" в навигаторе на стороне клиента', '');
INSERT INTO `settings` VALUES ('431', 'products_actional_keywords', 'акция', 'Товары - отображение - ключевые слова списка \"Акционные\"', '');
INSERT INTO `settings` VALUES ('432', 'products_actional_description', 'Список акционных товаров интернет-магазина.', 'Товары - отображение - мета описание списка \"Акционные\"', '');
INSERT INTO `settings` VALUES ('433', 'products_actional_maxcount', '4', 'Товары - отображение - длина списка \"Акционные\", когда выводится в виде блока', '');
INSERT INTO `settings` VALUES ('434', 'products_main_actional_enabled', '1', 'Товары - отображение - виден ли список \"Акционные\" на главной странице', '');
INSERT INTO `settings` VALUES ('435', 'products_actional_enabled', '1', 'Товары - отображение - виден ли список \"Акционные\" на странице товара', '');
INSERT INTO `settings` VALUES ('436', 'products_actional_random', '1', 'Товары - отображение - перемешать ли случайно список \"Акционные\", когда выводится в виде блока', '');
INSERT INTO `settings` VALUES ('437', 'products_awaited_title', 'Скоро в продаже', 'Товары - отображение - оглавление списка \"Скоро в продаже\" на стороне клиента', '');
INSERT INTO `settings` VALUES ('438', 'products_awaited_path', 'Ожидаемые', 'Товары - отображение - путевое название списка \"Скоро в продаже\" в навигаторе на стороне клиента', '');
INSERT INTO `settings` VALUES ('439', 'products_awaited_keywords', 'скоро в продаже', 'Товары - отображение - ключевые слова списка \"Скоро в продаже\"', '');
INSERT INTO `settings` VALUES ('440', 'products_awaited_description', 'Список ожидаемых товаров в интернет-магазине.', 'Товары - отображение - мета описание списка \"Скоро в продаже\"', '');
INSERT INTO `settings` VALUES ('441', 'products_awaited_maxcount', '2', 'Товары - отображение - длина списка \"Скоро в продаже\", когда выводится в виде блока', '');
INSERT INTO `settings` VALUES ('442', 'products_main_awaited_enabled', '1', 'Товары - отображение - виден ли список \"Скоро в продаже\" на главной странице', '');
INSERT INTO `settings` VALUES ('443', 'products_awaited_enabled', '1', 'Товары - отображение - виден ли список \"Скоро в продаже\" на странице товара', '');
INSERT INTO `settings` VALUES ('444', 'products_awaited_random', '1', 'Товары - отображение - перемешать ли случайно список \"Скоро в продаже\", когда выводится в виде блока', '');
INSERT INTO `settings` VALUES ('445', 'products_ordered_title', 'Недавно покупали', 'Товары - отображение - оглавление списка \"Недавно покупали\" на стороне клиента', '');
INSERT INTO `settings` VALUES ('446', 'products_ordered_path', 'Покупаемые', 'Товары - отображение - путевое название списка \"Недавно покупали\" в навигаторе на стороне клиента', '');
INSERT INTO `settings` VALUES ('447', 'products_ordered_keywords', 'купили, товар', 'Товары - отображение - ключевые слова списка \"Недавно покупали\"', '');
INSERT INTO `settings` VALUES ('448', 'products_ordered_description', 'Список недавно приобретенных товаров интернет-магазина.', 'Товары - отображение - мета описание списка \"Недавно покупали\"', '');
INSERT INTO `settings` VALUES ('449', 'products_ordered_maxcount', '4', 'Товары - отображение - длина списка \"Недавно покупали\", когда выводится в виде блока', '');
INSERT INTO `settings` VALUES ('450', 'products_main_ordered_enabled', '1', 'Товары - отображение - виден ли список \"Недавно покупали\" на главной странице', '');
INSERT INTO `settings` VALUES ('451', 'products_ordered_enabled', '1', 'Товары - отображение - виден ли список \"Недавно покупали\" на странице товара', '');
INSERT INTO `settings` VALUES ('452', 'products_ordered_random', '1', 'Товары - отображение - перемешать ли случайно список \"Недавно покупали\", когда выводится в виде блока', '');
INSERT INTO `settings` VALUES ('453', 'products_commented_title', 'Недавно обсуждали', 'Товары - отображение - оглавление списка \"Недавно обсуждали\" на стороне клиента', '');
INSERT INTO `settings` VALUES ('454', 'products_commented_path', 'Обсуждаемые', 'Товары - отображение - путевое название списка \"Недавно обсуждали\" в навигаторе на стороне клиента', '');
INSERT INTO `settings` VALUES ('455', 'products_commented_keywords', 'отзыв о товаре, обсуждаемые товары', 'Товары - отображение - ключевые слова списка \"Недавно обсуждали\"', '');
INSERT INTO `settings` VALUES ('456', 'products_commented_description', 'Список товаров интернет-магазина с отзывами покупателей.', 'Товары - отображение - мета описание списка \"Недавно обсуждали\"', '');
INSERT INTO `settings` VALUES ('457', 'products_commented_maxcount', '4', 'Товары - отображение - длина списка \"Недавно обсуждали\", когда выводится в виде блока', '');
INSERT INTO `settings` VALUES ('458', 'products_main_commented_enabled', '1', 'Товары - отображение - виден ли список \"Недавно обсуждали\" на главной странице', '');
INSERT INTO `settings` VALUES ('459', 'products_commented_enabled', '1', 'Товары - отображение - виден ли список \"Недавно обсуждали\" на странице товара', '');
INSERT INTO `settings` VALUES ('460', 'products_commented_random', '1', 'Товары - отображение - перемешать ли случайно список \"Недавно обсуждали\", когда выводится в виде блока', '');
INSERT INTO `settings` VALUES ('461', 'products_comments_title', 'Отзывы о *', 'Товары - отзывы - заголовок блока отзывов на товар', '');
INSERT INTO `settings` VALUES ('462', 'products_comment_next_time', '30', 'Товары - отзывы - антиспам пауза между отзывами', '');
INSERT INTO `settings` VALUES ('463', 'products_comment_moderation', '1', 'Товары - отзывы - включить ли модерацию отзывов', '');
INSERT INTO `settings` VALUES ('464', 'categories_files_folder_prefix', '', 'Категории - изображения - префикс папки с файлами изображений', '');
INSERT INTO `settings` VALUES ('465', 'categories_images_quality', '90', 'Категории - изображения - качество', '');
INSERT INTO `settings` VALUES ('466', 'categories_images_width', '4096', 'Категории - изображения - предельная ширина', '');
INSERT INTO `settings` VALUES ('467', 'categories_images_height', '3072', 'Категории - изображения - предельная высота', '');
INSERT INTO `settings` VALUES ('468', 'categories_thumbnail_width', '320', 'Категории - миниатюры - предельная ширина', '');
INSERT INTO `settings` VALUES ('469', 'categories_thumbnail_height', '240', 'Категории - миниатюры - предельная высота', '');
INSERT INTO `settings` VALUES ('470', 'categories_watermark_transparency', '50', 'Категории - водяной знак - процент видимости на картинке', '');
INSERT INTO `settings` VALUES ('471', 'categories_images_exactly', '', 'Категории - изображения - подгонять ли размеры картинок, меньших предельных размеров', '');
INSERT INTO `settings` VALUES ('472', 'categories_watermark_enabled', '', 'Категории - водяной знак - разрешено ли накладывать на картинку', '');
INSERT INTO `settings` VALUES ('473', 'categories_watermark_location', '8', 'Категории - водяной знак - расположение', '');
INSERT INTO `settings` VALUES ('474', 'categories_meta_autofill', '1', 'Категории - редактирование - заполнять ли пустые поля мета информации автоматически', '');
INSERT INTO `settings` VALUES ('475', 'categories_sort_method', '1', 'Категории - отображение - способ сортировки на стороне клиента', '');
INSERT INTO `settings` VALUES ('476', 'brands_files_folder_prefix', '', 'Бренды - изображения - префикс папки с файлами изображений', '');
INSERT INTO `settings` VALUES ('477', 'brands_images_quality', '90', 'Бренды - изображения - качество', '');
INSERT INTO `settings` VALUES ('478', 'brands_images_width', '4096', 'Бренды - изображения - предельная ширина', '');
INSERT INTO `settings` VALUES ('479', 'brands_images_height', '3072', 'Бренды - изображения - предельная высота', '');
INSERT INTO `settings` VALUES ('480', 'brands_thumbnail_width', '320', 'Бренды - миниатюры - предельная ширина', '');
INSERT INTO `settings` VALUES ('481', 'brands_thumbnail_height', '240', 'Бренды - миниатюры - предельная высота', '');
INSERT INTO `settings` VALUES ('482', 'brands_watermark_transparency', '50', 'Бренды - водяной знак - процент видимости на картинке', '');
INSERT INTO `settings` VALUES ('483', 'brands_images_exactly', '', 'Бренды - изображения - подгонять ли размеры картинок, меньших предельных размеров', '');
INSERT INTO `settings` VALUES ('484', 'brands_watermark_enabled', '', 'Бренды - водяной знак - разрешено ли накладывать на картинку', '');
INSERT INTO `settings` VALUES ('485', 'brands_watermark_location', '8', 'Бренды - водяной знак - расположение', '');
INSERT INTO `settings` VALUES ('486', 'brands_meta_autofill', '1', 'Бренды - редактирование - заполнять ли пустые поля мета информации автоматически', '');
INSERT INTO `settings` VALUES ('487', 'brands_sort_method', '1', 'Бренды - отображение - способ сортировки на стороне клиента', '');
INSERT INTO `settings` VALUES ('488', 'news_files_folder_prefix', '', 'Новости - изображения - префикс папки с файлами изображений', '');
INSERT INTO `settings` VALUES ('489', 'news_images_quality', '90', 'Новости - изображения - качество', '');
INSERT INTO `settings` VALUES ('490', 'news_images_width', '4096', 'Новости - изображения - предельная ширина', '');
INSERT INTO `settings` VALUES ('491', 'news_images_height', '3072', 'Новости - изображения - предельная высота', '');
INSERT INTO `settings` VALUES ('492', 'news_thumbnail_width', '320', 'Новости - миниатюры - предельная ширина', '');
INSERT INTO `settings` VALUES ('493', 'news_thumbnail_height', '240', 'Новости - миниатюры - предельная высота', '');
INSERT INTO `settings` VALUES ('494', 'news_watermark_transparency', '50', 'Новости - водяной знак - процент видимости на картинке', '');
INSERT INTO `settings` VALUES ('495', 'news_images_exactly', '', 'Новости - изображения - подгонять ли размеры картинок, меньших предельных размеров', '');
INSERT INTO `settings` VALUES ('496', 'news_watermark_enabled', '', 'Новости - водяной знак - разрешено ли накладывать на картинку', '');
INSERT INTO `settings` VALUES ('497', 'news_watermark_location', '8', 'Новости - водяной знак - расположение', '');
INSERT INTO `settings` VALUES ('498', 'news_meta_autofill', '1', 'Новости - редактирование - заполнять ли пустые поля мета информации автоматически', '');
INSERT INTO `settings` VALUES ('499', 'news_sort_method', '3', 'Новости - отображение - способ сортировки на стороне клиента', '');
INSERT INTO `settings` VALUES ('500', 'news_main_title', 'Новости', 'Новости - отображение - оглавление анонсового списка на стороне клиента', '');
INSERT INTO `settings` VALUES ('501', 'news_main_maxcount', '6', 'Новости - отображение - максимальное количество публикаций в анонсовом списке', '');
INSERT INTO `settings` VALUES ('502', 'news_products_title', 'Новости о *', 'Новости - отображение - оглавление списка новостей на стороне клиента, привязанных к товару', '');
INSERT INTO `settings` VALUES ('503', 'news_categories_title', 'Новости о *', 'Новости - отображение - оглавление списка новостей категории на стороне клиента', '');
INSERT INTO `settings` VALUES ('504', 'news_comment_next_time', '30', 'Новости - комментарии - антиспам пауза между комментариями', '');
INSERT INTO `settings` VALUES ('505', 'news_comment_moderation', '1', 'Новости - комментарии - включить ли модерацию комментариев', '');
INSERT INTO `settings` VALUES ('506', 'articles_files_folder_prefix', '', 'Статьи - изображения - префикс папки с файлами изображений', '');
INSERT INTO `settings` VALUES ('507', 'articles_images_quality', '90', 'Статьи - изображения - качество', '');
INSERT INTO `settings` VALUES ('508', 'articles_images_width', '4096', 'Статьи - изображения - предельная ширина', '');
INSERT INTO `settings` VALUES ('509', 'articles_images_height', '3072', 'Статьи - изображения - предельная высота', '');
INSERT INTO `settings` VALUES ('510', 'articles_thumbnail_width', '320', 'Статьи - миниатюры - предельная ширина', '');
INSERT INTO `settings` VALUES ('511', 'articles_thumbnail_height', '240', 'Статьи - миниатюры - предельная высота', '');
INSERT INTO `settings` VALUES ('512', 'articles_watermark_transparency', '50', 'Статьи - водяной знак - процент видимости на картинке', '');
INSERT INTO `settings` VALUES ('513', 'articles_images_exactly', '', 'Статьи - изображения - подгонять ли размеры картинок, меньших предельных размеров', '');
INSERT INTO `settings` VALUES ('514', 'articles_watermark_enabled', '', 'Статьи - водяной знак - разрешено ли накладывать на картинку', '');
INSERT INTO `settings` VALUES ('515', 'articles_watermark_location', '8', 'Статьи - водяной знак - расположение', '');
INSERT INTO `settings` VALUES ('516', 'articles_meta_autofill', '1', 'Статьи - редактирование - заполнять ли пустые поля мета информации автоматически', '');
INSERT INTO `settings` VALUES ('517', 'articles_main_title', 'Статьи', 'Статьи - отображение - оглавление анонсового списка на стороне клиента', '');
INSERT INTO `settings` VALUES ('518', 'articles_products_title', 'Статьи о *', 'Статьи - отображение - оглавление списка статей на стороне клиента, привязанных к товару', '');
INSERT INTO `settings` VALUES ('519', 'articles_categories_title', 'Статьи о *', 'Статьи - отображение - оглавление списка статей категории на стороне клиента', '');
INSERT INTO `settings` VALUES ('520', 'articles_comment_next_time', '30', 'Статьи - комментарии - антиспам пауза между комментариями', '');
INSERT INTO `settings` VALUES ('521', 'articles_comment_moderation', '1', 'Статьи - комментарии - включить ли модерацию комментариев', '');
INSERT INTO `settings` VALUES ('522', 'search_files_folder_prefix', '', 'Префикс папки прикрепленных файлов', 'Поиск');
INSERT INTO `settings` VALUES ('523', 'search_images_resizing', '1', 'Обрабатывать ли изображения после загрузки', 'Поиск');
INSERT INTO `settings` VALUES ('524', 'search_images_quality', '90', 'Качество послезагрузочной обработки изображений', 'Поиск');
INSERT INTO `settings` VALUES ('525', 'search_images_exactly', '1', 'Приводить ли изображения к точным размерам после загрузки', 'Поиск');
INSERT INTO `settings` VALUES ('526', 'search_images_width', '800', 'Максимальная ширина изображений после загрузки', 'Поиск');
INSERT INTO `settings` VALUES ('527', 'search_images_height', '600', 'Максимальная высота изображений после загрузки', 'Поиск');
INSERT INTO `settings` VALUES ('528', 'search_thumbnail_resizing', '1', 'Обрабатывать ли миниатюры после загрузки', 'Поиск');
INSERT INTO `settings` VALUES ('529', 'search_thumbnail_width', '160', 'Максимальная ширина миниатюр после загрузки', 'Поиск');
INSERT INTO `settings` VALUES ('530', 'search_thumbnail_height', '120', 'Максимальная высота миниатюр после загрузки', 'Поиск');
INSERT INTO `settings` VALUES ('531', 'search_watermark_enabled', '0', 'Накладывать ли водяной знак после загрузки изображений', 'Поиск');
INSERT INTO `settings` VALUES ('532', 'search_watermark_transparency', '50', 'Процент прозрачности водяного знака', 'Поиск');
INSERT INTO `settings` VALUES ('533', 'search_watermark_location', '8', 'Положение водяного знака', 'Поиск');
INSERT INTO `settings` VALUES ('534', 'search_wysiwyg_disabled', '0', 'Запрещен ли визуальный редактор', 'Поиск');
INSERT INTO `settings` VALUES ('535', 'search_wysiwyg_disabled_mode', '0', '', 'Поиск');
INSERT INTO `settings` VALUES ('536', 'search_meta_autofill', '1', 'Заполнять ли мета теги автоматически', 'Поиск');
INSERT INTO `settings` VALUES ('537', 'search_sort_method', '6', 'Дефолтный способ сортировки записей в списке на клиентской стороне', 'Поиск');
INSERT INTO `settings` VALUES ('538', 'search_sort_descending', '0', 'Противоположное направление сортировки записей в списке на клиентской стороне', 'Поиск');
INSERT INTO `settings` VALUES ('539', 'search_sort_laconical', '0', 'Лаконичность сортировки записей (отсечение не имеющих смысла)', 'Поиск');
INSERT INTO `settings` VALUES ('540', 'search_main_title', 'Поиск', 'Дефолтный заголовок страницы', 'Поиск');
INSERT INTO `settings` VALUES ('541', 'search_main_path', 'Поиск', 'Название страницы в хлебных крошках', 'Поиск');
INSERT INTO `settings` VALUES ('542', 'search_main_keywords', 'поиск', 'Дефолтный список ключевых слов страницы', 'Поиск');
INSERT INTO `settings` VALUES ('543', 'search_main_description', 'Страница поиска товаров в нашем магазине.', 'Дефолтное мета описание страницы', 'Поиск');
INSERT INTO `settings` VALUES ('544', 'search_num', '24', 'Число записей в списке на странице клиентской стороны', 'Поиск');
INSERT INTO `settings` VALUES ('545', 'search_num_admin', '50', 'Число записей в списке на странице админпанели', 'Поиск');
INSERT INTO `settings` VALUES ('546', 'search_show_all_disabled', '1', 'Запрещен ли просмотр всех записей на одной странице клиентской стороны', 'Поиск');

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА shippings_terms: структура
--
-- ----------------------------------------------------------------------------

DROP TABLE IF EXISTS `shippings_terms`;

CREATE TABLE `shippings_terms` (
  `term_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'Идентификатор срока отправки',
  `name` varchar(256) NOT NULL DEFAULT '' COMMENT 'Название срока отправки',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Дата создания записи',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Дата изменения записи',
  PRIMARY KEY (`term_id`),
  KEY `name` (`name`),
  KEY `created` (`created`),
  KEY `modified` (`modified`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА shippings_terms: содержимое
--
-- ----------------------------------------------------------------------------

INSERT INTO `shippings_terms` VALUES ('1', 'в течении 2 дней', '2014-11-12 16:40:35', '2014-11-12 16:40:45');
INSERT INTO `shippings_terms` VALUES ('2', 'в течении недели', '2014-11-12 16:40:58', '2014-11-12 16:40:58');
INSERT INTO `shippings_terms` VALUES ('3', 'в день оплаты', '2014-11-12 16:41:19', '2014-11-12 16:41:19');

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА stocks: структура
--
-- ----------------------------------------------------------------------------

DROP TABLE IF EXISTS `stocks`;

CREATE TABLE `stocks` (
  `stock_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `objects` varchar(512) NOT NULL DEFAULT '',
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `hidden` tinyint(1) NOT NULL DEFAULT '0',
  `visible` tinyint(1) NOT NULL DEFAULT '0',
  `enable_debit` tinyint(1) NOT NULL DEFAULT '1',
  `enable_credit` tinyint(1) NOT NULL DEFAULT '1',
  `url` varchar(256) NOT NULL DEFAULT '',
  `meta_title` varchar(256) NOT NULL DEFAULT '',
  `meta_keywords` varchar(512) NOT NULL DEFAULT '',
  `meta_description` varchar(512) NOT NULL DEFAULT '',
  `name` varchar(256) NOT NULL DEFAULT '',
  `annotation` text NOT NULL,
  `description` text NOT NULL,
  `seo_description` text NOT NULL,
  `image` varchar(256) NOT NULL DEFAULT '',
  `images` text NOT NULL,
  `images_alts` text NOT NULL,
  `images_texts` longtext NOT NULL,
  `images_view` text NOT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `browsed` int(11) NOT NULL DEFAULT '0',
  `order_num` int(11) NOT NULL DEFAULT '0',
  `tags` varchar(256) NOT NULL DEFAULT '' COMMENT 'Теги записи',
  `highlighted` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Признак Выделено визуально',
  `url_special` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Признак Особый адрес',
  `template` varchar(256) NOT NULL DEFAULT '' COMMENT 'Нестандартный шаблон для отображения',
  PRIMARY KEY (`stock_id`),
  KEY `enabled` (`enabled`),
  KEY `hidden` (`hidden`),
  KEY `visible` (`visible`),
  KEY `enable_debit` (`enable_debit`),
  KEY `enable_credit` (`enable_credit`),
  KEY `url` (`url`),
  KEY `name` (`name`),
  KEY `browsed` (`browsed`),
  KEY `order_num` (`order_num`),
  KEY `tags` (`tags`),
  KEY `highlighted` (`highlighted`),
  KEY `image` (`image`),
  KEY `template` (`template`),
  KEY `created` (`created`),
  KEY `modified` (`modified`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА stocks: содержимое
--
-- ----------------------------------------------------------------------------


-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА towns: структура
--
-- ----------------------------------------------------------------------------

DROP TABLE IF EXISTS `towns`;

CREATE TABLE `towns` (
  `town_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'Идентификатор города',
  `country_id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Идентификатор страны',
  `region_id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Идентификатор области',
  `enabled` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'Разрешена ли запись к использованию',
  `url` varchar(256) NOT NULL DEFAULT '' COMMENT 'Адрес страницы записи',
  `meta_title` varchar(256) NOT NULL DEFAULT '' COMMENT 'Мета заголовок страницы записи',
  `meta_keywords` varchar(512) NOT NULL DEFAULT '' COMMENT 'Мета ключевые слова страницы записи',
  `meta_description` varchar(512) NOT NULL DEFAULT '' COMMENT 'Мета описание страницы записи',
  `name` varchar(256) NOT NULL DEFAULT '' COMMENT 'Название города',
  `description` text NOT NULL COMMENT 'Описание города',
  `seo_description` text NOT NULL COMMENT 'SEO текст',
  `phone_code` varchar(16) NOT NULL DEFAULT '' COMMENT 'Телефонный стационарный код города',
  `post_code` varchar(24) NOT NULL DEFAULT '' COMMENT 'Почтовый код города',
  `images` text NOT NULL COMMENT 'Изображения записи',
  `images_alts` text NOT NULL COMMENT 'Подписи изображений записи',
  `images_texts` longtext NOT NULL COMMENT 'Описания изображений записи',
  `images_view` text NOT NULL COMMENT 'Признаки использования в слайдере изображений записи',
  `tags` varchar(256) NOT NULL DEFAULT '' COMMENT 'Теги записи',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Дата создания записи',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Дата изменения записи',
  `browsed` int(11) NOT NULL DEFAULT '0' COMMENT 'Количество просмотров записи',
  `order_num` int(11) NOT NULL DEFAULT '0' COMMENT 'Порядковый номер записи',
  PRIMARY KEY (`town_id`),
  KEY `country_id` (`country_id`),
  KEY `region_id` (`region_id`),
  KEY `enabled` (`enabled`),
  KEY `url` (`url`),
  KEY `name` (`name`),
  KEY `phone_code` (`phone_code`),
  KEY `post_code` (`post_code`),
  KEY `tags` (`tags`),
  KEY `created` (`created`),
  KEY `modified` (`modified`),
  KEY `browsed` (`browsed`),
  KEY `order_num` (`order_num`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА towns: содержимое
--
-- ----------------------------------------------------------------------------


-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА users: структура
--
-- ----------------------------------------------------------------------------

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `user_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'Идентификатор пользователя',
  `email` varchar(256) NOT NULL DEFAULT '' COMMENT 'Емейл',
  `password` varchar(50) NOT NULL DEFAULT '' COMMENT 'Хеш пароля',
  `name` varchar(256) NOT NULL DEFAULT '' COMMENT 'Фамилия, отчество, имя',
  `group_id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Идентификатор группы скидок',
  `enabled` tinyint(1) NOT NULL DEFAULT '0',
  `subdomain` varchar(256) NOT NULL DEFAULT '' COMMENT 'Левая часть имени субдомена',
  `subdomain_enabled` tinyint(1) NOT NULL DEFAULT '0',
  `subdomain_html` text NOT NULL,
  `juridical` tinyint(1) NOT NULL DEFAULT '0',
  `juridicaladdress` varchar(512) NOT NULL DEFAULT '' COMMENT 'Юридический адрес',
  `fiscalnum` varchar(256) NOT NULL DEFAULT '' COMMENT 'Налоговый номер',
  `bank` varchar(256) NOT NULL DEFAULT '' COMMENT 'Банк',
  `bankaccount` varchar(256) NOT NULL DEFAULT '' COMMENT 'Расчетный счет',
  `bankmfo` varchar(256) NOT NULL DEFAULT '' COMMENT 'МФО банка',
  `bankokpo` varchar(256) NOT NULL DEFAULT '' COMMENT 'ОКПО банка',
  `card_num` varchar(32) NOT NULL DEFAULT '' COMMENT 'Номер карточки в картотеке магазина',
  `address` varchar(512) NOT NULL DEFAULT '' COMMENT 'Адрес',
  `address2` varchar(512) NOT NULL DEFAULT '' COMMENT 'Адрес 2',
  `phone` varchar(256) NOT NULL DEFAULT '' COMMENT 'Телефон',
  `phone2` varchar(256) NOT NULL DEFAULT '' COMMENT 'Телефон 2',
  `email2` varchar(256) NOT NULL DEFAULT '' COMMENT 'Емейл 2',
  `remark` text NOT NULL,
  `cash` float(12,4) NOT NULL DEFAULT '0.0000',
  `affiliate_id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Идентификатор пользователя, кто привел этого',
  `charges` mediumtext NOT NULL,
  `referals` mediumtext NOT NULL,
  `regs` mediumtext NOT NULL,
  `commissions` mediumtext NOT NULL,
  `images` text NOT NULL,
  `images_alts` text NOT NULL,
  `images_texts` longtext NOT NULL,
  `images_view` text NOT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `nickname` varchar(64) NOT NULL DEFAULT '' COMMENT 'Ник пользователя',
  `birthday` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'День рождения',
  `icq` varchar(256) NOT NULL DEFAULT '' COMMENT 'ICQ номер пользователя',
  `icq2` varchar(256) NOT NULL DEFAULT '' COMMENT 'ICQ номер 2 пользователя',
  `skype` varchar(256) NOT NULL DEFAULT '' COMMENT 'Skype имя пользователя',
  `skype2` varchar(256) NOT NULL DEFAULT '' COMMENT 'Skype имя 2 пользователя',
  `country_id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Идентификатор страны',
  `region_id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Идентификатор области',
  `town_id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Идентификатор города',
  `school_id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Идентификатор учебного заведения',
  `class_id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Идентификатор класса учебного заведения',
  `grades` longtext NOT NULL COMMENT 'Сведения об оценках',
  `used_shop` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'Используется ли запись в интернет-магазине',
  `used_dnevnik` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Используется ли запись в СМС дневнике',
  `used_social` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Используется ли запись в социальной сети',
  `remote_token` varchar(256) NOT NULL DEFAULT '' COMMENT 'Аутентификатор удаленного действия',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Дата изменения записи',
  `ip` varchar(256) NOT NULL DEFAULT '' COMMENT 'IP-адрес пользователя во время регистрации',
  `price_id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Идентификатор ценовой группы',
  `template` varchar(256) NOT NULL DEFAULT '',
  `coupon_id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Идентификатор скидочного купона',
  `deleted` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Признак Запись удалена',
  PRIMARY KEY (`user_id`),
  KEY `email` (`email`),
  KEY `subdomain` (`subdomain`),
  KEY `subdomain_enabled` (`subdomain_enabled`),
  KEY `email2` (`email2`),
  KEY `affiliate_id` (`affiliate_id`),
  KEY `nickname` (`nickname`),
  KEY `birthday` (`birthday`),
  KEY `icq` (`icq`),
  KEY `icq2` (`icq2`),
  KEY `skype` (`skype`),
  KEY `skype2` (`skype2`),
  KEY `country_id` (`country_id`),
  KEY `region_id` (`region_id`),
  KEY `town_id` (`town_id`),
  KEY `school_id` (`school_id`),
  KEY `class_id` (`class_id`),
  KEY `used_shop` (`used_shop`),
  KEY `used_dnevnik` (`used_dnevnik`),
  KEY `used_social` (`used_social`),
  KEY `remote_token` (`remote_token`),
  KEY `modified` (`modified`),
  KEY `ip` (`ip`),
  KEY `price_id` (`price_id`),
  KEY `template` (`template`),
  KEY `name` (`name`),
  KEY `phone` (`phone`),
  KEY `phone2` (`phone2`),
  KEY `address` (`address`(333)),
  KEY `address2` (`address2`(333)),
  KEY `enabled` (`enabled`),
  KEY `group_id` (`group_id`),
  KEY `coupon_id` (`coupon_id`),
  KEY `juridical` (`juridical`),
  KEY `juridicaladdress` (`juridicaladdress`(333)),
  KEY `fiscalnum` (`fiscalnum`),
  KEY `bank` (`bank`),
  KEY `bankaccount` (`bankaccount`),
  KEY `bankmfo` (`bankmfo`),
  KEY `bankokpo` (`bankokpo`),
  KEY `card_num` (`card_num`),
  KEY `created` (`created`),
  KEY `deleted` (`deleted`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------------------------------------------------------
--
-- ТАБЛИЦА users: содержимое
--
-- ----------------------------------------------------------------------------

INSERT INTO `users` VALUES ('1', 'timur_tam@mail.ru', 'd3f3a3a293ab2f6c1ef79b8282ff21a5', 'Timur||', '0', '1', '', '0', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', '0.0000', '0', '', '', '', '', '', '', '', '', '2015-02-04 14:10:45', '', '0000-00-00 00:00:00', '', '', '', '', '0', '0', '0', '0', '0', '', '1', '0', '0', '', '0000-00-00 00:00:00', '188.163.69.50', '0', '', '0', '0');
INSERT INTO `users` VALUES ('2', 'papakarlo.ukraine@gmail.com', '5a514f1b941235e337ed50b591198469', 'Papa Karlo||', '0', '1', '', '0', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', '0.0000', '0', '', '', '', '', '', '', '', '', '2015-02-04 19:57:36', '', '0000-00-00 00:00:00', '', '', '', '', '0', '0', '0', '0', '0', '', '1', '0', '0', '', '0000-00-00 00:00:00', '188.163.69.50', '0', '', '0', '0');

